/**
 * JEE Formula Library — Phase 2
 * ~220 formulas across Physics, Chemistry, Mathematics
 * No API. Renders with KaTeX. Works offline.
 *
 * Usage:
 *   const lib = new FormulaLibrary();
 *   lib.getByChapter('rot')   → [{name, latex, desc, tip}]
 *   lib.getBySubject('physics') → all physics formulas
 *   lib.search('torque')      → matching formulas
 *   lib.getSummarySheet()     → high-weightage formulas only
 */
(function (global) {
  'use strict';

  // ── FORMULA DATA ──────────────────────────────────────────
  // Each entry: { id, chapter, subject, wt, name, items[], tip? }
  // items: [{ name, latex, desc }]

  const FORMULA_DATA = [

    // ══════════════════════════════════════════════
    // PHYSICS
    // ══════════════════════════════════════════════

    { id:'kin', subject:'physics', wt:3, name:'Kinematics', items:[
      { name:'1st Equation', latex:'v = u + at', desc:'Final velocity; no displacement needed' },
      { name:'2nd Equation', latex:'s = ut + \\dfrac{1}{2}at^2', desc:'Displacement with time' },
      { name:'3rd Equation', latex:'v^2 = u^2 + 2as', desc:'Final velocity; no time needed' },
      { name:'nth Second', latex:'s_n = u + \\dfrac{a}{2}(2n - 1)', desc:'Distance covered in the nth second' },
      { name:'Projectile Range', latex:'R = \\dfrac{u^2 \\sin 2\\theta}{g}', desc:'Range on flat ground; max at θ=45°' },
      { name:'Max Height', latex:'H = \\dfrac{u^2 \\sin^2\\theta}{2g}', desc:'Maximum height in projectile motion' },
      { name:'Time of Flight', latex:'T = \\dfrac{2u\\sin\\theta}{g}', desc:'Total air time' },
      { name:'Relative Velocity', latex:'\\vec{v}_{AB} = \\vec{v}_A - \\vec{v}_B', desc:'Velocity of A as seen from B' },
    ], tip:'Equations valid only for constant acceleration. Always define +ve direction first.' },

    { id:'nlm', subject:'physics', wt:4, name:'Laws of Motion', items:[
      { name:"Newton's 2nd Law", latex:'\\vec{F}_{net} = m\\vec{a}', desc:'Net force equals mass × acceleration' },
      { name:'Static Friction', latex:'f_s \\leq \\mu_s N', desc:'Maximum static friction = μₛN' },
      { name:'Kinetic Friction', latex:'f_k = \\mu_k N', desc:'Always opposes relative motion' },
      { name:'Banking Angle', latex:'\\tan\\theta = \\dfrac{v^2}{rg}', desc:'Ideal banking (no friction required)' },
      { name:'Conical Pendulum', latex:'T = 2\\pi\\sqrt{\\dfrac{L\\cos\\theta}{g}}', desc:'Period of conical pendulum' },
      { name:'Pseudo Force', latex:'\\vec{F}_{pseudo} = -m\\vec{a}_0', desc:'Fictitious force in non-inertial frame' },
    ]},

    { id:'wpe', subject:'physics', wt:4, name:'Work, Power & Energy', items:[
      { name:'Work Done', latex:'W = Fd\\cos\\theta = \\vec{F}\\cdot\\vec{d}', desc:'Work = force × displacement × cosθ' },
      { name:'Kinetic Energy', latex:'KE = \\dfrac{1}{2}mv^2', desc:'Energy due to motion' },
      { name:'Spring PE', latex:'PE = \\dfrac{1}{2}kx^2', desc:'Elastic potential energy stored in spring' },
      { name:'Work-Energy Theorem', latex:'W_{net} = \\Delta KE = KE_f - KE_i', desc:'Net work equals change in KE' },
      { name:'Power', latex:'P = \\dfrac{W}{t} = \\vec{F}\\cdot\\vec{v}', desc:'Rate of doing work' },
      { name:'Gravitational PE', latex:'\\Delta PE = mgh', desc:'Change in gravitational PE near Earth' },
    ]},

    { id:'rot', subject:'physics', wt:5, name:'Rotational Motion', items:[
      { name:'Torque', latex:'\\vec{\\tau} = \\vec{r}\\times\\vec{F} = I\\alpha', desc:'Rotational equivalent of force' },
      { name:'Angular Momentum', latex:'\\vec{L} = I\\vec{\\omega} = \\vec{r}\\times m\\vec{v}', desc:'Conserved when τ_net = 0' },
      { name:'MOI — Thin Rod (center)', latex:'I = \\dfrac{1}{12}ML^2', desc:'Axis through center, perpendicular to rod' },
      { name:'MOI — Thin Rod (end)', latex:'I = \\dfrac{1}{3}ML^2', desc:'Axis through one end' },
      { name:'MOI — Disk / Cylinder', latex:'I = \\dfrac{1}{2}MR^2', desc:'Axis through center, perpendicular to plane' },
      { name:'MOI — Ring', latex:'I = MR^2', desc:'Axis through center, perpendicular to ring' },
      { name:'MOI — Solid Sphere', latex:'I = \\dfrac{2}{5}MR^2', desc:'Axis through center' },
      { name:'MOI — Hollow Sphere', latex:'I = \\dfrac{2}{3}MR^2', desc:'Axis through center' },
      { name:'Parallel Axis Theorem', latex:'I = I_{cm} + Md^2', desc:'Shift axis by distance d from CM' },
      { name:'KE of Rolling', latex:'KE = \\dfrac{1}{2}mv^2\\left(1 + \\dfrac{k^2}{R^2}\\right)', desc:'k² = I/M; k²/R² = 2/5 (solid sphere), 1/2 (disk)' },
      { name:'Rolling Acceleration', latex:'a = \\dfrac{g\\sin\\theta}{1 + k^2/R^2}', desc:'Acceleration down incline; depends on shape' },
    ], tip:'For rolling without slipping: v = Rω, a = Rα. Use energy conservation when force/friction not needed.' },

    { id:'shm', subject:'physics', wt:4, name:'Simple Harmonic Motion', items:[
      { name:'Displacement', latex:'x = A\\sin(\\omega t + \\phi)', desc:'General SHM equation' },
      { name:'Velocity', latex:'v = \\omega\\sqrt{A^2 - x^2}', desc:'Max at x=0: v_max=Aω; zero at x=±A' },
      { name:'Acceleration', latex:'a = -\\omega^2 x', desc:'Always directed toward equilibrium' },
      { name:'Time Period (spring)', latex:'T = 2\\pi\\sqrt{\\dfrac{m}{k}}', desc:'Independent of amplitude' },
      { name:'Time Period (pendulum)', latex:'T = 2\\pi\\sqrt{\\dfrac{L}{g}}', desc:'Valid for small angles (θ < 10°)' },
      { name:'Total Energy', latex:'E = \\dfrac{1}{2}m\\omega^2 A^2 = \\dfrac{1}{2}kA^2', desc:'Constant; independent of position' },
      { name:'KE in SHM', latex:'KE = \\dfrac{1}{2}m\\omega^2(A^2 - x^2)', desc:'Maximum at mean position' },
      { name:'PE in SHM', latex:'PE = \\dfrac{1}{2}m\\omega^2 x^2', desc:'Maximum at extreme position' },
    ]},

    { id:'es', subject:'physics', wt:6, name:'Electrostatics', items:[
      { name:"Coulomb's Law", latex:'F = \\dfrac{kq_1 q_2}{r^2} = \\dfrac{q_1 q_2}{4\\pi\\varepsilon_0 r^2}', desc:'k = 9×10⁹ N m²/C²' },
      { name:'Electric Field', latex:'E = \\dfrac{kq}{r^2}', desc:'Due to point charge; radially outward for +q' },
      { name:'Electric Potential', latex:'V = \\dfrac{kq}{r}', desc:'Scalar; zero at infinity' },
      { name:'Relation E and V', latex:'E = -\\dfrac{dV}{dr}', desc:'Field points from high V to low V' },
      { name:"Gauss's Law", latex:'\\oint \\vec{E}\\cdot d\\vec{A} = \\dfrac{Q_{enc}}{\\varepsilon_0}', desc:'Total flux through closed surface' },
      { name:'Dipole Moment', latex:'\\vec{p} = q\\vec{d}', desc:'Direction: -q to +q' },
      { name:'Dipole E (axial)', latex:'E_{axial} = \\dfrac{2kp}{r^3}', desc:'Along dipole axis' },
      { name:'Dipole E (equatorial)', latex:'E_{eq} = \\dfrac{kp}{r^3}', desc:'Perpendicular to dipole; opposite direction' },
      { name:'Energy Density', latex:'u = \\dfrac{1}{2}\\varepsilon_0 E^2', desc:'Energy per unit volume in electric field' },
      { name:'Torque on Dipole', latex:'\\tau = pE\\sin\\theta', desc:'Aligns dipole along field; max at θ=90°' },
    ], tip:'Inside conductor: E=0, V=constant. Charge resides on surface.' },

    { id:'cap', subject:'physics', wt:4, name:'Capacitors', items:[
      { name:'Capacitance', latex:'C = \\dfrac{Q}{V} = \\dfrac{\\varepsilon_0 A}{d}', desc:'Parallel plate capacitor' },
      { name:'With Dielectric', latex:"C' = \\kappa C_0", desc:'κ = dielectric constant (always ≥ 1)' },
      { name:'Series', latex:'\\dfrac{1}{C_{eq}} = \\dfrac{1}{C_1} + \\dfrac{1}{C_2} + \\cdots', desc:'Charge same; voltage adds' },
      { name:'Parallel', latex:'C_{eq} = C_1 + C_2 + \\cdots', desc:'Voltage same; charge adds' },
      { name:'Energy Stored', latex:'U = \\dfrac{1}{2}CV^2 = \\dfrac{Q^2}{2C} = \\dfrac{QV}{2}', desc:'Three equivalent forms' },
      { name:'Energy Density', latex:'u = \\dfrac{1}{2}\\varepsilon_0 E^2 = \\dfrac{1}{2}\\varepsilon_0\\kappa E^2', desc:'With dielectric' },
    ]},

    { id:'cur', subject:'physics', wt:5, name:'Current Electricity', items:[
      { name:"Ohm's Law", latex:'V = IR', desc:'Valid for ohmic conductors only' },
      { name:'Resistance', latex:'R = \\dfrac{\\rho L}{A}', desc:'ρ = resistivity; depends on material & temperature' },
      { name:'Series Resistance', latex:'R_{eq} = R_1 + R_2 + \\cdots', desc:'Same current flows through all' },
      { name:'Parallel Resistance', latex:'\\dfrac{1}{R_{eq}} = \\dfrac{1}{R_1} + \\dfrac{1}{R_2} + \\cdots', desc:'Same voltage across all' },
      { name:'Power', latex:'P = VI = I^2R = \\dfrac{V^2}{R}', desc:'Three equivalent forms' },
      { name:'EMF and Terminal V', latex:'V_{terminal} = \\varepsilon - Ir', desc:'r = internal resistance; drops under load' },
      { name:'Wheatstone Bridge', latex:'\\dfrac{P}{Q} = \\dfrac{R}{S}', desc:'Balanced bridge: no current through galvanometer' },
      { name:"Kirchhoff's Current Law", latex:'\\sum I_{in} = \\sum I_{out}', desc:'At any junction (charge conservation)' },
      { name:"Kirchhoff's Voltage Law", latex:'\\sum V = 0', desc:'Around any closed loop (energy conservation)' },
    ]},

    { id:'mag', subject:'physics', wt:4, name:'Magnetism', items:[
      { name:'Lorentz Force', latex:'\\vec{F} = q\\vec{v}\\times\\vec{B}', desc:'On moving charge; perpendicular to both v and B' },
      { name:'Force on Wire', latex:'\\vec{F} = I\\vec{L}\\times\\vec{B}', desc:'On current-carrying conductor in field B' },
      { name:'B — Infinite Wire', latex:'B = \\dfrac{\\mu_0 I}{2\\pi r}', desc:'At distance r from long straight wire' },
      { name:'B — Circular Loop (center)', latex:'B = \\dfrac{\\mu_0 I}{2R}', desc:'At center of loop of radius R' },
      { name:'B — Solenoid', latex:'B = \\mu_0 nI', desc:'n = turns per unit length; uniform inside' },
      { name:'Cyclotron Radius', latex:'r = \\dfrac{mv}{qB}', desc:'Radius of circular path in magnetic field' },
      { name:'Cyclotron Period', latex:'T = \\dfrac{2\\pi m}{qB}', desc:'Independent of speed — key cyclotron principle' },
      { name:'Magnetic Moment', latex:'M = NIA', desc:'Of a current loop; N turns, area A' },
      { name:'Torque on Dipole', latex:'\\tau = MB\\sin\\theta = NIAB\\sin\\theta', desc:'Aligns dipole along B' },
    ]},

    { id:'emi', subject:'physics', wt:5, name:'EMI & AC Circuits', items:[
      { name:'Magnetic Flux', latex:'\\Phi = NBA\\cos\\theta', desc:'Max when B⊥ plane; zero when B∥ plane' },
      { name:"Faraday's Law", latex:'\\varepsilon = -\\dfrac{d\\Phi}{dt}', desc:'Induced EMF = rate of change of flux' },
      { name:'Rotating Coil EMF', latex:'\\varepsilon = NBA\\omega\\sin(\\omega t)', desc:'Peak EMF = NBAω' },
      { name:'Motional EMF', latex:'\\varepsilon = Bvl', desc:'Rod of length l moving at v in field B' },
      { name:'Self Inductance', latex:'\\varepsilon = -L\\dfrac{dI}{dt}', desc:'L = self-inductance in Henry' },
      { name:'Solenoid Inductance', latex:'L = \\mu_0 n^2 V', desc:'V = volume; n = turns/length' },
      { name:'Energy in Inductor', latex:'U = \\dfrac{1}{2}LI^2', desc:'Analogous to ½mv² in mechanics' },
      { name:'Impedance', latex:'Z = \\sqrt{R^2 + (X_L - X_C)^2}', desc:'X_L=ωL, X_C=1/ωC' },
      { name:'Resonant Frequency', latex:'\\omega_0 = \\dfrac{1}{\\sqrt{LC}},\\quad f_0 = \\dfrac{1}{2\\pi\\sqrt{LC}}', desc:'Z is minimum = R at resonance' },
      { name:'Power in AC', latex:'P = V_{rms}I_{rms}\\cos\\phi', desc:'cosφ = power factor = R/Z' },
      { name:'Transformer', latex:'\\dfrac{V_s}{V_p} = \\dfrac{N_s}{N_p} = \\dfrac{I_p}{I_s}', desc:'Ideal transformer (100% efficiency)' },
    ]},

    { id:'ray', subject:'physics', wt:4, name:'Ray Optics', items:[
      { name:"Snell's Law", latex:'n_1\\sin\\theta_1 = n_2\\sin\\theta_2', desc:'At any refracting surface' },
      { name:'Critical Angle', latex:'\\sin C = \\dfrac{n_2}{n_1}', desc:'For TIR: θ > C, n₁ > n₂' },
      { name:'Mirror Formula', latex:'\\dfrac{1}{f} = \\dfrac{1}{v} + \\dfrac{1}{u},\\quad f = \\dfrac{R}{2}', desc:'Sign convention: real is positive' },
      { name:'Lens Formula', latex:'\\dfrac{1}{f} = \\dfrac{1}{v} - \\dfrac{1}{u}', desc:'f +ve for convex, -ve for concave' },
      { name:"Lens Maker's Formula", latex:'\\dfrac{1}{f} = (n-1)\\left(\\dfrac{1}{R_1} - \\dfrac{1}{R_2}\\right)', desc:'n = refractive index of lens material' },
      { name:'Magnification (mirror)', latex:'m = -\\dfrac{v}{u}', desc:'m > 0 → virtual, erect; m < 0 → real, inverted' },
      { name:'Prism — Minimum Deviation', latex:'n = \\dfrac{\\sin\\left(\\dfrac{A+\\delta_m}{2}\\right)}{\\sin(A/2)}', desc:'At min deviation r₁ = r₂ = A/2' },
      { name:'Dispersive Power', latex:'\\omega = \\dfrac{\\mu_v - \\mu_r}{\\mu_{yellow} - 1}', desc:'Ability to split colours' },
    ]},

    { id:'mod', subject:'physics', wt:5, name:'Modern Physics', items:[
      { name:'Photon Energy', latex:'E = hf = \\dfrac{hc}{\\lambda}', desc:'h = 6.626×10⁻³⁴ J·s' },
      { name:'Photoelectric Equation', latex:'KE_{max} = hf - \\phi = eV_0', desc:'φ = work function; V₀ = stopping potential' },
      { name:'de Broglie Wavelength', latex:'\\lambda = \\dfrac{h}{p} = \\dfrac{h}{mv}', desc:'Wave nature of matter' },
      { name:'Bohr Radius', latex:'r_n = n^2 a_0 = n^2 \\times 0.529\\,\\text{Å}', desc:'nth orbit radius' },
      { name:'Bohr Energy', latex:'E_n = -\\dfrac{13.6}{n^2}\\,\\text{eV}', desc:'Negative → bound state; ground state n=1' },
      { name:'Mass-Energy', latex:'E = mc^2', desc:'c = 3×10⁸ m/s' },
      { name:'Radioactive Decay', latex:'N = N_0 e^{-\\lambda t} = N_0 \\left(\\dfrac{1}{2}\\right)^{t/T_{1/2}}', desc:'Exponential decay law' },
      { name:'Half-Life', latex:'T_{1/2} = \\dfrac{0.693}{\\lambda}', desc:'Time for N₀ to become N₀/2' },
      { name:'Activity', latex:'A = \\lambda N', desc:'Disintegrations per second (Becquerel)' },
    ]},

    // ══════════════════════════════════════════════
    // CHEMISTRY
    // ══════════════════════════════════════════════

    { id:'mol', subject:'chemistry', wt:3, name:'Mole Concept', items:[
      { name:'Moles', latex:'n = \\dfrac{m}{M} = \\dfrac{V}{22.4} \\text{ (at STP)}', desc:'V in litres at STP' },
      { name:"Avogadro's Number", latex:'N = n \\times N_A,\\quad N_A = 6.022\\times10^{23}', desc:'Particles per mole' },
      { name:'Molarity', latex:'M = \\dfrac{n_{solute}}{V_{solution}(\\text{L})}', desc:'mol/L; changes with temperature' },
      { name:'Molality', latex:'m = \\dfrac{n_{solute}}{m_{solvent}(\\text{kg})}', desc:'mol/kg; independent of temperature' },
      { name:'Mole Fraction', latex:'\\chi_A = \\dfrac{n_A}{n_A + n_B}', desc:'Dimensionless; χ_A + χ_B = 1' },
      { name:'Normality', latex:'N = n_{eq}/V(L) = \\text{n-factor} \\times M', desc:'n-factor depends on reaction type' },
    ]},

    { id:'therm', subject:'chemistry', wt:4, name:'Thermodynamics (Chem)', items:[
      { name:'First Law', latex:'\\Delta U = Q - W', desc:'ΔU = internal energy; W = work done BY system' },
      { name:'Enthalpy', latex:'\\Delta H = \\Delta U + \\Delta n_g RT', desc:'Δnₘ = moles of gas (products - reactants)' },
      { name:'Gibbs Free Energy', latex:'\\Delta G = \\Delta H - T\\Delta S', desc:'ΔG < 0 → spontaneous' },
      { name:'Standard Free Energy', latex:'\\Delta G^\\circ = -RT\\ln K = -nFE^\\circ', desc:'Links equilibrium constant and cell EMF' },
      { name:"Hess's Law", latex:'\\Delta H_{rxn} = \\sum \\Delta H_f^\\circ (products) - \\sum \\Delta H_f^\\circ (reactants)', desc:'Path-independent; state function' },
      { name:'Bond Enthalpy', latex:'\\Delta H_{rxn} = \\sum BE_{broken} - \\sum BE_{formed}', desc:'Approximate; gaseous species only' },
    ]},

    { id:'ceq', subject:'chemistry', wt:4, name:'Chemical Equilibrium', items:[
      { name:'Equilibrium Constant', latex:'K_c = \\dfrac{[C]^c[D]^d}{[A]^a[B]^b}', desc:'For aA + bB ⇌ cC + dD' },
      { name:'Kp and Kc', latex:'K_p = K_c(RT)^{\\Delta n}', desc:'Δn = moles of gaseous products − reactants' },
      { name:'Reaction Quotient', latex:'Q < K \\Rightarrow \\text{forward},\\quad Q > K \\Rightarrow \\text{reverse}', desc:'Predicts direction of reaction' },
      { name:'Henderson-Hasselbalch', latex:'\\text{pH} = \\text{p}K_a + \\log\\dfrac{[A^-]}{[HA]}', desc:'pH of buffer solution' },
      { name:'Water Ionic Product', latex:'K_w = [H^+][OH^-] = 10^{-14}\\text{ at }25^\\circ C', desc:'pKw = 14; pH + pOH = 14' },
      { name:'Degree of Dissociation', latex:'K_a = \\dfrac{c\\alpha^2}{1-\\alpha} \\approx c\\alpha^2 \\text{ (if } \\alpha \\ll 1)', desc:'For weak acid HA ⇌ H⁺ + A⁻' },
    ]},

    { id:'elec', subject:'chemistry', wt:5, name:'Electrochemistry', items:[
      { name:'Nernst Equation', latex:'E = E^\\circ - \\dfrac{0.0592}{n}\\log Q\\quad (25^\\circ C)', desc:'E° = standard cell EMF; n = electrons transferred' },
      { name:'Standard Free Energy', latex:'\\Delta G^\\circ = -nFE^\\circ', desc:'F = 96500 C/mol (Faraday constant)' },
      { name:"Faraday's 1st Law", latex:'m = \\dfrac{M \\cdot I \\cdot t}{n \\cdot F} = ZIt', desc:'m = mass deposited; Z = electrochemical equivalent' },
      { name:'Conductance', latex:'\\Lambda_m = \\dfrac{\\kappa}{c}', desc:'κ = specific conductance; c = concentration' },
      { name:'Kohlrausch Law', latex:'\\Lambda_m^\\infty = \\nu_+\\lambda_+^\\infty + \\nu_-\\lambda_-^\\infty', desc:'Molar conductance at infinite dilution' },
      { name:'Cell EMF', latex:'E_{cell} = E_{cathode} - E_{anode}', desc:'Higher SRP = cathode (reduction occurs there)' },
    ]},

    { id:'ckin', subject:'chemistry', wt:3, name:'Chemical Kinetics', items:[
      { name:'Rate Law', latex:'r = k[A]^m[B]^n', desc:'m,n = reaction orders (determined experimentally)' },
      { name:'First Order — Integrated', latex:'k = \\dfrac{2.303}{t}\\log\\dfrac{[A]_0}{[A]}', desc:'Plot ln[A] vs t → straight line' },
      { name:'First Order Half-Life', latex:'t_{1/2} = \\dfrac{0.693}{k}', desc:'Independent of initial concentration' },
      { name:'Second Order Half-Life', latex:'t_{1/2} = \\dfrac{1}{k[A]_0}', desc:'Depends on initial concentration' },
      { name:'Arrhenius Equation', latex:'k = Ae^{-E_a/RT}', desc:'A = frequency factor; Ea = activation energy' },
      { name:'Temperature Ratio', latex:'\\ln\\dfrac{k_2}{k_1} = \\dfrac{E_a}{R}\\left(\\dfrac{1}{T_1} - \\dfrac{1}{T_2}\\right)', desc:'Relates rate constants at two temperatures' },
    ]},

    // ══════════════════════════════════════════════
    // MATHEMATICS
    // ══════════════════════════════════════════════

    { id:'cn', subject:'mathematics', wt:4, name:'Complex Numbers', items:[
      { name:'Modulus', latex:'|z| = \\sqrt{a^2 + b^2},\\quad z = a + ib', desc:'Distance from origin in Argand plane' },
      { name:'Conjugate Product', latex:'z \\cdot \\bar{z} = |z|^2', desc:'Always real and non-negative' },
      { name:'Euler\'s Formula', latex:'e^{i\\theta} = \\cos\\theta + i\\sin\\theta', desc:'Fundamental link between complex and trig' },
      { name:'De Moivre\'s Theorem', latex:'(\\cos\\theta + i\\sin\\theta)^n = \\cos n\\theta + i\\sin n\\theta', desc:'For integer n' },
      { name:'Cube Roots of Unity', latex:'\\omega = e^{2\\pi i/3};\\quad 1 + \\omega + \\omega^2 = 0', desc:'ω³ = 1; |ω| = 1' },
      { name:'nth Roots of Unity', latex:'z_k = e^{2\\pi ik/n},\\quad k = 0,1,\\ldots,n-1', desc:'Sum of all nth roots = 0' },
    ]},

    { id:'seq', subject:'mathematics', wt:3, name:'Sequences & Series', items:[
      { name:'AP nth Term', latex:'a_n = a + (n-1)d', desc:'a = first term; d = common difference' },
      { name:'AP Sum', latex:'S_n = \\dfrac{n}{2}[2a + (n-1)d] = \\dfrac{n}{2}(a + l)', desc:'l = last term' },
      { name:'GP nth Term', latex:'a_n = ar^{n-1}', desc:'r = common ratio' },
      { name:'GP Sum (finite)', latex:'S_n = \\dfrac{a(1-r^n)}{1-r}', desc:'For r ≠ 1' },
      { name:'GP Sum (infinite)', latex:'S_\\infty = \\dfrac{a}{1-r},\\quad |r| < 1', desc:'Converges only for |r| < 1' },
      { name:'Sum of Naturals', latex:'\\sum_{k=1}^n k = \\dfrac{n(n+1)}{2}', desc:'1+2+3+...+n' },
      { name:'Sum of Squares', latex:'\\sum_{k=1}^n k^2 = \\dfrac{n(n+1)(2n+1)}{6}', desc:'Memorise this' },
      { name:'Sum of Cubes', latex:'\\sum_{k=1}^n k^3 = \\left[\\dfrac{n(n+1)}{2}\\right]^2', desc:'Equals (sum of naturals)²' },
    ]},

    { id:'pnc', subject:'mathematics', wt:4, name:'Permutations & Combinations', items:[
      { name:'Permutation', latex:'^nP_r = \\dfrac{n!}{(n-r)!}', desc:'Ordered selection of r from n' },
      { name:'Combination', latex:'^nC_r = \\dfrac{n!}{r!(n-r)!}', desc:'Unordered selection of r from n' },
      { name:'Circular Permutation', latex:'(n-1)!', desc:'Distinct arrangements in a circle' },
      { name:'With Repetition', latex:'n^r', desc:'r selections from n with repetition allowed' },
      { name:'Pascal\'s Identity', latex:'^nC_r = ^{n-1}C_{r-1} + ^{n-1}C_r', desc:'Foundation of Pascal\'s triangle' },
      { name:'Derangement', latex:'D_n = n!\\sum_{k=0}^{n}\\dfrac{(-1)^k}{k!}', desc:'Arrangements where no element is in original position' },
    ]},

    { id:'prob', subject:'mathematics', wt:5, name:'Probability', items:[
      { name:'Classical Probability', latex:'P(A) = \\dfrac{n(A)}{n(S)}', desc:'Equally likely outcomes' },
      { name:'Addition Rule', latex:'P(A\\cup B) = P(A) + P(B) - P(A\\cap B)', desc:'For any two events' },
      { name:'Conditional Probability', latex:"P(A|B) = \\dfrac{P(A\\cap B)}{P(B)}", desc:'Probability of A given B occurred' },
      { name:'Multiplication Rule', latex:'P(A\\cap B) = P(A|B)\\cdot P(B)', desc:'For dependent events' },
      { name:"Bayes' Theorem", latex:"P(A_i|B) = \\dfrac{P(A_i)P(B|A_i)}{\\sum_j P(A_j)P(B|A_j)}", desc:'Reverse conditional probability' },
      { name:'Binomial Distribution', latex:'P(X=r) = ^nC_r p^r q^{n-r}', desc:'n trials, p = success prob, q = 1-p' },
      { name:'Binomial Mean & Var', latex:'E(X) = np,\\quad \\text{Var}(X) = npq', desc:'σ = √(npq)' },
    ]},

    { id:'diff', subject:'mathematics', wt:4, name:'Differentiation', items:[
      { name:'Power Rule', latex:'\\dfrac{d}{dx}(x^n) = nx^{n-1}', desc:'Most used rule' },
      { name:'Exponential', latex:'\\dfrac{d}{dx}(e^x) = e^x;\\quad \\dfrac{d}{dx}(a^x) = a^x\\ln a', desc:'' },
      { name:'Logarithm', latex:'\\dfrac{d}{dx}(\\ln x) = \\dfrac{1}{x};\\quad \\dfrac{d}{dx}(\\log_a x) = \\dfrac{1}{x\\ln a}', desc:'' },
      { name:'Trig Derivatives', latex:'\\dfrac{d}{dx}\\sin x = \\cos x;\\quad \\dfrac{d}{dx}\\cos x = -\\sin x;\\quad \\dfrac{d}{dx}\\tan x = \\sec^2 x', desc:'' },
      { name:'Product Rule', latex:'(uv)^\\prime = u^\\prime v + uv^\\prime', desc:'' },
      { name:'Quotient Rule', latex:'\\left(\\dfrac{u}{v}\\right)^\\prime = \\dfrac{u^\\prime v - uv^\\prime}{v^2}', desc:'' },
      { name:'Chain Rule', latex:'\\dfrac{d}{dx}f(g(x)) = f^\\prime(g(x))\\cdot g^\\prime(x)', desc:'Differentiate outer × derivative of inner' },
      { name:'Parametric', latex:'\\dfrac{dy}{dx} = \\dfrac{dy/dt}{dx/dt}', desc:'When x and y are functions of t' },
    ]},

    { id:'iint', subject:'mathematics', wt:5, name:'Indefinite Integration', items:[
      { name:'Power Rule', latex:'\\int x^n\\,dx = \\dfrac{x^{n+1}}{n+1} + C', desc:'n ≠ -1' },
      { name:'Standard Integrals', latex:'\\int e^x\\,dx = e^x + C;\\quad \\int \\dfrac{1}{x}\\,dx = \\ln|x| + C', desc:'' },
      { name:'Trig Integrals', latex:'\\int \\sin x\\,dx = -\\cos x;\\quad \\int \\cos x\\,dx = \\sin x;\\quad \\int \\sec^2 x\\,dx = \\tan x', desc:'' },
      { name:'Inverse Trig', latex:'\\int \\dfrac{dx}{\\sqrt{a^2-x^2}} = \\sin^{-1}\\dfrac{x}{a};\\quad \\int \\dfrac{dx}{x^2+a^2} = \\dfrac{1}{a}\\tan^{-1}\\dfrac{x}{a}', desc:'' },
      { name:'Integration by Parts', latex:'\\int u\\,dv = uv - \\int v\\,du', desc:'ILATE: Inverse, Log, Algebraic, Trig, Exponential' },
      { name:'\\int √(a²-x²)', latex:'\\int\\sqrt{a^2-x^2}\\,dx = \\dfrac{x}{2}\\sqrt{a^2-x^2} + \\dfrac{a^2}{2}\\sin^{-1}\\dfrac{x}{a} + C', desc:'Often in JEE' },
    ]},

    { id:'dint', subject:'mathematics', wt:5, name:'Definite Integration', items:[
      { name:'Odd/Even Functions', latex:'\\int_{-a}^{a}f(x)\\,dx = \\begin{cases}0 & f\\text{ odd}\\\\2\\int_0^a f & f\\text{ even}\\end{cases}', desc:'Check if f(-x) = -f(x) or f(-x) = f(x)' },
      { name:'King Property', latex:'\\int_a^b f(x)\\,dx = \\int_a^b f(a+b-x)\\,dx', desc:'Most powerful property — add both forms' },
      { name:'Half-period Property', latex:'\\int_0^{2a}f(x)\\,dx = 2\\int_0^a f(x)\\,dx \\text{ if } f(2a-x)=f(x)', desc:'' },
      { name:'Periodic Function', latex:'\\int_0^{nT}f(x)\\,dx = n\\int_0^T f(x)\\,dx', desc:'T = period of f' },
      { name:'Leibniz Rule', latex:'\\dfrac{d}{dt}\\int_{g(t)}^{h(t)}f(x)\\,dx = f(h)h^\\prime - f(g)g^\\prime', desc:'Differentiation under integral sign' },
      { name:"Wallis' Formula", latex:'\\int_0^{\\pi/2}\\sin^n x\\,dx = \\int_0^{\\pi/2}\\cos^n x\\,dx', desc:'Equal by King property; both use Wallis formula' },
    ]},

    { id:'cir', subject:'mathematics', wt:4, name:'Circles', items:[
      { name:'Standard Form', latex:'x^2 + y^2 = r^2', desc:'Center (0,0), radius r' },
      { name:'General Form', latex:'x^2+y^2+2gx+2fy+c=0', desc:'Center (-g,-f), radius √(g²+f²-c)' },
      { name:'Length of Tangent', latex:'L = \\sqrt{x_1^2+y_1^2-r^2}', desc:'From external point (x₁,y₁) to x²+y²=r²' },
      { name:'Tangent at Point', latex:'xx_1+yy_1 = r^2', desc:'Tangent at (x₁,y₁) on x²+y²=r²' },
      { name:'Chord of Contact', latex:'xx_1+yy_1 = r^2', desc:'Chord joining tangent points from (x₁,y₁)' },
      { name:'Condition of Tangency', latex:'c^2 = a^2(1+m^2)', desc:'Line y=mx+c tangent to x²+y²=a²' },
    ]},

    { id:'para', subject:'mathematics', wt:4, name:'Parabola', items:[
      { name:'Standard Parabola', latex:'y^2 = 4ax', desc:'Focus (a,0); directrix x=-a; vertex (0,0)' },
      { name:'Parametric Point', latex:'(at^2, 2at)', desc:'Any point on y²=4ax in terms of parameter t' },
      { name:'Tangent at Parameter t', latex:'ty = x + at^2', desc:'Tangent at (at²,2at) on y²=4ax' },
      { name:'Normal at Parameter t', latex:'y = -tx + 2at + at^3', desc:'Normal at (at²,2at)' },
      { name:'Chord of Contact', latex:'yy_1 = 2a(x+x_1)', desc:'From external point (x₁,y₁)' },
      { name:'Focal Chord', latex:'t_1 t_2 = -1', desc:'For any focal chord; SS\' = a(t-1/t)²' },
    ]},

    { id:'ell', subject:'mathematics', wt:4, name:'Ellipse', items:[
      { name:'Standard Ellipse', latex:'\\dfrac{x^2}{a^2}+\\dfrac{y^2}{b^2}=1,\\quad a>b', desc:'Foci on x-axis; a>b' },
      { name:'Relation', latex:'b^2 = a^2(1-e^2);\\quad c^2 = a^2-b^2', desc:'c = ae = distance from center to focus' },
      { name:'Foci & Directrix', latex:'\\text{Foci: }(\\pm c,0);\\quad \\text{Directrix: }x = \\pm \\dfrac{a}{e}', desc:'' },
      { name:'Sum of Focal Radii', latex:'SP + S^\\prime P = 2a', desc:'For any point P on the ellipse' },
      { name:'Area', latex:'\\text{Area} = \\pi ab', desc:'Both axes needed' },
      { name:'Tangent', latex:'\\dfrac{xx_1}{a^2}+\\dfrac{yy_1}{b^2}=1', desc:'At point (x₁,y₁) on ellipse' },
    ]},

    { id:'vec', subject:'mathematics', wt:4, name:'Vectors', items:[
      { name:'Dot Product', latex:'\\vec{a}\\cdot\\vec{b} = |a||b|\\cos\\theta = a_xb_x+a_yb_y+a_zb_z', desc:'Scalar result' },
      { name:'Cross Product Magnitude', latex:'|\\vec{a}\\times\\vec{b}| = |a||b|\\sin\\theta', desc:'Direction: right-hand rule' },
      { name:'Area of Triangle', latex:'\\text{Area} = \\dfrac{1}{2}|\\vec{a}\\times\\vec{b}|', desc:'Half of parallelogram area' },
      { name:'Scalar Triple Product', latex:'[\\vec{a}\\,\\vec{b}\\,\\vec{c}] = \\vec{a}\\cdot(\\vec{b}\\times\\vec{c})', desc:'Volume of parallelepiped; zero if coplanar' },
      { name:'Projection', latex:'\\text{proj}_{\\vec{b}}\\vec{a} = \\dfrac{\\vec{a}\\cdot\\vec{b}}{|\\vec{b}|}', desc:'Length of a along b' },
    ]},

    { id:'trig', subject:'mathematics', wt:4, name:'Trigonometry', items:[
      { name:'Pythagorean Identities', latex:'\\sin^2\\theta+\\cos^2\\theta=1;\\quad 1+\\tan^2\\theta=\\sec^2\\theta;\\quad 1+\\cot^2\\theta=\\csc^2\\theta', desc:'' },
      { name:'Double Angle', latex:'\\sin 2\\theta = 2\\sin\\theta\\cos\\theta;\\quad \\cos 2\\theta = \\cos^2\\theta-\\sin^2\\theta = 1-2\\sin^2\\theta', desc:'' },
      { name:'Sum to Product', latex:'\\sin A+\\sin B = 2\\sin\\dfrac{A+B}{2}\\cos\\dfrac{A-B}{2}', desc:'PROSTHAPHAERESIS' },
      { name:'Sine Rule', latex:'\\dfrac{a}{\\sin A}=\\dfrac{b}{\\sin B}=\\dfrac{c}{\\sin C}=2R', desc:'R = circumradius' },
      { name:'Cosine Rule', latex:'a^2 = b^2+c^2-2bc\\cos A', desc:'Use when 2 sides + included angle known' },
      { name:'t-Substitution', latex:'\\sin\\theta=\\dfrac{2t}{1+t^2};\\quad \\cos\\theta=\\dfrac{1-t^2}{1+t^2};\\quad t=\\tan\\dfrac{\\theta}{2}', desc:'Converts trig to rational; useful in integration' },
    ]},

    { id:'3d', subject:'mathematics', wt:4, name:'3D Geometry', items:[
      { name:'Distance Formula', latex:'d = \\sqrt{(x_2-x_1)^2+(y_2-y_1)^2+(z_2-z_1)^2}', desc:'' },
      { name:'Direction Cosines', latex:'l^2+m^2+n^2=1;\\quad l=\\cos\\alpha,\\,m=\\cos\\beta,\\,n=\\cos\\gamma', desc:'α,β,γ = angles with x,y,z axes' },
      { name:'Line (symmetric)', latex:'\\dfrac{x-x_1}{l}=\\dfrac{y-y_1}{m}=\\dfrac{z-z_1}{n}', desc:'(x₁,y₁,z₁) = point; (l,m,n) = direction' },
      { name:'Plane Equation', latex:'ax+by+cz+d=0', desc:'Normal = (a,b,c)' },
      { name:'Point-to-Plane Distance', latex:'d = \\dfrac{|ax_0+by_0+cz_0+d|}{\\sqrt{a^2+b^2+c^2}}', desc:'' },
      { name:'Angle Between Planes', latex:'\\cos\\theta = \\dfrac{|a_1a_2+b_1b_2+c_1c_2|}{\\sqrt{a_1^2+b_1^2+c_1^2}\\cdot\\sqrt{a_2^2+b_2^2+c_2^2}}', desc:'' },
    ]},
  ];

  // ── FORMULA LIBRARY CLASS ─────────────────────────────────
  class FormulaLibrary {
    constructor() {
      this._data = FORMULA_DATA;
      this._flat = []; // flat list of all individual formulas
      this._buildFlat();
    }

    _buildFlat() {
      this._data.forEach(ch => {
        ch.items.forEach((item, idx) => {
          this._flat.push({ ...item, chapter: ch.id, chapterName: ch.name, subject: ch.subject, wt: ch.wt, uid: `${ch.id}_${idx}` });
        });
      });
    }

    /** Get all formulas for a chapter */
    getByChapter(chapterId) {
      return this._data.find(c => c.id === chapterId) || null;
    }

    /** Get all chapters for a subject */
    getBySubject(subject) {
      return this._data.filter(c => c.subject === subject);
    }

    /** Search by name or description */
    search(query) {
      const q = query.toLowerCase();
      return this._flat.filter(f =>
        f.name.toLowerCase().includes(q) ||
        f.desc.toLowerCase().includes(q) ||
        f.chapterName.toLowerCase().includes(q)
      );
    }

    /** High-weightage chapters only (wt >= 4) */
    getSummarySheet() {
      return this._data.filter(c => c.wt >= 4);
    }

    /** All individual formula objects in a flat list */
    getAll() { return this._flat; }

    /** Total count */
    get count() { return this._flat.length; }

    /** Chapter count */
    get chapterCount() { return this._data.length; }
  }

  // ── EXPORTS ───────────────────────────────────────────────
  global.FormulaLibrary = FormulaLibrary;
  global.JEE_FORMULAS_RAW = FORMULA_DATA;

})(typeof window !== 'undefined' ? window : this);
