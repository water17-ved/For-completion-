/**
 * JEE AI Core — Phase 3: Communication + Request Layer
 * ═══════════════════════════════════════════════════════
 *
 * Components:
 *   EngineRegistry   — unified access to all Phase 1+2 engines
 *   ContextBuilder   — intent detection + lean context packaging
 *   RequestManager   — gatekeeper for ALL Gemini calls
 *   DevMonitor       — request audit log + rate limit tracker
 *   JEEAICore v2     — full facade wiring everything together
 *
 * Architecture enforced:
 *   UI → JEEAICore → ContextBuilder → RequestManager → Gemini
 *   Never: scattered fetch() calls, duplicate requests, polling
 *
 * Requires: jee-engines.js, jee-formulas.js, jee-quizbank.js
 * Optional: jee-josaa.js (real JoSAA cutoffs; load it before this file)
 */
(function (global) {
  'use strict';

  // ── Re-use EventBus from Phase 1 ────────────────────────
  const Bus = global.JEEEventBus || (() => {
    const h = {};
    return {
      on(e,f){(h[e]=h[e]||[]).push(f)},
      off(e,f){h[e]=(h[e]||[]).filter(x=>x!==f)},
      emit(e,d){(h[e]||[]).forEach(f=>{try{f(d)}catch(x){}})},
      once(e,f){const w=d=>{f(d);this.off(e,w)};this.on(e,w)}
    };
  })();

  // ═══════════════════════════════════════════════════════
  // ENGINE REGISTRY
  // Central store for all engines. Single source of truth.
  // ═══════════════════════════════════════════════════════
  class EngineRegistry {
    constructor() {
      this._engines  = {};   // name → engine instance
      this._cache    = {};   // name → { data, ts }
      this._TTL      = 30000; // cache TTL: 30s
    }

    /** Register an engine under a name */
    register(name, engine) {
      this._engines[name] = engine;
      Bus.emit('registry:registered', { name });
      return this;
    }

    /** Get engine instance */
    get(name) {
      return this._engines[name] || null;
    }

    /** Query an engine, using cache if fresh */
    query(name, ...args) {
      const eng = this._engines[name];
      if (!eng) return null;

      const cached = this._cache[name];
      const now    = Date.now();
      if (cached && (now - cached.ts) < this._TTL && !args.length) {
        return cached.data;
      }

      const result = eng.query ? eng.query(...args) : null;
      if (result !== null) this._cache[name] = { data: result, ts: now };
      return result;
    }

    /** Invalidate cache for one or all engines */
    invalidate(name) {
      if (name) delete this._cache[name];
      else this._cache = {};
      Bus.emit('registry:invalidated', { name: name || 'all' });
    }

    /** Check all engine readiness */
    status() {
      return Object.fromEntries(
        Object.entries(this._engines).map(([k, e]) => [k, {
          ready: e.isReady ?? true,
          lastUpdated: e.lastUpdated ?? null
        }])
      );
    }

    /** Get raw engine output (bypass cache) */
    fresh(name, ...args) {
      this.invalidate(name);
      return this.query(name, ...args);
    }
  }

  // ═══════════════════════════════════════════════════════
  // INTENT CLASSIFIER
  // Classifies user message into one of 8 intents.
  // Pure regex — zero API calls.
  // ═══════════════════════════════════════════════════════
  const INTENTS = {
    rank_query:       /\b(rank|percentile|cut-?offs?|josaa|counsell?ing|which (college|nit|iit)s?|colleges?|nits?|iits?|iiits?|iit eligib\w*)\b|\bair\s*#?\d/i,
    test_analysis:    /my (score|marks|result|test|exam|mock)|analy[sz]e[^.?!\n]{0,20}\b(mock|test)s?\b|\b(last|latest|recent) (mock|test)|mock (test )?(analysis|trend|result)|test analysis/i,
    study_tonight:    /study tonight|what (to|should) (study|revise) (today|tonight|now)|revision (queue|list|today)/i,
    weakness:         /weak(er|ness|est)?|struggling|trouble with|not getting|can.t understand|always (wrong|fail)/i,
    quiz_request:     /\b(mcq|quiz|practice|question|test me|give me (a|some) q)/i,
    study_plan:       /plan|schedule|timetable|roadmap|how (many|much) (days?|months?|time)/i,
    formula_lookup:   /formula|equation|formula for|write (the|down) formula/i,
    concept_doubt:    /explain|what is|how does|how do|derive|proof|concept|define/i,
  };

  function classifyIntent(msg) {
    for (const [intent, pattern] of Object.entries(INTENTS)) {
      if (pattern.test(msg)) return intent;
    }
    return 'general_doubt';
  }


  // ═══════════════════════════════════════════════════════
  // RANK-QUERY PARSER (for JoSAA local answers)
  // Pulls rank / category / exam / institute / branch out of a
  // free-text message. Pure regex, zero API calls. Conservative:
  // if it is not clearly a college question, it returns no rank
  // so the message falls through to Gemini as before.
  // ═══════════════════════════════════════════════════════
  const COLLEGE_WORDS = /\b(colleges?|nits?|iits?|iiits?|josaa|branch(es)?|admission|counsell?ing|cut-?offs?|seat|chances?|jee|obc|ews|general|category|crl|air)\b/i;
  const PROGRAM_ALIASES = [
    [/\b(cse|computer science|computer engineering)\b/i, 'computer science'],
    [/\b(ece|electronics and communication|electronics & communication)\b/i, 'electronics and communication'],
    [/\b(eee|electrical and electronics)\b/i, 'electrical and electronics'],
    [/\b(electrical)\b/i, 'electrical'],
    [/\b(mechanical|mech)\b/i, 'mechanical'],
    [/\b(civil)\b/i, 'civil'],
    [/\b(chemical engineering|chem engg)\b/i, 'chemical engineering'],
    [/\b(aerospace|aero)\b/i, 'aerospace'],
    [/\b(engineering physics)\b/i, 'engineering physics'],
    [/\b(mnc|maths? (and|&) computing|mathematics (and|&) computing)\b/i, 'mathematics and computing'],
  ];
  // Common shorthand → text found in the JoSAA institute name
  const INSTITUTE_ALIASES = {
    trichy: 'tiruchirappalli', nitt: 'tiruchirappalli', tiruchi: 'tiruchirappalli',
    mumbai: 'bombay', iitb: 'bombay', chennai: 'madras', iitm: 'madras',
    iitd: 'iit delhi', iitk: 'kanpur', kgp: 'kharagpur', iitkgp: 'kharagpur', iitr: 'roorkee',
    nitk: 'surathkal', nitw: 'warangal', nitr: 'rourkela', nitc: 'calicut',
    mnnit: 'allahabad', prayagraj: 'allahabad', vnit: 'nagpur', mnit: 'jaipur',
    bhu: 'bhu', ism: 'ism', dhanbad: 'ism', varanasi: 'bhu',
  };

  function parseRankQuery(msg, josaa) {
    const text = String(msg || '');
    const out = { rank: null, category: null, exam: null, institutes: [], program: null, isCollegeQuestion: COLLEGE_WORDS.test(text) };

    // rank: "rank 5000", "AIR 850", "12,000 rank", "rank of 5k"
    const num = '(\\d{1,3}(?:,\\d{3})+|\\d+(?:\\.\\d+)?)\\s*(k|lakh|l)?';
    const tail = '(?![\\w^×*/])';
    const m = text.match(new RegExp('\\b(?:rank|air|crl)\\s*(?:is|of|=|:|-|around|about|approx\\.?|~)?\\s*#?\\s*' + num + tail, 'i'))
           || text.match(new RegExp('\\b' + num + tail + '\\s*(?:rank|air|crl)\\b', 'i'));
    if (m && out.isCollegeQuestion) {
      let v = parseFloat(m[1].replace(/,/g, ''));
      const suf = (m[2] || '').toLowerCase();
      if (suf === 'k') v *= 1000; else if (suf === 'lakh' || suf === 'l') v *= 100000;
      v = Math.round(v);
      if (v >= 1 && v <= 1500000) out.rank = v;
    }

    // category (default handled by caller)
    if (/\bobc([- ]?ncl)?\b/i.test(text)) out.category = 'OBC-NCL';
    else if (/\bews\b/i.test(text)) out.category = 'EWS';
    else if (/\bsc\b/i.test(text)) out.category = 'SC';
    else if (/\bst\b/i.test(text)) out.category = 'ST';
    else if (/\b(general|gen|open|ur|unreserved)\b/i.test(text)) out.category = 'OPEN';

    // exam: IIT ranks are JEE Advanced ranks, NIT ranks are JEE Main ranks
    const adv  = /\b(advanced|adv|iits?)\b/i.test(text);
    const main = /\b(main|mains|nits?|iiits?|gfti|cfti|cfis?)\b/i.test(text);
    if (adv && !main) out.exam = 'advanced';
    else if (main && !adv) out.exam = 'main';

    // program
    const pa = PROGRAM_ALIASES.find(([re]) => re.test(text));
    if (pa) out.program = pa[1];

    // institute(s)
    if (josaa && josaa.institutes) {
      const low = text.toLowerCase();
      const wantIIT = /\biits?\b/i.test(text), wantNIT = /\bnits?\b/i.test(text);
      const names = josaa.institutes();
      const hits = new Set();
      names.forEach(name => {
        const n = name.toLowerCase();
        const core = (n.split(',').pop() || n).replace(/^(iit|nit|malaviya nit|maulana azad nit|motilal nehru nit|vnit)\s*/,'').trim();
        const keys = [n];
        if (core.length >= 4) keys.push(core);
        keys.forEach(k => { if (new RegExp('\\b' + k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b').test(low)) hits.add(name); });
      });
      Object.keys(INSTITUTE_ALIASES).forEach(a => {
        if (new RegExp('\\b' + a + '\\b').test(low)) {
          const target = INSTITUTE_ALIASES[a];
          names.forEach(name => { if (name.toLowerCase().includes(target)) hits.add(name); });
        }
      });
      let list = [...hits];
      if (list.length > 1) {   // e.g. "delhi" matches IIT Delhi and NIT Delhi
        if (wantIIT && !wantNIT) { const f = list.filter(x => /^IIT/i.test(x)); if (f.length) list = f; }
        if (wantNIT && !wantIIT) { const f = list.filter(x => !/^IIT/i.test(x)); if (f.length) list = f; }
      }
      out.institutes = list.slice(0, 4);
    }
    return out;
  }

  const CAT_FROM_ESTIMATOR = { general: 'OPEN', obc: 'OBC-NCL', sc: 'SC', st: 'ST', ews: 'EWS' };
  const JOSAA_NOTE = 'Based on JoSAA 2024 final-round closing ranks (IIT: All-India quota with JEE Advanced rank; NIT: Other-State quota with JEE Main rank; gender-neutral). Past cutoffs do not guarantee future ones.';

  /** Bucketed college chances for a rank; capped so the answer stays small. */
  function josaaChances(josaa, { rank, category, exam, program, cap = {} }) {
    const types = exam === 'advanced' ? ['IIT'] : ['NIT', 'CFI'];
    const pick = { safe: [], likely: [], borderline: [], reach: [] };
    types.forEach(type => {
      const r = josaa.chances({ rank, category, type });
      Object.keys(pick).forEach(k => pick[k].push(...r[k]));
    });
    const pf = program ? (c => c.program.toLowerCase().includes(program)) : (() => true);
    const trim = c => ({ institute: c.institute, program: c.program, type: c.type, orank: c.orank, crank: c.crank, chance: c.chance });
    const lim = { safe: 5, likely: 8, borderline: 5, reach: 3, ...cap };
    const counts = {}, res = {};
    Object.keys(pick).forEach(k => {
      const all = pick[k].filter(pf).sort((a, b) => a.crank - b.crank);
      counts[k] = all.length;
      // reach: nearest misses (largest closing rank) are the useful ones; others: most competitive first
      res[k] = (k === 'reach' ? all.slice(-lim[k]).reverse() : all.slice(0, lim[k])).map(trim);
    });
    return { counts, ...res };
  }

  function josaaCutoffs(josaa, { institutes, program, category, year = 2024, limit = 12 }) {
    let rows = [];
    const insts = institutes.length ? institutes : [''];
    insts.forEach(i => rows.push(...josaa.findCutoff({ institute: i, program: program || '', category, year })));
    rows.sort((a, b) => a.r - b.r);
    const total = rows.length;
    const prev = {};
    const insts2 = new Set(rows.map(r => r.i));
    josaa.findCutoff({ institute: '', program: program || '', category, year: year - 1 })
      .forEach(r => { prev[r.i + '|' + r.p] = r; });   // exact (institute, program) key, not substring
    const out = rows.slice(0, limit).map(r => {
      const p = prev[r.i + '|' + r.p];
      const trend = p ? (r.r - p.r) : null;
      return { institute: r.i, program: r.p, type: r.t, orank: r.o, crank: r.r, prevCrank: p ? p.r : null,
               trend: trend === null ? null : (trend > 50 ? 'easier' : trend < -50 ? 'harder' : 'stable') };
    });
    return { rows: out, total, institutes: [...insts2].length };
  }

  // ═══════════════════════════════════════════════════════
  // CONTEXT BUILDER
  // The intelligence layer between the user and Gemini.
  // Decides what data to send, or whether to answer locally.
  // ═══════════════════════════════════════════════════════
  class ContextBuilder {
    constructor(registry) {
      this._reg = registry;
    }

    /**
     * Build a context package for a user message.
     * Returns:
     *   { intent, canAnswerLocally, localAnswer, localType,
     *     engines: {}, sizeBytes, savedBytes }
     */
    build(userMessage) {
      const intent = classifyIntent(userMessage);
      const ctx    = { intent, canAnswerLocally: false, localAnswer: null, localType: null, engines: {} };

      switch (intent) {

        // ── Rank: JoSAA real data first, RankEstimator cache as fallback ──
        case 'rank_query': {
          const est    = this._reg.get('rank')?.cache;
          const josaa  = this._reg.get('josaa');
          const p      = parseRankQuery(userMessage, josaa);
          const asksColleges = /\b(colleges?|nits?|iits?|iiits?|branch(es)?|cut-?offs?|admission|chances?|josaa|counsell?ing)\b/i.test(userMessage);
          ctx.engines.rank = est;

          if (josaa) {
            const category = p.category || 'OPEN';
            const categoryAssumed = !p.category;

            // (a) explicit rank in the message
            if (p.rank) {
              const exam = p.exam || (est && est.exam) || null;
              if (!exam) {
                ctx.canAnswerLocally = true;
                ctx.localType = 'josaa_needs_exam';
                ctx.localAnswer = { rank: p.rank, question: 'Is ' + p.rank + ' your JEE Main rank (for NITs) or your JEE Advanced rank (for IITs)?' };
                break;
              }
              ctx.canAnswerLocally = true;
              ctx.localType = 'josaa_chances';
              ctx.localAnswer = { rank: p.rank, exam, category, categoryAssumed, program: p.program, source: 'message',
                                  year: 2024, ...josaaChances(josaa, { rank: p.rank, category, exam, program: p.program }), note: JOSAA_NOTE };
              break;
            }

            // (b) asking about a specific college / branch cutoff
            if (p.institutes.length || (p.program && p.isCollegeQuestion)) {
              const cut = josaaCutoffs(josaa, { institutes: p.institutes, program: p.program, category });
              if (cut.total) {
                ctx.canAnswerLocally = true;
                ctx.localType = 'josaa_cutoff';
                ctx.localAnswer = { category, categoryAssumed, institutes: p.institutes, program: p.program, year: 2024, ...cut, note: JOSAA_NOTE };
                break;
              }
            }

            // (c) no rank typed, but the student has a score-based estimate
            if (est && asksColleges) {
              const estCat = CAT_FROM_ESTIMATOR[est.category] || 'OPEN';
              ctx.canAnswerLocally = true;
              ctx.localType = 'josaa_chances';
              ctx.localAnswer = { rank: est.rank, exam: est.exam, category: estCat, categoryAssumed: false, program: p.program, source: 'score_estimate',
                                  year: 2024, ...josaaChances(josaa, { rank: est.rank, category: estCat, exam: est.exam, program: p.program }),
                                  note: JOSAA_NOTE + ' Rank is an estimate from your score.' };
              break;
            }
          }

          // legacy path: RankEstimator cache (also used when josaa is not loaded).
          // Only when the student is asking about THEIR rank — "rank of a matrix" must go to Gemini.
          const aboutMe = /\b(my|me|mine|i|i'm|i am)\b|percentile|\bscore\b|\bmarks\b/i.test(userMessage);
          if (est && (aboutMe || asksColleges)) {
            ctx.canAnswerLocally = true;
            ctx.localType = 'rank';
            ctx.localAnswer = {
              rank: est.rank,
              percentile: est.percentile,
              score: est.score,
              exam: est.exam,
              colleges: est.colleges,
              cutoffStatus: est.cutoffStatus
            };
          }
          break;
        }

        // ── Quiz: use local bank first ──
        case 'quiz_request': {
          const qbank = this._reg.get('quizbank');
          if (qbank) {
            const subjectHint = /physics/i.test(userMessage) ? 'physics'
              : /chemistry|chem/i.test(userMessage) ? 'chemistry'
              : /maths?|math/i.test(userMessage) ? 'mathematics'
              : undefined;
            const localQ = qbank.getUnseen({ subject: subjectHint, count: 1 });
            if (localQ.length) {
              ctx.canAnswerLocally = true;
              ctx.localType = 'quiz';
              ctx.localAnswer = localQ[0];
            }
          }
          ctx.engines.quizStats = this._reg.get('quizbank')?.getStats?.();
          break;
        }

        // ── Formula: local library ──
        case 'formula_lookup': {
          const lib = this._reg.get('formulas');
          if (lib) {
            const q = userMessage.replace(/formula|equation|for|write|the|down/gi,'').trim();
            const results = lib.search(q).slice(0, 3);
            if (results.length) {
              ctx.canAnswerLocally = true;
              ctx.localType = 'formulas';
              ctx.localAnswer = results;
            }
          }
          break;
        }

        // ── Study tonight: revision + weak + timer ──
        case 'study_tonight': {
          const rev = this._reg.get('revision');
          const wk  = this._reg.get('weak');
          const tmr = this._reg.get('timer');
          const syl = this._reg.get('syllabus');
          if (rev) {
            ctx.engines.dueToday    = rev.getToday().slice(0, 5);
            ctx.engines.overdue     = rev.getOverdue().slice(0, 3);
          }
          if (wk?.cache)  ctx.engines.weakPriority = wk.cache.priorityList?.slice(0, 5);
          if (tmr?.cache) ctx.engines.todayStudy   = tmr.cache.today;
          if (syl?.cache) ctx.engines.completion   = syl.cache.completion;
          break;
        }

        // ── Test analysis: score + weak + rank ──
        case 'test_analysis': {
          const sc  = this._reg.get('score');
          const wk  = this._reg.get('weak');
          const rnk = this._reg.get('rank');
          if (sc?.cache)  ctx.engines.score       = sc.cache;
          if (wk?.cache)  ctx.engines.weakAreas   = wk.cache.priorityList?.slice(0, 8);
          if (rnk?.cache) ctx.engines.rankData    = rnk.cache;
          break;
        }

        // ── Weakness: weak detector + revision ──
        case 'weakness': {
          const wk  = this._reg.get('weak');
          const rev = this._reg.get('revision');
          if (wk?.cache)  ctx.engines.weakAreas   = wk.cache;
          if (rev)        ctx.engines.overdue      = rev.getOverdue().slice(0, 5);
          break;
        }

        // ── Study plan: everything ──
        case 'study_plan': {
          const syl = this._reg.get('syllabus');
          const wk  = this._reg.get('weak');
          const rev = this._reg.get('revision');
          const tmr = this._reg.get('timer');
          if (syl?.cache) ctx.engines.syllabusCompletion = syl.cache.completion;
          if (syl?.cache) ctx.engines.nextChapters       = syl.cache.nextRecommended?.slice(0,5);
          if (wk?.cache)  ctx.engines.weakPriority       = wk.cache.priorityList?.slice(0,5);
          if (rev)        ctx.engines.revisionQueue      = rev.getToday().slice(0,5);
          if (tmr?.cache) ctx.engines.studyHabits        = { streak: tmr.cache.streak, weekly: tmr.cache.weekly };
          break;
        }

        // ── Default: minimal context ──
        default: {
          const wk = this._reg.get('weak');
          if (wk?.cache) ctx.engines.weakSummary = wk.cache.summary;
          break;
        }
      }

      // Strip nulls + measure size
      ctx.engines   = Object.fromEntries(Object.entries(ctx.engines).filter(([,v]) => v != null));
      ctx.sizeBytes = JSON.stringify(ctx).length;

      // Compare against full localStorage size
      try {
        const fullSize = new Blob([JSON.stringify(localStorage)]).size;
        ctx.savedBytes   = Math.max(0, fullSize - ctx.sizeBytes);
        ctx.savingPct    = fullSize > 0 ? Math.round((1 - ctx.sizeBytes / fullSize) * 100) : 0;
      } catch(e) {
        ctx.savedBytes = 0; ctx.savingPct = 0;
      }

      Bus.emit('context:built', { intent, sizeBytes: ctx.sizeBytes, canAnswerLocally: ctx.canAnswerLocally });
      return ctx;
    }
  }

  // ═══════════════════════════════════════════════════════
  // REQUEST MANAGER
  // The mandatory gatekeeper. ALL Gemini calls go through here.
  // Enforces every rule from the AI precautions document.
  // ═══════════════════════════════════════════════════════
  class RequestManager {
    constructor(limits = {}) {
      // Hard limits (configurable)
      this.limits = {
        maxPerSession:  limits.maxPerSession  ?? 50,
        maxPerMinute:   limits.maxPerMinute   ?? 15,
        maxRetries:     limits.maxRetries     ?? 2,
        maxInputChars:  limits.maxInputChars  ?? 12000,
        maxOutputTokens:limits.maxOutputTokens?? 2048,
      };

      this._busy        = false;
      this._abortCtrl   = null;
      this._log         = [];           // full audit log
      this._sessionCount= 0;
      this._minuteCount = 0;
      this._minuteWindowEnd = Date.now() + 60000;
      this._lastRequestId = null;
    }

    // ── Public API ─────────────────────────────────────────

    /** Send a request to Gemini. Returns streamed full text. */
    async send({ reason, systemPrompt, messages, apiKey, modelId, onChunk, streaming = true }) {
      this._enforceLimits(reason);

      const reqId = this._newId();
      this._lastRequestId = reqId;
      const entry = this._startLog(reqId, reason, modelId, messages);

      this._busy = true;
      this._abortCtrl = new AbortController();
      this._sessionCount++;
      this._minuteCount++;

      let attempt = 0;
      let lastErr = null;

      while (attempt <= this.limits.maxRetries) {
        attempt++;
        try {
          entry.attempts = attempt;
          const result = await this._callGemini({
            systemPrompt, messages, apiKey, modelId,
            onChunk, streaming,
            signal: this._abortCtrl.signal,
            maxTokens: this.limits.maxOutputTokens,
          });

          this._endLog(entry, 'success', result.length);
          return result;

        } catch (err) {
          lastErr = err;
          if (err.name === 'AbortError') {
            this._endLog(entry, 'cancelled');
            throw err;
          }
          if (err.message?.includes('429') && attempt <= this.limits.maxRetries) {
            // Rate limit: wait before retry (finite — not infinite)
            const wait = Math.pow(2, attempt) * 5000; // 10s, 20s
            entry.status = `retrying (${attempt}/${this.limits.maxRetries})`;
            Bus.emit('request:retrying', { reqId, attempt, waitMs: wait });
            await new Promise(r => setTimeout(r, wait));
            continue;
          }
          // Non-retriable error
          break;
        }
      }

      // All retries exhausted
      this._endLog(entry, 'failed', 0, lastErr?.message);
      throw lastErr;
    }

    /** Cancel the active request */
    abort() {
      if (!this._busy || !this._abortCtrl) return;
      this._abortCtrl.abort();
      Bus.emit('request:aborted', { reqId: this._lastRequestId });
    }

    /** Current status snapshot */
    status() {
      this._tickMinute();
      return {
        busy:             this._busy,
        sessionCount:     this._sessionCount,
        sessionRemaining: this.limits.maxPerSession - this._sessionCount,
        minuteCount:      this._minuteCount,
        minuteRemaining:  this.limits.maxPerMinute  - this._minuteCount,
        minuteResetsIn:   Math.max(0, Math.round((this._minuteWindowEnd - Date.now()) / 1000)),
        limits:           { ...this.limits },
      };
    }

    /** Full audit log */
    getLog() { return [...this._log]; }

    /** Latest N entries */
    getRecentLog(n = 10) { return this._log.slice(-n); }

    /** Reset session counters (for testing) */
    resetCounters() {
      this._sessionCount = 0;
      this._minuteCount  = 0;
      this._minuteWindowEnd = Date.now() + 60000;
    }

    // ── Private helpers ────────────────────────────────────

    _enforceLimits(reason) {
      if (this._busy) throw Object.assign(new Error('BUSY: Another request is active. Stop it before sending a new one.'), { code: 'BUSY' });

      this._tickMinute();
      if (this._sessionCount >= this.limits.maxPerSession)
        throw Object.assign(new Error(`SESSION_LIMIT: Reached ${this.limits.maxPerSession} requests this session.`), { code: 'SESSION_LIMIT' });
      if (this._minuteCount >= this.limits.maxPerMinute)
        throw Object.assign(new Error(`RATE_LIMIT: ${this.limits.maxPerMinute} requests/min limit hit. Resets in ${Math.round((this._minuteWindowEnd-Date.now())/1000)}s`), { code: 'RATE_LIMIT' });
    }

    _tickMinute() {
      if (Date.now() >= this._minuteWindowEnd) {
        this._minuteCount    = 0;
        this._minuteWindowEnd = Date.now() + 60000;
      }
    }

    _newId() {
      return `req_${Date.now().toString(36)}_${Math.random().toString(36).slice(2,6)}`;
    }

    _startLog(reqId, reason, modelId, messages) {
      const inputChars = JSON.stringify(messages).length;
      if (inputChars > this.limits.maxInputChars) {
        console.warn(`[RequestManager] Input ${inputChars} chars exceeds soft limit ${this.limits.maxInputChars}`);
      }
      const entry = {
        reqId, reason, modelId,
        startedAt: Date.now(),
        startedAtHuman: new Date().toLocaleTimeString(),
        status: 'active',
        attempts: 1,
        inputChars,
        outputChars: 0,
        durationMs: 0,
        error: null,
      };
      this._log.push(entry);
      Bus.emit('request:started', { ...entry });
      return entry;
    }

    _endLog(entry, status, outputChars = 0, error = null) {
      entry.status      = status;
      entry.outputChars = outputChars;
      entry.durationMs  = Date.now() - entry.startedAt;
      entry.error       = error;
      this._busy        = false;
      this._abortCtrl   = null;
      Bus.emit(`request:${status}`, { ...entry });
      Bus.emit('request:ended', { ...entry });
    }

    async _callGemini({ systemPrompt, messages, apiKey, modelId, onChunk, streaming, signal, maxTokens }) {
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${modelId}:streamGenerateContent?alt=sse&key=${encodeURIComponent(apiKey)}`;
      const body = {
        contents: messages.map(m => ({
          role: m.role === 'assistant' ? 'model' : 'user',
          parts: m.parts || [{ text: m.content }]
        })),
        systemInstruction: systemPrompt ? { parts: [{ text: systemPrompt }] } : undefined,
        generationConfig: { maxOutputTokens: maxTokens, temperature: 0.7 }
      };

      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal,
      });

      if (!res.ok) {
        let msg = `HTTP ${res.status}`;
        try { const j = await res.json(); msg = j.error?.message || msg; } catch(e){}
        throw new Error(msg);
      }

      // Stream the response
      const reader = res.body.getReader();
      const dec    = new TextDecoder();
      let full = '', buf = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const lines = buf.split('\n'); buf = lines.pop() || '';
        for (const line of lines) {
          if (!line.startsWith('data: ')) continue;
          const d = line.slice(6).trim(); if (!d) continue;
          try {
            const j = JSON.parse(d);
            const t = j.candidates?.[0]?.content?.parts?.[0]?.text || '';
            if (t) { full += t; if (onChunk) onChunk(full, t); }
          } catch(e) {}
        }
      }
      return full;
    }
  }

  // ═══════════════════════════════════════════════════════
  // DEV MONITOR
  // Real-time request log + rate limit display.
  // Attach to any DOM element to render.
  // ═══════════════════════════════════════════════════════
  class DevMonitor {
    constructor(requestManager) {
      this._rm   = requestManager;
      this._el   = null;

      Bus.on('request:started',   () => this.render());
      Bus.on('request:ended',     () => this.render());
      Bus.on('request:retrying',  () => this.render());
      Bus.on('request:aborted',   () => this.render());
      Bus.on('context:built',     () => this.render());
    }

    mount(el) {
      this._el = typeof el === 'string' ? document.getElementById(el) : el;
      this.render();
      return this;
    }

    render() {
      if (!this._el) return;
      const s = this._rm.status();
      const log = this._rm.getRecentLog(8).reverse();

      const statusColor = s.busy ? '#f87171' : '#10b981';
      const minPct   = Math.round((s.minuteCount / s.limits.maxPerMinute) * 100);
      const sessPct  = Math.round((s.sessionCount / s.limits.maxPerSession) * 100);

      this._el.innerHTML = `
        <div style="font-family:monospace;font-size:12px;background:#0a0a0a;color:#e5e5e5;padding:14px;border-radius:12px;border:1px solid rgba(255,255,255,0.08)">
          <div style="font-size:11px;font-weight:700;color:#888;letter-spacing:.5px;margin-bottom:10px">AI REQUEST MONITOR</div>

          <div style="display:flex;gap:14px;margin-bottom:12px;flex-wrap:wrap">
            <div>
              <div style="font-size:10px;color:#555;margin-bottom:2px">STATUS</div>
              <div style="color:${statusColor};font-weight:700">${s.busy ? '● ACTIVE' : '○ IDLE'}</div>
            </div>
            <div>
              <div style="font-size:10px;color:#555;margin-bottom:2px">THIS MINUTE</div>
              <div style="color:#a78bfa">${s.minuteCount} / ${s.limits.maxPerMinute}</div>
              <div style="width:80px;height:3px;background:#222;border-radius:2px;margin-top:3px">
                <div style="width:${minPct}%;height:100%;background:${minPct>80?'#f87171':'#7c3aed'};border-radius:2px"></div>
              </div>
            </div>
            <div>
              <div style="font-size:10px;color:#555;margin-bottom:2px">SESSION</div>
              <div style="color:#a78bfa">${s.sessionCount} / ${s.limits.maxPerSession}</div>
              <div style="width:80px;height:3px;background:#222;border-radius:2px;margin-top:3px">
                <div style="width:${sessPct}%;height:100%;background:${sessPct>80?'#f87171':'#7c3aed'};border-radius:2px"></div>
              </div>
            </div>
            <div>
              <div style="font-size:10px;color:#555;margin-bottom:2px">RESETS IN</div>
              <div style="color:#888">${s.minuteResetsIn}s</div>
            </div>
          </div>

          <div style="font-size:10px;color:#555;margin-bottom:6px">RECENT REQUESTS</div>
          ${log.length ? log.map(e => `
            <div style="display:flex;gap:8px;align-items:center;padding:4px 0;border-bottom:1px solid #1a1a1a">
              <span style="color:${e.status==='success'?'#10b981':e.status==='active'?'#f59e0b':e.status==='cancelled'?'#888':'#f87171'}">${
                {success:'✓',active:'↻',failed:'✗',cancelled:'⊘'}[e.status]||'?'}</span>
              <span style="color:#444;flex:0 0 60px">${e.startedAtHuman}</span>
              <span style="flex:1;color:#888;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${e.reason}</span>
              <span style="color:#555;flex:0 0 50px;text-align:right">${e.durationMs ? e.durationMs+'ms' : ''}</span>
              <span style="color:#333;flex:0 0 55px;text-align:right">${e.inputChars ? (e.inputChars/1000).toFixed(1)+'k in' : ''}</span>
            </div>
          `).join('') : '<div style="color:#333">No requests yet this session.</div>'}

          <div style="margin-top:8px;font-size:10px;color:#333">
            Limits: ${s.limits.maxPerMinute}/min · ${s.limits.maxPerSession}/session · ${s.limits.maxRetries} retries · ${(s.limits.maxInputChars/1000).toFixed(0)}k input chars
          </div>
        </div>`;
    }
  }

  // ═══════════════════════════════════════════════════════
  // JEE AI CORE v2 — Full System Facade
  // ═══════════════════════════════════════════════════════
  class JEEAICore {
    constructor(config = {}) {
      // Phase 1 engines
      this.score    = new (global.JEECore ? Object.getPrototypeOf(new global.JEECore()).constructor : Object)();
      try { const jee = new global.JEECore();
        this.score    = jee.score;
        this.rank     = jee.rank;
        this.syllabus = jee.syllabus;
        this.weak     = jee.weak;
        this.revision = jee.revision;
        this.timer    = jee.timer;
      } catch(e) {}

      // Phase 2 engines
      try { this.formulas = new global.FormulaLibrary(); } catch(e) {}
      try { this.quizbank = new global.LocalQuizBank();  } catch(e) {}

      // Real data
      try { this.josaa = new global.JoSAARankEngine(); } catch(e) {}

      // Phase 3
      this.registry = new EngineRegistry();
      this.requests = new RequestManager(config.limits || {});
      this.monitor  = new DevMonitor(this.requests);
      this.context  = new ContextBuilder(this.registry);
      this.bus      = Bus;

      this._apiKey  = config.apiKey  || '';
      this._modelId = config.modelId || 'gemini-3.5-flash';

      this._registerAll();
      this._wireEvents();
    }

    /** Register all engines in the registry */
    _registerAll() {
      if (this.score)    this.registry.register('score',    this.score);
      if (this.rank)     this.registry.register('rank',     this.rank);
      if (this.syllabus) this.registry.register('syllabus', this.syllabus);
      if (this.weak)     this.registry.register('weak',     this.weak);
      if (this.revision) this.registry.register('revision', this.revision);
      if (this.timer)    this.registry.register('timer',    this.timer);
      if (this.formulas) this.registry.register('formulas', this.formulas);
      if (this.quizbank) this.registry.register('quizbank', this.quizbank);
      if (this.josaa)    this.registry.register('josaa',    this.josaa);
    }

    /** Wire cross-engine event hooks */
    _wireEvents() {
      // Syllabus done → add to revision scheduler
      Bus.on('syllabus:updated', ({ chapterId, status }) => {
        if (status === 'done' && this.revision?.addChapters)
          this.revision.addChapters([chapterId]);
        this.registry.invalidate('syllabus');
      });

      // Score updated → invalidate rank cache so it gets recalculated
      Bus.on('score:updated', () => this.registry.invalidate('rank'));

      // Weak updated → invalidate context cache
      Bus.on('weak:updated', () => this.registry.invalidate('weak'));

      // Timer stopped → invalidate timer cache
      Bus.on('timer:stopped', () => this.registry.invalidate('timer'));
    }

    /** Configure API settings */
    configure({ apiKey, modelId, limits } = {}) {
      if (apiKey)  this._apiKey  = apiKey;
      if (modelId) this._modelId = modelId;
      if (limits)  Object.assign(this.requests.limits, limits);
    }

    /**
     * The main entry point for all AI requests.
     * Builds context → checks if local engines can answer →
     * only then calls Gemini.
     */
    async ask({ userMessage, systemPrompt, history = [], onChunk, reason }) {
      // 1. Build minimal context
      const ctx = this.context.build(userMessage);

      // 2. Can local engines answer this?
      if (ctx.canAnswerLocally) {
        Bus.emit('answer:local', { intent: ctx.intent, type: ctx.localType });
        return { source: 'local', intent: ctx.intent, data: ctx.localAnswer };
      }

      // Only Gemini needs a key — local answers above work without one
      if (!this._apiKey) throw new Error('NO_KEY: Set API key via core.configure({ apiKey })');

      // 3. Build messages for Gemini (context + history + user message)
      // Optional compact student profile (set by TrackerBridge.install) — sent with every Gemini call
      let profile = null;
      try { profile = this.profileProvider ? this.profileProvider() : null; } catch (e) { profile = null; }
      const profileBlock = profile ? `[Student profile from their tracker]\n${JSON.stringify(profile)}\n\n` : '';
      const contextBlock = profileBlock + (Object.keys(ctx.engines).length
        ? `[Student context from local tracking]\n${JSON.stringify(ctx.engines, null, 2)}\n\n`
        : '');

      const messages = [
        ...history.slice(-6), // last 6 messages only
        { role: 'user', content: contextBlock + userMessage }
      ];

      // 4. Send through Request Manager
      const fullText = await this.requests.send({
        reason:       reason || `${ctx.intent}: ${userMessage.slice(0, 60)}`,
        systemPrompt: systemPrompt,
        messages,
        apiKey:       this._apiKey,
        modelId:      this._modelId,
        onChunk,
      });

      return { source: 'gemini', intent: ctx.intent, text: fullText, context: ctx };
    }

    /** Mount the dev monitor to a DOM element */
    mountMonitor(elOrId) {
      return this.monitor.mount(elOrId);
    }

    /** Full system status */
    status() {
      return {
        engines:  this.registry.status(),
        requests: this.requests.status(),
        apiKey:   this._apiKey ? '✓ set' : '✗ not set',
        model:    this._modelId,
      };
    }
  }

  // ── Exports ──────────────────────────────────────────────
  global.JEEAICoreV2   = JEEAICore;
  global.RequestManager = RequestManager;
  global.ContextBuilder = ContextBuilder;
  global.EngineRegistry = EngineRegistry;
  global.DevMonitor     = DevMonitor;
  global.classifyIntent = classifyIntent;
  global.parseRankQuery = parseRankQuery;

})(typeof window !== 'undefined' ? window : this);
