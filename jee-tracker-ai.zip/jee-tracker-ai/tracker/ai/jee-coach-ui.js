/*!
 * jee-coach-ui.js — the "🧠 AI Coach" tab for the JEE Battle Royale Tracker
 * ═══════════════════════════════════════════════════════════════════════════
 * Mounts a chat + live dashboard into #ai-coach-root. Everything the tracker already knows
 * (checklist progress, chapter tests, mocks, revision dates, study hours, exam date) is read
 * through TrackerBridge — READ-ONLY, the tracker's data is never modified from here.
 *
 *   Local, zero-API answers : study plan for tonight, weak chapters, mock trend, quiz (978 PYQs),
 *                             formulas, JoSAA college chances / cutoffs
 *   Gemini (only when needed): doubts, concept explanations, study plans, anything else —
 *                             every call goes through RequestManager (limits + audit log)
 *
 * API key / model are stored in localStorage as jee_key / jee_model (underscore — the same keys
 * the standalone AI Tutor uses, and outside the tracker's "jee-" reset namespace).
 * Accessibility: screen-reader roles + live regions, keyboard/focus handling, 44px targets, reduced motion, text-size control,
 * voice input (Web Speech API) and read-aloud for replies. Also reachable from every tab via the floating button (see the launcher in index.html).
 * Public: JEECoachUI.mount(el), JEECoachUI.open({ sheet, tab })
 */
(function (global) {
  'use strict';

  var LS_KEY = 'jee_key', LS_MODEL = 'jee_model', LS_CHAT = 'jee_coach_chat';
  var MODELS = ['gemini-3.8-flash', 'gemini-3.7-flash', 'gemini-3.5-flash', 'gemini-3.5-flash-lite', 'gemini-3.1-flash-lite'];
  var SUBJ_COLOR = { physics: 'var(--phys,#22d3ee)', chemistry: 'var(--chem,#39ff88)', maths: 'var(--maths,#c77dff)', mathematics: 'var(--maths,#c77dff)' };
  var SYSTEM_PROMPT = 'You are a concise, encouraging JEE Main/Advanced coach inside the student\'s progress tracker. ' +
    'A "[Student profile from their tracker]" block holds their real data (days to exam, syllabus %, weak chapters, revision due, mock trend, study hours) — ' +
    'use it to personalise, never invent data that is not there, and say so if something is missing. ' +
    'Be specific and short: bullets, no filler. For maths/science use LaTeX with $...$ (inline) and $$...$$ (display). ' +
    'For doubts give the idea first, then the steps, then one common mistake to avoid.';

  var core = null, root = null, els = {}, msgs = [], busy = false, cardSeq = 0, quizzes = {}, katexState = 0, katexQueue = [];

  // ── tiny helpers ────────────────────────────────────────────────────────
  function ls(k, v) { try { if (v === undefined) return global.localStorage.getItem(k); global.localStorage.setItem(k, v); } catch (e) { return null; } }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function short(s, n) { s = String(s || ''); return s.length > n ? s.slice(0, n - 1).replace(/\s+\S*$/, '') + '…' : s; }
  function shortProgram(p) { return short(String(p || '').replace(/\s*\((?:\d+\s*Years?|Bachelor|B\.Tech|Integrated).*$/i, ''), 58); }
  function bridge() { return global.TrackerBridge; }
  function chapterName(engineId) { var t = bridge().toTrackerIds(engineId)[0]; var c = bridge().chapters().filter(function (x) { return x.id === t; })[0]; return c ? c.n : engineId; }
  function subjColor(s) { return SUBJ_COLOR[s] || 'var(--gold,#ff6a00)'; }

  // ── KaTeX (lazy, optional — raw LaTeX stays readable if the CDN is unreachable) ──
  function loadKatex(cb) {
    if (global.renderMathInElement) return cb();
    if (katexState === 2) return;                         // failed earlier — don't retry every message
    katexQueue.push(cb);
    if (katexState === 1) return;
    katexState = 1;
    var base = 'https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.9/';
    var css = document.createElement('link'); css.rel = 'stylesheet'; css.href = base + 'katex.min.css'; document.head.appendChild(css);
    function s(src, ok) { var el = document.createElement('script'); el.src = src; el.onload = ok; el.onerror = function () { katexState = 2; katexQueue = []; }; document.head.appendChild(el); }
    s(base + 'katex.min.js', function () { s(base + 'contrib/auto-render.min.js', function () { katexState = 3; var q = katexQueue; katexQueue = []; q.forEach(function (f) { f(); }); }); });
  }
  function typeset(el) {
    loadKatex(function () {
      try { global.renderMathInElement(el, { delimiters: [{ left: '$$', right: '$$', display: true }, { left: '$', right: '$', display: false }, { left: '\\(', right: '\\)', display: false }, { left: '\\[', right: '\\]', display: true }], throwOnError: false }); } catch (e) { /* ignore */ }
    });
  }

  // ── minimal markdown (bold, code, headings, lists) with math protected ────────
  function md(text) {
    var math = [];
    text = String(text || '').replace(/\$\$[\s\S]+?\$\$|\$[^$\n]+?\$|\\\([\s\S]+?\\\)|\\\[[\s\S]+?\\\]/g, function (m) { math.push(m); return '\u0000' + (math.length - 1) + '\u0000'; });
    text = esc(text);
    text = text.replace(/```(?:\w+)?\n?([\s\S]*?)```/g, function (_, c) { return '<pre>' + c.trim() + '</pre>'; });
    var out = [], list = null;
    function close() { if (list) { out.push('</' + list + '>'); list = null; } }
    text.split('\n').forEach(function (line) {
      var m;
      if ((m = line.match(/^\s*[-*•]\s+(.*)/))) { if (list !== 'ul') { close(); out.push('<ul>'); list = 'ul'; } out.push('<li>' + m[1] + '</li>'); }
      else if ((m = line.match(/^\s*\d+[.)]\s+(.*)/))) { if (list !== 'ol') { close(); out.push('<ol>'); list = 'ol'; } out.push('<li>' + m[1] + '</li>'); }
      else if ((m = line.match(/^\s*#{1,4}\s+(.*)/))) { close(); out.push('<h5>' + m[1] + '</h5>'); }
      else if (!line.trim()) { close(); }
      else { close(); out.push('<p>' + line + '</p>'); }
    });
    close();
    var html = out.join('').replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>').replace(/`([^`]+)`/g, '<code>$1</code>');
    return html.replace(/\u0000(\d+)\u0000/g, function (_, i) { return esc(math[+i]); });
  }

  // ── styles ────────────────────────────────────────────────────────────
  var CSS = '' +
    '.jc-wrap{display:flex;flex-direction:column;height:calc(100vh - 150px);height:calc(100dvh - 150px);min-height:430px;max-width:820px;margin:0 auto;font-family:var(--font-body,Roboto,sans-serif);color:var(--text-main,#f3ecff)}' +
    '.jc-top{display:flex;align-items:center;gap:8px;padding:2px 2px 8px}.jc-title{font-family:var(--font-display,Orbitron,sans-serif);font-size:1rem;letter-spacing:.5px;flex:1}' +
    '.jc-gear{background:var(--panel-bg,#170d20);border:1px solid var(--border,#3a2452);color:var(--text-main,#f3ecff);border-radius:10px;padding:6px 10px;font-size:1rem;cursor:pointer}' +
    '.jc-stats{display:flex;gap:6px;overflow-x:auto;padding-bottom:8px;scrollbar-width:none}.jc-stats::-webkit-scrollbar{display:none}' +
    '.jc-stat{flex:0 0 auto;background:var(--panel-bg,#170d20);border:1px solid var(--border,#3a2452);border-radius:12px;padding:6px 10px;font-size:.82rem;cursor:pointer;white-space:nowrap;color:var(--text-main,#f3ecff)}' +
    '.jc-stat b{color:var(--gold-bright,#ffcf3d);font-family:var(--font-accent,Rajdhani,sans-serif);font-size:1rem}' +
    '.jc-chat{flex:1;overflow-y:auto;-webkit-overflow-scrolling:touch;padding:4px 2px;display:flex;flex-direction:column;gap:10px}' +
    '.jc-msg{max-width:92%;padding:9px 12px;border-radius:14px;line-height:1.45;font-size:.95rem;word-wrap:break-word;overflow-wrap:anywhere}' +
    '.jc-msg.user{align-self:flex-end;background:linear-gradient(135deg,var(--gold,#ff6a00),var(--xp,#ff3d7d));color:#fff;border-bottom-right-radius:4px;white-space:pre-wrap}' +
    '.jc-msg.assistant{align-self:flex-start;background:var(--card-bg,#130b1a);border:1px solid var(--border,#3a2452);border-bottom-left-radius:4px}' +
    '.jc-wrap p,.jc-wrap li{color:var(--text-main,#f3ecff)}.jc-msg p{margin:0 0 6px}.jc-msg ul,.jc-msg ol{margin:4px 0 6px 18px;padding:0}.jc-msg h5{margin:8px 0 4px;color:var(--gold-bright,#ffcf3d);font-size:.95rem}' +
    '.jc-msg pre{background:#0008;padding:8px;border-radius:8px;overflow-x:auto;font-size:.8rem}.jc-msg code{background:#0006;padding:1px 4px;border-radius:4px}' +
    '.jc-msg.streaming::after{content:"▍";animation:jcblink 1s steps(2) infinite}@keyframes jcblink{50%{opacity:0}}' +
    '.jc-card{align-self:stretch;background:var(--card-bg,#130b1a);border:1px solid var(--border,#3a2452);border-radius:14px;padding:12px;font-size:.9rem}' +
    '.jc-card h4{margin:0 0 8px;font-family:var(--font-accent,Rajdhani,sans-serif);font-size:1.05rem;color:var(--gold-bright,#ffcf3d)}' +
    '.jc-sec{margin:8px 0 4px;font-size:.75rem;letter-spacing:.6px;text-transform:uppercase;color:var(--text-muted,#9a83b0)}' +
    '.jc-row{display:flex;gap:8px;align-items:flex-start;padding:6px 0;border-top:1px solid #ffffff10}.jc-row:first-of-type{border-top:0}' +
    '.jc-dot{flex:0 0 auto;width:8px;height:8px;border-radius:50%;margin-top:6px}.jc-rt{flex:1;min-width:0}.jc-rt small{display:block;color:var(--text-muted,#9a83b0);font-size:.78rem}' +
    '.jc-bar{height:5px;border-radius:9px;background:#ffffff14;margin-top:5px;overflow:hidden}.jc-bar i{display:block;height:100%;background:linear-gradient(90deg,var(--gold,#ff6a00),var(--xp,#ff3d7d))}' +
    '.jc-btns{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px}' +
    '.jc-btn{background:var(--panel-bg,#170d20);border:1px solid var(--border,#3a2452);color:var(--text-main,#f3ecff);border-radius:10px;padding:7px 11px;font-size:.83rem;cursor:pointer;font-family:inherit}' +
    '.jc-btn.pri{background:linear-gradient(135deg,var(--gold,#ff6a00),var(--xp,#ff3d7d));border-color:transparent;color:#fff;font-weight:700}.jc-btn:disabled{opacity:.45}' +
    '.jc-btn.sm{padding:4px 8px;font-size:.75rem}' +
    '.jc-pills{display:flex;flex-wrap:wrap;gap:6px;margin:4px 0 6px}.jc-pill{border-radius:999px;padding:2px 9px;font-size:.75rem;border:1px solid var(--border,#3a2452)}' +
    '.jc-pill.safe{color:#39ff88;border-color:#39ff8866}.jc-pill.likely{color:#22d3ee;border-color:#22d3ee66}.jc-pill.borderline{color:#ffcf3d;border-color:#ffcf3d66}.jc-pill.reach{color:#ff6a8d;border-color:#ff6a8d66}' +
    '.jc-note{margin-top:8px;color:var(--text-muted,#9a83b0);font-size:.75rem;line-height:1.35}' +
    '.jc-opt{display:block;width:100%;text-align:left;margin:6px 0;padding:9px 11px;border-radius:10px;background:var(--panel-bg,#170d20);border:1px solid var(--border,#3a2452);color:var(--text-main,#f3ecff);font-size:.9rem;cursor:pointer;font-family:inherit}' +
    '.jc-opt.ok{border-color:#39ff88;background:#39ff8818}.jc-opt.bad{border-color:#ff1a5e;background:#ff1a5e18}.jc-opt:disabled{cursor:default}' +
    '.jc-sol{margin-top:8px;padding:9px;border-radius:10px;background:#0006;font-size:.88rem}.jc-q{font-size:.95rem;line-height:1.5;margin:6px 0}' +
    '.jc-numin{width:100%;box-sizing:border-box;margin:6px 0;padding:9px;border-radius:10px;border:1px solid var(--border,#3a2452);background:var(--panel-bg,#170d20);color:var(--text-main,#f3ecff);font-size:1rem}' +
    '.jc-table{width:100%;border-collapse:collapse;font-size:.8rem}.jc-table td,.jc-table th{padding:5px 4px;border-top:1px solid #ffffff10;text-align:left;vertical-align:top}.jc-table th{color:var(--text-muted,#9a83b0);font-weight:600}' +
    '.jc-chips{display:flex;gap:6px;overflow-x:auto;padding:8px 0 6px;scrollbar-width:none}.jc-chips::-webkit-scrollbar{display:none}' +
    '.jc-chip{flex:0 0 auto;background:var(--panel-bg,#170d20);border:1px solid var(--border,#3a2452);color:var(--text-main,#f3ecff);border-radius:999px;padding:6px 12px;font-size:.82rem;cursor:pointer;white-space:nowrap;font-family:inherit}' +
    '.jc-input{display:flex;gap:8px;align-items:flex-end}.jc-input textarea{flex:1;resize:none;max-height:120px;min-height:42px;box-sizing:border-box;border-radius:12px;border:1px solid var(--border,#3a2452);background:var(--panel-bg,#170d20);color:var(--text-main,#f3ecff);padding:10px 12px;font-size:1rem;font-family:inherit;line-height:1.35}' +
    '.jc-send{flex:0 0 auto;height:42px;padding:0 16px;border-radius:12px;border:0;background:linear-gradient(135deg,var(--gold,#ff6a00),var(--xp,#ff3d7d));color:#fff;font-weight:800;font-size:1rem;cursor:pointer}.jc-send:disabled{opacity:.5}' +
    '.jc-set{display:none;background:var(--card-bg,#130b1a);border:1px solid var(--border,#3a2452);border-radius:14px;padding:12px;margin-bottom:8px;font-size:.88rem}.jc-set.open{display:block}' +
    '.jc-set label{display:block;margin:8px 0 4px;color:var(--text-muted,#9a83b0);font-size:.78rem}.jc-set input,.jc-set select{width:100%;box-sizing:border-box;padding:8px;border-radius:9px;border:1px solid var(--border,#3a2452);background:var(--panel-bg,#170d20);color:var(--text-main,#f3ecff);font-size:.9rem}' +
    '.jc-mon{margin-top:10px;max-height:240px;overflow:auto}.jc-loading{padding:30px;text-align:center;color:var(--text-muted,#9a83b0)}';

  // Text-size control: every rem in the coach CSS is multiplied by --jc-fs (set on the root element)
  CSS = CSS.replace(/(\d*\.?\d+)rem/g, 'calc($1rem*var(--jc-fs,1))') +
    '.jc-wrap button:focus-visible,.jc-wrap textarea:focus-visible,.jc-wrap input:focus-visible,.jc-wrap select:focus-visible,.jc-wrap a:focus-visible{outline:3px solid var(--gold-bright,#ffcf3d);outline-offset:2px}' +
    '.jc-btn{display:inline-flex;align-items:center;justify-content:center}.jc-chip,.jc-btn,.jc-stat,.jc-opt,.jc-gear,.jc-mic{min-height:44px}.jc-btn.sm{min-height:36px}.jc-gear,.jc-mic{min-width:44px}' +
    '.jc-mic{flex:0 0 auto;height:42px;border-radius:12px;border:1px solid var(--border,#3a2452);background:var(--panel-bg,#170d20);color:var(--text-main,#f3ecff);font-size:1.15rem;cursor:pointer}' +
    '.jc-mic.rec{background:#ff1a5e;border-color:#ff1a5e;color:#fff}' +
    '.jc-tag{font-weight:700;margin-left:6px}.jc-sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}' +
    '.jc-fsrow{display:flex;gap:8px;align-items:center;margin-top:6px}.jc-fsrow output{min-width:48px;text-align:center}' +
    '.jc-chk{display:flex;gap:8px;align-items:center;margin-top:10px;color:var(--text-main,#f3ecff)}.jc-set .jc-chk input{width:auto}' +
    '@media (prefers-reduced-motion:reduce){.jc-msg.streaming::after{animation:none}.jc-wrap *{scroll-behavior:auto!important;transition:none!important}}';

  // ── card renderers (return HTML strings) ────────────────────────────────
  function btn(label, act, attrs, cls) {
    var a = ''; Object.keys(attrs || {}).forEach(function (k) { a += ' data-' + k + '="' + esc(attrs[k]) + '"'; });
    return '<button class="jc-btn ' + (cls || '') + '" data-act="' + act + '"' + a + '>' + label + '</button>';
  }
  function row(c, sub, pct) {
    return '<div class="jc-row"><span class="jc-dot" aria-hidden="true" style="background:' + subjColor(c.subject) + '"></span><div class="jc-rt"><b>' + esc(c.name) + '</b><small>' + esc(sub) + '</small>' +
      (pct != null ? '<div class="jc-bar" aria-hidden="true"><i style="width:' + Math.max(3, Math.min(100, pct)) + '%"></i></div>' : '') + '</div></div>';
  }
  function bankHas(engineId) { var b = core.quizbank; return !!(b && b.questions.some(function (q) { return q.ch === engineId && q.t === 'mcq'; })); }
  function quizIdFor(c) { for (var i = 0; i < c.engineIds.length; i++) if (bankHas(c.engineIds[i])) return c.engineIds[i]; return null; }

  function planCard(s) {
    if (!s.hasData) return '<div class="jc-card"><h4>📅 Tonight\'s plan</h4>Your tracker is empty so far — tick a few checklist items or log a chapter test and this plan fills itself in.</div>';
    var h = '<div class="jc-card"><h4>📅 Tonight\'s plan</h4>';
    if (s.revisionDue.length) { h += '<div class="jc-sec">🔁 Revise first</div>'; s.revisionDue.slice(0, 3).forEach(function (c) { h += row(c, 'Completed ' + c.revisionDueDays + ' days ago, never retested'); }); }
    if (s.weak.length) { h += '<div class="jc-sec">🎯 Fix the weak spots</div>'; s.weak.slice(0, 3).forEach(function (c) { h += row(c, c.weakReason, c.weakScore / 2); }); }
    var cont = s.chapters.filter(function (c) { return c.pct > 0 && c.pct < 90; }).sort(function (a, b) { return b.pct - a.pct; }).slice(0, 2);
    if (cont.length) { h += '<div class="jc-sec">▶ Keep going</div>'; cont.forEach(function (c) { h += row(c, c.pct + '% of checklist done', c.pct); }); }
    if (!s.revisionDue.length && !s.weak.length && !cont.length) h += 'Nothing is flagged right now — start the next chapter on your list.';
    h += '<div class="jc-note">Studied today: <b>' + s.study.hoursToday + ' h</b> · last 7 days: <b>' + s.study.hoursWeek + ' h</b>' + (s.exam.daysLeft !== null ? ' · ' + s.exam.daysLeft + ' days to exam' : '') + '</div>';
    h += '<div class="jc-btns">' + btn('✨ Turn into a timetable (AI)', 'gem', { text: 'Turn my study situation into a realistic timetable for tonight, using my weak chapters and revision-due list. I have about 3-4 hours.' }, 'pri');
    var w = s.weak[0] && quizIdFor(s.weak[0]); if (w) h += btn('🎯 Quiz: ' + short(s.weak[0].name, 22), 'quiz', { ch: w });
    return h + '</div></div>';
  }

  function weakCard(s) {
    if (!s.weak.length) return '<div class="jc-card"><h4>⚠ Weak chapters</h4>Nothing flagged yet. Log chapter tests in the Battle Log (with mistake types) and the tracker will rank your weak spots — the same ranking shows here.' +
      (s.selfWeakSubjects && s.selfWeakSubjects.length ? '<div class="jc-note">You marked ' + esc(s.selfWeakSubjects.join(', ')) + ' as weak subjects.</div>' : '') + '</div>';
    var h = '<div class="jc-card"><h4>⚠ Your weakest chapters</h4>';
    s.weak.slice(0, 6).forEach(function (c) {
      var q = quizIdFor(c), f = c.engineIds.filter(function (e) { return core.formulas && core.formulas.getByChapter && core.formulas.getByChapter(e); })[0];
      h += row(c, c.weakReason, c.weakScore / 2).replace(/<\/div><\/div>$/, '<div class="jc-btns" style="margin-top:6px">' +
        (q ? btn('Quiz', 'quiz', { ch: q }, 'sm') : '') + (f ? btn('Formulas', 'formulas', { ch: f }, 'sm') : '') + btn('Explain', 'gem', { text: 'Explain the key concepts and the most common mistakes in ' + c.name + ' for JEE, briefly.' }, 'sm') + '</div></div></div>');
    });
    return h + '<div class="jc-note">Ranked the same way as the tracker\'s Weak Spot Radar: test scores, mistake types and untested chapters.</div></div>';
  }

  function mockCard(s) {
    if (!s.mocks.length) return '<div class="jc-card"><h4>📊 Mock tests</h4>No scored mock tests yet. Log one in the Battle Log and I can show the trend and where you lose marks.</div>';
    var last = s.mocks.slice(-6), h = '<div class="jc-card"><h4>📊 Mock trend</h4>';
    last.forEach(function (m) { h += '<div class="jc-row"><div class="jc-rt"><b>' + esc(short(m.name, 26)) + '</b> <small style="display:inline">' + esc(m.date) + '</small><div class="jc-bar" aria-hidden="true"><i style="width:' + Math.max(3, m.pct) + '%"></i></div></div><b>' + m.pct + '%</b></div>'; });
    if (s.mockTrend !== null) h += '<div class="jc-note">Latest is <b>' + (s.mockTrend >= 0 ? '+' : '') + s.mockTrend + ' points</b> vs the average of the 3 before it.</div>';
    if (s.weak.length) h += '<div class="jc-sec">Biggest leaks</div>' + s.weak.slice(0, 3).map(function (c) { return row(c, c.weakReason); }).join('');
    return h + '<div class="jc-btns">' + btn('✨ Analyse my mocks (AI)', 'gem', { text: 'Analyse my mock test trend and weak chapters and tell me the 3 highest-impact things to change in the next two weeks.' }, 'pri') + '</div></div>';
  }

  function quizCard(q, id) {
    quizzes[id] = { q: q, done: false };
    var meta = chapterName(q.ch) + ' · ' + q.d + ' · ' + q.s;
    var h = '<div class="jc-card" data-card="' + id + '"><h4>🎯 ' + esc(short(meta, 60)) + '</h4><div class="jc-q">' + esc(q.q) + '</div>';
    if (q.t === 'num') h += '<input class="jc-numin" inputmode="decimal" placeholder="Your numerical answer" data-numin="' + id + '"><div class="jc-btns">' + btn('Check', 'num', { card: id }, 'pri') + '</div>';
    else q.opts.forEach(function (o, i) { h += '<button class="jc-opt" data-act="opt" data-card="' + id + '" data-i="' + i + '"><b>' + 'ABCD'[i] + '.</b> ' + esc(o) + '</button>'; });
    return h + '<div class="jc-fb" role="status" aria-live="polite"></div></div>';
  }
  function quizFeedback(cardEl, id, res, picked) {
    var qz = quizzes[id], q = qz.q; qz.done = true;
    var opts = cardEl.querySelectorAll('.jc-opt');
    opts.forEach(function (b, i) {
      b.disabled = true;
      if (i === q.ans) { b.classList.add('ok'); b.insertAdjacentHTML('beforeend', '<span class="jc-tag">✓ correct answer</span>'); }
      else if (i === picked) { b.classList.add('bad'); b.insertAdjacentHTML('beforeend', '<span class="jc-tag">✗ your answer</span>'); }
    });
    var num = cardEl.querySelector('[data-numin]'); if (num) num.disabled = true;
    var st = core.quizbank.getStats();
    var fb = cardEl.querySelector('.jc-fb');
    fb.innerHTML = '<div class="jc-sol"><b>' + (res.correct ? '✅ Correct' : '❌ Not quite') + '</b>' + (q.t === 'num' ? ' — answer: ' + esc(q.num) : '') + '<br>' + md(q.sol) + '</div>' +
      '<div class="jc-btns">' + btn('Next question →', 'next', { card: id }, 'pri') + btn('Ask AI to explain', 'gem', { text: 'Explain this JEE question step by step and the concept behind it:\n' + q.q + (q.t === 'mcq' ? '\nOptions: ' + q.opts.map(function (o, i) { return 'ABCD'[i] + ') ' + o; }).join('  ') : '') }) + '</div>' +
      '<div class="jc-note">Quiz bank: ' + st.seen + '/' + st.total + ' seen · ' + st.accuracy + '% accuracy</div>';
    typeset(fb);
  }

  function chancesCard(a) {
    var advanced = a.exam === 'advanced';
    var h = '<div class="jc-card"><h4>🏫 Rank ' + esc(a.rank) + ' · ' + (advanced ? 'JEE Advanced → IITs' : 'JEE Main → NIT/IIIT/CFI') + '</h4>' +
      '<div class="jc-note" style="margin:0 0 6px">Category: <b>' + esc(a.category) + '</b>' + (a.categoryAssumed ? ' (assumed) ' : ' ') + (a.program ? '· Branch filter: ' + esc(a.program) : '') + '</div>';
    h += '<div class="jc-pills">' + ['safe', 'likely', 'borderline', 'reach'].map(function (k) { return '<span class="jc-pill ' + k + '">' + k + ' ' + (a.counts ? a.counts[k] : (a[k] || []).length) + '</span>'; }).join('') + '</div>';
    var labels = { safe: '✅ Safe (rank is better than the opening rank)', likely: '👍 Likely (inside last year\'s range)', borderline: '⚠ Borderline (up to 12% past closing)', reach: '🎯 Reach' };
    ['safe', 'likely', 'borderline', 'reach'].forEach(function (k) {
      var list = a[k] || []; if (!list.length) return;
      h += '<div class="jc-sec">' + labels[k] + '</div><table class="jc-table">' + list.map(function (c) {
        return '<tr><td><b>' + esc(c.institute) + '</b><br><span style="color:var(--text-muted,#9a83b0)">' + esc(shortProgram(c.program)) + '</span></td><td style="white-space:nowrap;text-align:right">' + esc(c.orank) + '–' + esc(c.crank) + '</td></tr>';
      }).join('') + '</table>';
    });
    if (a.categoryAssumed) h += '<div class="jc-btns">' + ['OBC-NCL', 'EWS', 'SC', 'ST'].map(function (c) { return btn(c, 'send', { text: 'JEE ' + (advanced ? 'Advanced' : 'Main') + ' rank ' + a.rank + ' ' + c + ' which colleges' }, 'sm'); }).join('') + '</div>';
    return h + '<div class="jc-note">' + esc(a.note || '') + ' Numbers are opening–closing ranks.</div></div>';
  }
  function cutoffCard(a) {
    var h = '<div class="jc-card"><h4>🏫 ' + (a.institutes && a.institutes.length ? esc(a.institutes.join(', ')) : 'Cutoffs') + '</h4><div class="jc-note" style="margin:0 0 6px">' + esc(a.category) + (a.categoryAssumed ? ' (assumed)' : '') + ' · ' + esc(a.year) + ' final round · showing ' + a.rows.length + ' of ' + a.total + '</div>' +
      '<table class="jc-table"><tr><th>Branch</th><th>Open–Close</th><th></th></tr>' + a.rows.map(function (r) {
        var t = r.trend === 'harder' ? '📈' : r.trend === 'easier' ? '📉' : r.trend === 'stable' ? '➖' : '';
        return '<tr><td>' + (a.institutes && a.institutes.length === 1 ? '' : '<b>' + esc(r.institute) + '</b><br>') + esc(shortProgram(r.program)) + '</td><td style="white-space:nowrap">' + esc(r.orank) + '–' + esc(r.crank) + '</td><td>' + t + '</td></tr>';
      }).join('') + '</table><div class="jc-note">' + esc(a.note || '') + ' 📈 = harder than the previous year, 📉 = easier.</div></div>';
    return h;
  }
  function needsExamCard(a, text) {
    return '<div class="jc-card"><h4>🏫 Which rank is ' + esc(a.rank) + '?</h4>IIT seats use your <b>JEE Advanced</b> rank; NIT/IIIT seats use your <b>JEE Main</b> rank.<div class="jc-btns">' +
      btn('JEE Main rank', 'send', { text: text + ' (JEE Main)', silent: 1 }, 'pri') + btn('JEE Advanced rank', 'send', { text: text + ' (JEE Advanced)', silent: 1 }, 'pri') + '</div></div>';
  }
  function formulasCard(list) {
    var h = '<div class="jc-card"><h4>🧮 Formulas</h4>';
    list.slice(0, 6).forEach(function (f) {
      h += '<div class="jc-row"><div class="jc-rt"><b>' + esc(f.name || f.title || '') + '</b>' + (f.chapter ? ' <small style="display:inline">· ' + esc(f.chapter) + '</small>' : '') + '<div>$$' + (f.latex || '') + '$$</div>' + (f.desc ? '<small>' + esc(f.desc) + '</small>' : '') + '</div></div>';
    });
    return h + '</div>';
  }
  function chapterFormulasCard(ch) {
    var d = core.formulas.getByChapter(ch); if (!d) return '';
    var h = '<div class="jc-card"><h4>🧮 ' + esc(d.name || chapterName(ch)) + '</h4>';
    (d.items || []).slice(0, 8).forEach(function (f) { h += '<div class="jc-row"><div class="jc-rt"><b>' + esc(f.name) + '</b><div>$$' + (f.latex || '') + '$$</div>' + (f.desc ? '<small>' + esc(f.desc) + '</small>' : '') + '</div></div>'; });
    if (d.tip) h += '<div class="jc-note">💡 ' + esc(d.tip) + '</div>';
    return h + '</div>';
  }
  function rankCard(a) {
    return '<div class="jc-card"><h4>📈 Estimated rank</h4><b>' + esc(a.rank) + '</b> (' + esc(a.percentile) + ' percentile) · ' + esc(a.exam) + (a.score != null ? ' · score ' + esc(a.score) : '') +
      '<div class="jc-note">Estimate from historical score→rank data. Ask "which colleges can I get?" for JoSAA-based options.</div></div>';
  }
  function keyCard() {
    return '<div class="jc-card"><h4>🔑 Gemini key needed</h4>Local answers (plan, weak chapters, quiz, formulas, colleges) work without a key. For doubts and explanations, add a free Gemini API key.' +
      '<div class="jc-btns">' + btn('Add API key', 'settings', {}, 'pri') + '<a class="jc-btn" style="text-decoration:none" target="_blank" rel="noopener" href="https://aistudio.google.com/apikey">Get a free key ↗</a></div></div>';
  }

  // ── message plumbing ───────────────────────────────────────────────────
  function scrollDown() { requestAnimationFrame(function () { els.chat.scrollTop = els.chat.scrollHeight; }); }
  function addBubble(role, html, plain) {
    var d = document.createElement('div'); d.className = 'jc-msg ' + role;
    if (role === 'user') d.textContent = plain; else d.innerHTML = html;
    els.chat.appendChild(d); scrollDown(); return d;
  }
  // Assistant text reply (Gemini) with a read-aloud button; raw text kept for speech
  function addReply(raw) {
    var d = addBubble('assistant', md(raw)); d._raw = raw; decorateReply(d); return d;
  }
  function decorateReply(d) {
    if (!global.speechSynthesis || d.querySelector('[data-act=speak]')) return;
    d.insertAdjacentHTML('beforeend', '<div class="jc-btns" style="margin-top:6px"><button class="jc-btn sm" data-act="speak" aria-label="Read this answer aloud">🔊 Read aloud</button></div>');
  }
  function speechText(raw) {
    return String(raw || '').replace(/\$\$[\s\S]+?\$\$|\$[^$\n]+?\$/g, ' formula ').replace(/[*_`#>]+/g, '').replace(/^\s*[-•]\s+/gm, '').replace(/\s+/g, ' ').trim();
  }
  function speak(btn) {
    var ss = global.speechSynthesis; if (!ss) return;
    if (ss.speaking) { ss.cancel(); btn.textContent = '🔊 Read aloud'; return; }
    var msg = btn.closest('.jc-msg'), u = new global.SpeechSynthesisUtterance(speechText(msg && msg._raw));
    u.lang = 'en-IN'; u.onend = u.onerror = function () { btn.textContent = '🔊 Read aloud'; };
    btn.textContent = '⏹ Stop reading'; ss.speak(u);
  }
  function announce(t) { if (els.live) { els.live.textContent = ''; setTimeout(function () { els.live.textContent = t; }, 50); } }

  // ── voice input (Web Speech API; hidden where unsupported) ──
  var rec = null;
  function micToggle() {
    var SR = global.SpeechRecognition || global.webkitSpeechRecognition, mic = root.querySelector('.jc-mic');
    if (!SR) return;
    if (rec) { rec.stop(); return; }
    rec = new SR(); rec.lang = ls('jee_coach_lang') || 'en-IN'; rec.interimResults = true; rec.continuous = false;
    var base = els.input.value ? els.input.value.replace(/\s+$/, '') + ' ' : '';
    rec.onresult = function (e) { var t = ''; for (var i = 0; i < e.results.length; i++) t += e.results[i][0].transcript; els.input.value = base + t; els.input.dispatchEvent(new Event('input')); };
    rec.onerror = function (e) { announce(e.error === 'not-allowed' ? 'Microphone permission was blocked.' : 'Voice input stopped: ' + e.error); };
    rec.onend = function () { rec = null; mic.classList.remove('rec'); mic.setAttribute('aria-pressed', 'false'); mic.setAttribute('aria-label', 'Speak your question'); els.input.focus(); announce('Stopped listening. Review your question, then press send.'); };
    try { rec.start(); mic.classList.add('rec'); mic.setAttribute('aria-pressed', 'true'); mic.setAttribute('aria-label', 'Stop listening'); announce('Listening'); } catch (err) { rec = null; }
  }

  function addCard(html) {
    if (!html) return null;
    var d = document.createElement('div'); d.innerHTML = html; var n = d.firstElementChild; els.chat.appendChild(n); typeset(n); scrollDown(); return n;
  }
  function persist() {
    var keep = msgs.filter(function (m) { return m.text; }).slice(-30).map(function (m) { return { role: m.role, text: m.text.slice(0, 4000) }; });
    ls(LS_CHAT, JSON.stringify(keep));
  }
  function push(role, text) { msgs.push({ role: role, text: text }); persist(); }
  function historyForGemini() { return msgs.filter(function (m) { return m.text; }).slice(-7, -1).map(function (m) { return { role: m.role, content: m.text }; }); }
  function setBusy(b) { busy = b; els.send.disabled = false; els.send.textContent = b ? '■' : '➤'; els.send.setAttribute('aria-label', b ? 'Stop' : 'Send'); }

  async function gemini(text) {
    var node = addBubble('assistant', '', ''); node.classList.add('streaming'); setBusy(true); els.chat.setAttribute('aria-busy', 'true');
    var raf = 0, latest = '';
    try {
      var r = await core.ask({
        userMessage: text, systemPrompt: SYSTEM_PROMPT, history: historyForGemini(),
        onChunk: function (full) { latest = full; if (!raf) raf = requestAnimationFrame(function () { raf = 0; node.innerHTML = md(latest); scrollDown(); }); }
      });
      if (r.source === 'local') { node.remove(); return renderLocal(text); }
      if (raf) { cancelAnimationFrame(raf); raf = 0; }          // a late stream repaint must not overwrite the final reply
      node.classList.remove('streaming'); node.innerHTML = md(r.text); node._raw = r.text; decorateReply(node); typeset(node); push('assistant', r.text); scrollDown(); announce('Answer ready');
    } catch (e) {
      node.remove(); var m = String(e && e.message || e);
      if (/NO_KEY/.test(m)) addCard(keyCard());
      else if (/abort|cancel/i.test(m)) addBubble('assistant', '<p>Stopped.</p>');
      else addBubble('assistant', '<p>⚠ ' + esc(m.replace(/^[A-Z_]+:\s*/, '')) + '</p>');
    } finally { setBusy(false); els.chat.setAttribute('aria-busy', 'false'); refreshStats(); }
  }

  function renderLocal(text) {
    var ctx = core.context.build(text), t = ctx.localType, a = ctx.localAnswer;
    if (t === 'josaa_chances') addCard(chancesCard(a));
    else if (t === 'josaa_cutoff') addCard(cutoffCard(a));
    else if (t === 'josaa_needs_exam') addCard(needsExamCard(a, text.replace(/\s*\((JEE )?(Main|Advanced)\)\s*$/, '')));
    else if (t === 'quiz') addCard(quizCard(a, 'q' + (++cardSeq)));
    else if (t === 'formulas') addCard(formulasCard(a));
    else if (t === 'rank') addCard(rankCard(a));
    else return false;
    return true;
  }

  async function handle(text, silent) {
    text = String(text || '').trim(); if (!text || busy) return;
    if (!silent) { addBubble('user', '', text); push('user', text); }
    var s = bridge().snapshot(), ctx = core.context.build(text);
    if (text.length <= 300) {
      if (ctx.intent === 'study_tonight') return void addCard(planCard(s));
      if (ctx.intent === 'weakness') return void addCard(weakCard(s));
      if (ctx.intent === 'test_analysis') return void addCard(mockCard(s));
    }
    if (ctx.canAnswerLocally) {
      try { await core.ask({ userMessage: text }); } catch (e) { /* audit only */ }
      if (renderLocal(text)) return;
    }
    return gemini(text);
  }

  function quizNext(opts) {
    var b = core.quizbank, f = { count: 1 };
    if (opts.ch) f.chapter = opts.ch;
    if (opts.subject) f.subject = opts.subject;
    var q = b.getUnseen(f)[0] || b.getRandom(f)[0];
    if (!q) { addBubble('assistant', '<p>No questions for that filter yet.</p>'); return; }
    addCard(quizCard(q, 'q' + (++cardSeq)));
  }

  function refreshStats() {
    var s = bridge().snapshot(), h = '';
    function chip(icon, label, val, text) { return '<button class="jc-stat" data-act="send" data-text="' + esc(text) + '">' + icon + ' ' + label + ' <b>' + val + '</b></button>'; }
    if (s.exam.daysLeft !== null && s.exam.daysLeft >= 0) h += chip('⏳', 'exam in', s.exam.daysLeft + 'd', 'What should I focus on with ' + s.exam.daysLeft + ' days left?');
    h += chip('📚', 'syllabus', s.completion.overallPct + '%', 'What should I study tonight?');
    h += chip('⚠', 'weak', s.weak.length, 'Which chapters am I weak in?');
    h += chip('🔁', 'revise', s.revisionDue.length, 'What should I study tonight?');
    if (s.lastMock) h += chip('📊', 'last mock', s.lastMock.pct + '%', 'Analyse my last mock test');
    h += chip('🔥', 'streak', s.streak.current + 'd', 'How is my consistency and what should I change?');
    els.stats.innerHTML = h;
  }

  // ── settings ────────────────────────────────────────────────────────────
  function buildSettings() {
    var cur = ls(LS_MODEL) || 'gemini-3.5-flash';
    els.set.innerHTML = '<b>⚙ AI settings</b><label>Gemini API key (stored only on this device)</label><input type="password" id="jc-key" placeholder="AIza…" autocomplete="off" value="' + esc(ls(LS_KEY) || '') + '">' +
      '<label>Model</label><select id="jc-model">' + MODELS.map(function (m) { return '<option' + (m === cur ? ' selected' : '') + '>' + m + '</option>'; }).join('') + '</select>' +
      '<label>Text size</label><div class="jc-fsrow">' + '<button class="jc-btn" data-act="fs-" aria-label="Smaller text">A−</button><output id="jc-fsval" aria-live="polite"></output><button class="jc-btn" data-act="fs+" aria-label="Larger text">A+</button></div>' +
      '<label class="jc-chk"><input type="checkbox" id="jc-fabtoggle"' + (ls('jee_coach_fab') !== '0' ? ' checked' : '') + '> Show the floating AI button on every tab</label>' +
      '<div class="jc-btns">' + btn('Save', 'save', {}, 'pri') + btn('Request monitor', 'monitor', {}) + btn('Clear chat', 'clear', {}) + '</div><div class="jc-note" id="jc-status"></div><div class="jc-mon" id="jc-mon" hidden></div>';
  }
  function setFs(v) {
    v = Math.max(0.85, Math.min(1.4, Math.round(v * 100) / 100)); ls('jee_coach_fs', String(v));
    root.style.setProperty('--jc-fs', v); var o = root.querySelector('#jc-fsval'); if (o) o.textContent = Math.round(v * 100) + '%';
  }
  function saveSettings() {
    var k = root.querySelector('#jc-key').value.trim(), m = root.querySelector('#jc-model').value;
    ls(LS_KEY, k); ls(LS_MODEL, m); core.configure({ apiKey: k, modelId: m });
    root.querySelector('#jc-status').textContent = k ? '✓ Saved. Model: ' + m : 'Key cleared — only local answers will work.';
  }

  // ── events ──────────────────────────────────────────────────────────────
  function onClick(e) {
    var b = e.target.closest('[data-act]'); if (!b || !root.contains(b)) return;
    var d = b.dataset, act = d.act;
    if (act === 'send') return void handle(d.text, !!d.silent);
    if (act === 'gem') { if (busy) return; addBubble('user', '', short(d.text.split('\n')[0], 120)); push('user', d.text); return void gemini(d.text); }
    if (act === 'quiz') { addBubble('user', '', '🎯 Quiz me: ' + chapterName(d.ch)); return void quizNext({ ch: d.ch }); }
    if (act === 'quizweak') {
      var w = bridge().snapshot().weak.map(quizIdFor).filter(Boolean)[0];
      addBubble('user', '', w ? '🎯 Quiz me on my weakest chapter' : '🎯 Quiz me'); return void quizNext(w ? { ch: w } : {});
    }
    if (act === 'formulas') { var c = chapterFormulasCard(d.ch); return void addCard(c || '<div class="jc-card">No formula sheet for this chapter yet.</div>'); }
    if (act === 'opt' || act === 'num') {
      var qz = quizzes[d.card]; if (!qz || qz.done) return;
      var card = root.querySelector('[data-card="' + d.card + '"]'), picked, val;
      if (act === 'opt') { picked = +d.i; val = picked; } else { val = card.querySelector('[data-numin]').value; if (val === '') return; }
      return void quizFeedback(card, d.card, core.quizbank.checkAnswer(qz.q.id, val), picked);
    }
    if (act === 'next') { var q0 = quizzes[d.card].q; return void quizNext({ ch: q0.ch }); }
    if (act === 'settings') { els.set.classList.add('open'); return void els.set.scrollIntoView({ behavior: 'smooth' }); }
    if (act === 'save') return void saveSettings();
    if (act === 'fs+' || act === 'fs-') return void setFs((parseFloat(ls('jee_coach_fs')) || 1) + (act === 'fs+' ? 0.1 : -0.1));
    if (act === 'mic') return void micToggle();
    if (act === 'speak') return void speak(b);
    if (act === 'quizsub') { addBubble('user', '', '🎯 Quick ' + d.sub + ' quiz'); return void quizNext({ subject: d.sub }); }
    if (act === 'clear') { msgs = []; ls(LS_CHAT, '[]'); els.chat.innerHTML = ''; return void welcome(); }
    if (act === 'monitor') {
      var mon = root.querySelector('#jc-mon'); mon.hidden = !mon.hidden;
      if (!mon.hidden) { try { core.mountMonitor(mon); } catch (err) { mon.textContent = 'Monitor unavailable: ' + err.message; } }
      var st = core.status(); root.querySelector('#jc-status').textContent = 'Key: ' + st.apiKey + ' · model ' + st.model + ' · requests this session ' + (st.requests.sessionCount || 0);
    }
  }

  function welcome() {
    var s = bridge().snapshot();
    addBubble('assistant', '<p><b>Hey! I\'m your JEE coach.</b> I read your tracker — chapters, tests, mocks, revision dates and study hours — so my answers use <i>your</i> data.</p>' +
      (s.hasData ? '<p>Try a quick action below, or ask anything.</p>' : '<p>Your tracker is still empty, so advice will be generic until you log progress.</p>') + '<p style="color:var(--text-muted,#9a83b0);font-size:.8rem">Plans, weak chapters, quizzes, formulas and college chances are answered on-device with no API call.</p>');
    if (!ls(LS_KEY)) addCard(keyCard());
  }

  // ── mount / open ────────────────────────────────────────────────────────
  function mount(el) {
    if (root === el && core) return;
    root = el; root.style.scrollMarginTop = '58px';   // clear the tracker's sticky chapter chip row
    if (!document.getElementById('jee-coach-css')) { var st = document.createElement('style'); st.id = 'jee-coach-css'; st.textContent = CSS; document.head.appendChild(st); }
    core = new global.JEEAICoreV2({ apiKey: ls(LS_KEY) || '', modelId: ls(LS_MODEL) || 'gemini-3.5-flash' });
    global.TrackerBridge.install(core);
    root.innerHTML = '<div class="jc-wrap" role="region" aria-label="AI Coach"><div class="jc-sr" aria-live="assertive" role="status"></div><div class="jc-top"><div class="jc-title">🧠 AI COACH</div><button class="jc-gear" data-act="settings" aria-label="AI settings">⚙</button></div>' +
      '<div class="jc-set"></div><div class="jc-stats"></div><div class="jc-chat" role="log" aria-live="polite" aria-label="Conversation"></div>' +
      '<div class="jc-chips">' +
        '<button class="jc-chip" data-act="send" data-text="What should I study tonight?">📅 Study tonight</button>' +
        '<button class="jc-chip" data-act="send" data-text="Which chapters am I weak in?">⚠ Weak chapters</button>' +
        '<button class="jc-chip" data-act="send" data-text="Analyse my last mock test">📊 Mock trend</button>' +
        '<button class="jc-chip" data-act="quizweak">🎯 Quiz me</button>' +
        '<button class="jc-chip" data-act="fillf">🧮 Formulas</button>' +
        '<button class="jc-chip" data-act="fillc">🏫 Colleges</button>' +
      '</div><div class="jc-input"><textarea rows="1" placeholder="Ask anything…" aria-label="Message"></textarea>' +
      ((global.SpeechRecognition || global.webkitSpeechRecognition) ? '<button class="jc-mic" data-act="mic" aria-pressed="false" aria-label="Speak your question">🎤</button>' : '') +
      '<button class="jc-send" aria-label="Send">➤</button></div></div>';
    setFs(parseFloat(ls('jee_coach_fs')) || 1);
    els = { live: root.querySelector('.jc-sr'), set: root.querySelector('.jc-set'), stats: root.querySelector('.jc-stats'), chat: root.querySelector('.jc-chat'), input: root.querySelector('textarea'), send: root.querySelector('.jc-send') };
    buildSettings(); setFs(parseFloat(ls('jee_coach_fs')) || 1);
    root.addEventListener('change', function (e) {
      if (e.target && e.target.id === 'jc-fabtoggle' && global.AICoachLauncher) global.AICoachLauncher.setVisible(e.target.checked);
    });
    root.addEventListener('click', function (e) {
      var b = e.target.closest('[data-act]');
      if (b && b.dataset.act === 'fillf') { els.input.value = 'formula for '; els.input.focus(); return; }
      if (b && b.dataset.act === 'fillc') { els.input.value = 'My JEE Main rank is '; els.input.focus(); return; }
      onClick(e);
    });
    function submit() {
      if (busy) { try { core.requests.abort(); } catch (e) { /* ignore */ } return; }
      var v = els.input.value; els.input.value = ''; els.input.style.height = 'auto'; handle(v);
    }
    els.send.addEventListener('click', submit);
    els.input.addEventListener('input', function () { els.input.style.height = 'auto'; els.input.style.height = Math.min(120, els.input.scrollHeight) + 'px'; });
    els.input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && !e.shiftKey && !global.matchMedia('(pointer:coarse)').matches) { e.preventDefault(); submit(); }
    });
    var saved = []; try { saved = JSON.parse(ls(LS_CHAT) || '[]'); } catch (e) { saved = []; }
    if (saved.length) saved.forEach(function (m) { msgs.push(m); if (m.role === 'user') addBubble('user', '', m.text); else { var n = addReply(m.text); typeset(n); } });
    else welcome();
    refreshStats();
  }
  var HINTS = {
    physics:   { label: '🎯 Quick physics quiz', act: 'quizsub', sub: 'physics' },
    chemistry: { label: '🎯 Quick chemistry quiz', act: 'quizsub', sub: 'chemistry' },
    maths:     { label: '🎯 Quick maths quiz', act: 'quizsub', sub: 'mathematics' },
    advanced:  { label: '🎯 Quick maths quiz', act: 'quizsub', sub: 'mathematics' },
    tests:     { label: '📊 Analyse my mocks', act: 'send', text: 'Analyse my last mock test' },
    schedule:  { label: '📅 Plan tonight', act: 'send', text: 'What should I study tonight?' },
    daily:     { label: '⚠ My weak chapters', act: 'send', text: 'Which chapters am I weak in?' },
    syllabus:  { label: '⚠ My weak chapters', act: 'send', text: 'Which chapters am I weak in?' },
    roadmap:   { label: '📅 Plan tonight', act: 'send', text: 'What should I study tonight?' }
  };
  function open(opts) {
    if (!core) return; opts = opts || {}; refreshStats();
    var chips = root.querySelector('.jc-chips');
    var old = chips.querySelector('[data-hint]'); if (old) old.remove();
    var h = HINTS[opts.tab];
    if (h) { chips.insertAdjacentHTML('afterbegin', '<button class="jc-chip" data-hint="1" data-act="' + h.act + '"' + (h.sub ? ' data-sub="' + h.sub + '"' : '') + (h.text ? ' data-text="' + esc(h.text) + '"' : '') + '>' + h.label + '</button>'); chips.scrollLeft = 0; }
    if (opts.sheet || root.closest('.jc-sheet')) { scrollDown(); return; }
    // In the tab: the tracker keeps its HUD above every tab; bring the coach to the top of the screen so the chat gets the full height.
    // (Delayed: switchTab() scrolls to top itself ~150 ms into its slide animation.)
    setTimeout(function () { try { root.scrollIntoView({ block: 'start', behavior: 'smooth' }); } catch (e) { /* ignore */ } scrollDown(); }, 380);
  }

  global.JEECoachUI = { mount: mount, open: open, _md: md };
})(typeof window !== 'undefined' ? window : globalThis);
