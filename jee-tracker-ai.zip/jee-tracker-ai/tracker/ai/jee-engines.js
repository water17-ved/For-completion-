/**
 * JEE AI Core — Phase 1: Local Computation Engines
 * ═══════════════════════════════════════════════════
 * Zero API calls. Zero internet required. Instant.
 *
 * Engines:
 *   EventBus          — pub/sub between engines
 *   ScoreEngine       — marks, accuracy, subject breakdown
 *   RankEstimator     — rank prediction from score
 *   SyllabusTracker   — chapter completion + prerequisites
 *   WeakAreaDetector  — performance classification + priority
 *   RevisionScheduler — SM-2 spaced repetition algorithm
 *   StudyTimer        — sessions, streaks, heatmap
 *
 * Usage:
 *   const jee = new JEECore();
 *   jee.score.query({ responses: [...] })
 *   jee.rank.query({ score: 210, exam: 'main', category: 'general' })
 *   jee.syllabus.mark('rot', 'done')
 *   jee.revision.getToday()
 *   jee.timer.start('Physics')
 */

(function (global) {
  'use strict';

  // ═══════════════════════════════════════════════════════════
  // STATIC DATA — Syllabus, Ranks, Cutoffs
  // ═══════════════════════════════════════════════════════════

  /** JEE full syllabus with weightages (1–6 scale) and prerequisites */
  const SYLLABUS = {
    physics: [
      { id:'kin',  name:'Kinematics',               cls:11, wt:3, pre:[] },
      { id:'nlm',  name:'Laws of Motion',            cls:11, wt:4, pre:['kin'] },
      { id:'wpe',  name:'Work, Power & Energy',      cls:11, wt:4, pre:['nlm'] },
      { id:'com',  name:'Centre of Mass',            cls:11, wt:3, pre:['nlm'] },
      { id:'rot',  name:'Rotational Motion',         cls:11, wt:5, pre:['nlm','wpe'] },
      { id:'grav', name:'Gravitation',               cls:11, wt:3, pre:['nlm'] },
      { id:'prop', name:'Properties of Matter',      cls:11, wt:2, pre:[] },
      { id:'shm',  name:'Simple Harmonic Motion',    cls:11, wt:4, pre:['nlm'] },
      { id:'wave', name:'Waves & Sound',             cls:11, wt:3, pre:['shm'] },
      { id:'heat', name:'Heat & Thermodynamics',     cls:11, wt:4, pre:[] },
      { id:'ktg',  name:'Kinetic Theory of Gases',   cls:11, wt:2, pre:['heat'] },
      { id:'es',   name:'Electrostatics',            cls:12, wt:6, pre:[] },
      { id:'cap',  name:'Capacitors',                cls:12, wt:4, pre:['es'] },
      { id:'cur',  name:'Current Electricity',       cls:12, wt:5, pre:['es'] },
      { id:'mag',  name:'Magnetism & Moving Charges',cls:12, wt:4, pre:['cur'] },
      { id:'emi',  name:'EMI & AC Circuits',         cls:12, wt:5, pre:['mag'] },
      { id:'ray',  name:'Ray Optics',                cls:12, wt:4, pre:[] },
      { id:'wop',  name:'Wave Optics',               cls:12, wt:3, pre:['wave','ray'] },
      { id:'mod',  name:'Modern Physics',            cls:12, wt:5, pre:[] },
      { id:'semi', name:'Semiconductors',            cls:12, wt:2, pre:['mod'] },
    ],
    chemistry: [
      // Physical
      { id:'mol',   name:'Mole Concept',                cls:11, wt:3, pre:[] },
      { id:'atm',   name:'Atomic Structure',             cls:11, wt:3, pre:[] },
      { id:'cbond', name:'Chemical Bonding',             cls:11, wt:4, pre:['atm'] },
      { id:'therm', name:'Thermodynamics (Chem)',        cls:11, wt:4, pre:['mol'] },
      { id:'ceq',   name:'Chemical Equilibrium',         cls:11, wt:4, pre:['therm'] },
      { id:'ieq',   name:'Ionic Equilibrium',            cls:11, wt:3, pre:['ceq'] },
      { id:'red',   name:'Redox Reactions',              cls:11, wt:2, pre:[] },
      { id:'sol',   name:'Solutions & Colligative',      cls:12, wt:3, pre:['mol'] },
      { id:'elec',  name:'Electrochemistry',             cls:12, wt:5, pre:['red','ceq'] },
      { id:'ckin',  name:'Chemical Kinetics',            cls:12, wt:3, pre:['ceq'] },
      { id:'ss',    name:'Surface Chemistry & States',   cls:11, wt:1, pre:[] },
      // Organic
      { id:'goc',   name:'General Organic Chemistry',    cls:11, wt:4, pre:[] },
      { id:'hc',    name:'Hydrocarbons',                 cls:11, wt:3, pre:['goc'] },
      { id:'hal',   name:'Haloalkanes & Haloarenes',     cls:12, wt:3, pre:['hc'] },
      { id:'alc',   name:'Alcohols, Phenols & Ethers',   cls:12, wt:3, pre:['goc'] },
      { id:'ald',   name:'Aldehydes & Ketones',          cls:12, wt:4, pre:['goc'] },
      { id:'acid',  name:'Carboxylic Acids & Derivatives',cls:12,wt:3, pre:['ald'] },
      { id:'ami',   name:'Amines',                       cls:12, wt:3, pre:['goc'] },
      { id:'bio',   name:'Biomolecules & Polymers',      cls:12, wt:2, pre:[] },
      // Inorganic
      { id:'pt',    name:'Periodic Table & Properties',  cls:11, wt:3, pre:[] },
      { id:'sblk',  name:'s-Block Elements',             cls:11, wt:2, pre:['pt'] },
      { id:'pblk',  name:'p-Block Elements',             cls:12, wt:5, pre:['cbond'] },
      { id:'dblk',  name:'d & f-Block Elements',         cls:12, wt:3, pre:['pt'] },
      { id:'coord', name:'Coordination Compounds',       cls:12, wt:4, pre:['dblk','cbond'] },
      { id:'metal', name:'Metallurgy',                   cls:12, wt:2, pre:[] },
    ],
    mathematics: [
      // Algebra
      { id:'sets',  name:'Sets, Relations & Functions',  cls:11, wt:2, pre:[] },
      { id:'cn',    name:'Complex Numbers',              cls:11, wt:4, pre:[] },
      { id:'qe',    name:'Quadratic Equations',          cls:11, wt:3, pre:['cn'] },
      { id:'seq',   name:'Sequences & Series',           cls:11, wt:3, pre:[] },
      { id:'bin',   name:'Binomial Theorem',             cls:11, wt:3, pre:['seq'] },
      { id:'pnc',   name:'Permutations & Combinations',  cls:11, wt:4, pre:['sets'] },
      { id:'mat',   name:'Matrices & Determinants',      cls:12, wt:4, pre:[] },
      { id:'prob',  name:'Probability',                  cls:12, wt:5, pre:['pnc'] },
      // Calculus
      { id:'fun',   name:'Functions & Graphs',           cls:11, wt:3, pre:['sets'] },
      { id:'lim',   name:'Limits & Continuity',          cls:11, wt:3, pre:['fun'] },
      { id:'diff',  name:'Differentiation',              cls:12, wt:4, pre:['lim'] },
      { id:'aod',   name:'Applications of Derivatives',  cls:12, wt:4, pre:['diff'] },
      { id:'iint',  name:'Indefinite Integration',       cls:12, wt:5, pre:['diff'] },
      { id:'dint',  name:'Definite Integration',         cls:12, wt:5, pre:['iint'] },
      { id:'auc',   name:'Area Under Curves',            cls:12, wt:3, pre:['dint'] },
      { id:'de',    name:'Differential Equations',       cls:12, wt:3, pre:['iint'] },
      // Coordinate Geometry
      { id:'sl',    name:'Straight Lines',               cls:11, wt:3, pre:[] },
      { id:'cir',   name:'Circles',                      cls:11, wt:4, pre:['sl'] },
      { id:'para',  name:'Parabola',                     cls:11, wt:4, pre:['sl'] },
      { id:'ell',   name:'Ellipse',                      cls:12, wt:4, pre:['para'] },
      { id:'hyp',   name:'Hyperbola',                    cls:12, wt:3, pre:['ell'] },
      // Trigonometry + Misc
      { id:'trig',  name:'Trigonometry',                 cls:11, wt:4, pre:[] },
      { id:'itr',   name:'Inverse Trigonometry',         cls:12, wt:3, pre:['trig'] },
      { id:'vec',   name:'Vectors',                      cls:12, wt:4, pre:[] },
      { id:'3d',    name:'3D Geometry',                  cls:12, wt:4, pre:['vec'] },
      { id:'stat',  name:'Statistics',                   cls:11, wt:2, pre:[] },
    ]
  };

  /** [score, rank] data points for linear interpolation — JEE Main 2024 */
  const RANK_TABLE = {
    main: {
      general: [[300,1],[290,50],[280,220],[270,620],[260,1600],[250,3600],
                [240,6200],[230,10500],[220,16000],[210,24000],[200,34000],
                [190,48000],[180,68000],[170,93000],[160,122000],[150,155000],
                [140,195000],[130,240000],[120,292000],[110,355000],[100,430000],
                [90,520000],[80,630000],[70,760000],[60,900000],[45,1100000]],
      obc:     [[240,1],[210,1000],[180,5000],[160,12000],[140,26000],[110,60000],[85,120000]],
      sc:      [[180,1],[150,1000],[120,5000],[100,12000],[75,28000],[55,55000]],
      st:      [[150,1],[120,500],[95,2000],[75,5500],[55,12000]],
      ews:     [[240,1],[215,800],[185,4000],[160,10000],[135,22000],[105,52000]],
    },
    advanced: {
      general: [[360,1],[300,100],[260,500],[220,2000],[185,5000],
                [160,10000],[135,18000],[110,28000],[90,40000],[70,55000]],
      obc:     [[200,1],[165,1000],[135,5000],[110,12000],[85,25000]],
      sc:      [[150,1],[115,1000],[85,5000],[65,12000]],
      st:      [[120,1],[90,500],[65,2000],[50,5000]],
    }
  };

  /** Approximate opening ranks for popular programmes (Advanced rank unless noted) */
  const COLLEGE_CUTOFFS = [
    // IITs (JEE Advanced rank)
    { name:'IIT Bombay',    branch:'Computer Science',    exam:'advanced', rank:67 },
    { name:'IIT Delhi',     branch:'Computer Science',    exam:'advanced', rank:98 },
    { name:'IIT Madras',    branch:'Computer Science',    exam:'advanced', rank:185 },
    { name:'IIT Kanpur',    branch:'Computer Science',    exam:'advanced', rank:240 },
    { name:'IIT Kharagpur', branch:'Computer Science',    exam:'advanced', rank:390 },
    { name:'IIT Roorkee',   branch:'Computer Science',    exam:'advanced', rank:680 },
    { name:'IIT Guwahati',  branch:'Computer Science',    exam:'advanced', rank:1150 },
    { name:'IIT Bombay',    branch:'Electrical Engg',     exam:'advanced', rank:320 },
    { name:'IIT Delhi',     branch:'Electrical Engg',     exam:'advanced', rank:420 },
    { name:'IIT Bombay',    branch:'Mechanical Engg',     exam:'advanced', rank:900 },
    { name:'IIT (any)',     branch:'Any Branch',          exam:'advanced', rank:11500 },
    // NITs (JEE Main rank)
    { name:'NIT Trichy',    branch:'Computer Science',    exam:'main', rank:480 },
    { name:'NIT Warangal',  branch:'Computer Science',    exam:'main', rank:570 },
    { name:'NIT Surathkal', branch:'Computer Science',    exam:'main', rank:870 },
    { name:'NIT Calicut',   branch:'Computer Science',    exam:'main', rank:1750 },
    { name:'NIT Rourkela',  branch:'Computer Science',    exam:'main', rank:2400 },
    { name:'Top NIT',       branch:'Any Branch',          exam:'main', rank:25000 },
    { name:'NIT (any)',     branch:'Any Branch',          exam:'main', rank:75000 },
  ];

  // ═══════════════════════════════════════════════════════════
  // EVENT BUS — decoupled inter-engine communication
  // ═══════════════════════════════════════════════════════════
  const EventBus = (function () {
    const _h = {};
    return {
      on(ev, fn) { (_h[ev] = _h[ev] || []).push(fn); },
      off(ev, fn) { _h[ev] = (_h[ev] || []).filter(f => f !== fn); },
      emit(ev, data) { (_h[ev] || []).forEach(fn => { try { fn(data); } catch(e) {} }); },
      once(ev, fn) {
        const wrap = d => { fn(d); this.off(ev, wrap); };
        this.on(ev, wrap);
      }
    };
  })();

  // ═══════════════════════════════════════════════════════════
  // BASE ENGINE
  // ═══════════════════════════════════════════════════════════
  class Engine {
    constructor(id) {
      this.id = id;
      this.cache = null;
      this.lastUpdated = null;
      this.isReady = false;
    }
    _save(key, val) {
      try { localStorage.setItem(`jee_${this.id}_${key}`, JSON.stringify(val)); } catch(e) {}
    }
    _load(key, fallback = null) {
      try {
        const raw = localStorage.getItem(`jee_${this.id}_${key}`);
        return raw !== null ? JSON.parse(raw) : fallback;
      } catch(e) { return fallback; }
    }
    _clear(key) {
      try { localStorage.removeItem(`jee_${this.id}_${key}`); } catch(e) {}
    }
  }

  // ═══════════════════════════════════════════════════════════
  // ENGINE 1 — SCORE ENGINE
  // ═══════════════════════════════════════════════════════════
  /**
   * Calculates JEE scores with full marking scheme support.
   *
   * query(input) where input =
   * {
   *   exam: 'main' | 'advanced',
   *   subjects: {
   *     physics:   { mcq: [{ans:'A', correct:'A'},...], num: [{ans:42, correct:42},...] },
   *     chemistry: { mcq: [...], num: [...] },
   *     maths:     { mcq: [...], num: [...] }
   *   }
   * }
   *
   * Returns full breakdown: total, per-subject, accuracy, attempt rate.
   */
  class ScoreEngine extends Engine {
    constructor() {
      super('score');
      this.schemes = {
        main:     { mcq: { right:4, wrong:-1, skip:0 }, num: { right:4, wrong:0, skip:0 } },
        advanced: { mcq: { right:3, wrong:-1, skip:0 }, num: { right:4, wrong:0, skip:0 } }
      };
    }

    query(input) {
      const result = this._calculate(input);
      this.cache = result;
      this.lastUpdated = Date.now();
      this.isReady = true;
      EventBus.emit('score:updated', result);
      return result;
    }

    /** Quick entry: just pass totals per subject, no question-level detail */
    quickQuery({ physics, chemistry, maths, total = 300 }) {
      const sub = (marks, max) => ({
        marks, max,
        percentage: +((marks / max) * 100).toFixed(1),
        status: marks/max >= 0.7 ? 'strong' : marks/max >= 0.45 ? 'medium' : 'weak'
      });
      const result = {
        total: physics + chemistry + maths,
        maxTotal: total,
        percentage: +(((physics + chemistry + maths) / total) * 100).toFixed(1),
        subjects: {
          Physics: sub(physics, total/3),
          Chemistry: sub(chemistry, total/3),
          Mathematics: sub(maths, total/3)
        }
      };
      this.cache = result;
      this.lastUpdated = Date.now();
      this.isReady = true;
      EventBus.emit('score:updated', result);
      return result;
    }

    _calculate({ exam = 'main', subjects }) {
      const scheme = this.schemes[exam];
      let grandTotal = 0, grandMax = 0, grandAttempted = 0, grandCorrect = 0;
      const subjectResults = {};

      for (const [subj, data] of Object.entries(subjects)) {
        let score = 0, max = 0, attempted = 0, correct = 0, total = 0;

        // MCQ questions
        if (data.mcq) {
          for (const q of data.mcq) {
            total++;
            max += scheme.mcq.right;
            if (q.ans === null || q.ans === undefined || q.ans === '') {
              score += scheme.mcq.skip;
            } else {
              attempted++;
              if (q.ans === q.correct) {
                score += scheme.mcq.right;
                correct++;
              } else {
                score += scheme.mcq.wrong;
              }
            }
          }
        }

        // Numerical questions
        if (data.num) {
          for (const q of data.num) {
            total++;
            max += scheme.num.right;
            if (q.ans === null || q.ans === undefined || q.ans === '') {
              score += scheme.num.skip;
            } else {
              attempted++;
              if (Number(q.ans) === Number(q.correct)) {
                score += scheme.num.right;
                correct++;
              } else {
                score += scheme.num.wrong;
              }
            }
          }
        }

        const percentage = total > 0 ? +((score / max) * 100).toFixed(1) : 0;
        const accuracy   = attempted > 0 ? +((correct / attempted) * 100).toFixed(1) : 0;
        const attemptRate = total > 0 ? +((attempted / total) * 100).toFixed(1) : 0;

        subjectResults[subj] = {
          score, max, total, attempted, correct,
          percentage, accuracy, attemptRate,
          status: percentage >= 70 ? 'strong' : percentage >= 45 ? 'medium' : 'weak'
        };

        grandTotal    += score;
        grandMax      += max;
        grandAttempted+= attempted;
        grandCorrect  += correct;
      }

      return {
        total: grandTotal,
        maxTotal: grandMax,
        percentage: grandMax > 0 ? +((grandTotal / grandMax) * 100).toFixed(1) : 0,
        accuracy: grandAttempted > 0 ? +((grandCorrect / grandAttempted) * 100).toFixed(1) : 0,
        attemptRate: grandMax / 4 > 0 ? +((grandAttempted / (grandMax / 4)) * 100).toFixed(1) : 0,
        subjects: subjectResults,
        exam,
        timestamp: Date.now()
      };
    }
  }

  // ═══════════════════════════════════════════════════════════
  // ENGINE 2 — RANK ESTIMATOR
  // ═══════════════════════════════════════════════════════════
  /**
   * Estimates rank from score using piecewise linear interpolation
   * on historical JEE Main/Advanced data.
   *
   * query({ score, exam, category }) →
   * { rank, percentile, confidence, colleges, cutoffStatus }
   */
  class RankEstimator extends Engine {
    constructor() { super('rank'); }

    query({ score, exam = 'main', category = 'general' }) {
      const rank = this._interpolate(score, exam, category);
      const maxRank = this._interpolate(0, exam, category);
      const percentile = +(100 - (rank / maxRank * 100)).toFixed(2);
      const colleges = this._matchColleges(rank, exam);
      const cutoffStatus = this._cutoffStatus(score, exam, category);

      const result = { score, exam, category, rank, percentile, confidence: this._confidence(score, exam), colleges, cutoffStatus };
      this.cache = result;
      this.lastUpdated = Date.now();
      this.isReady = true;
      return result;
    }

    _interpolate(score, exam, category) {
      const table = (RANK_TABLE[exam] || {})[category] || RANK_TABLE[exam].general;
      // table is sorted descending by score
      if (score >= table[0][0]) return table[0][1];
      if (score <= table[table.length-1][0]) return table[table.length-1][1];

      for (let i = 0; i < table.length - 1; i++) {
        const [s1, r1] = table[i];
        const [s2, r2] = table[i+1];
        if (score <= s1 && score >= s2) {
          const t = (s1 - score) / (s1 - s2);
          return Math.round(r1 + t * (r2 - r1));
        }
      }
      return table[table.length-1][1];
    }

    _matchColleges(rank, exam) {
      return COLLEGE_CUTOFFS
        .filter(c => c.exam === exam && rank <= c.rank)
        .map(c => ({ name: c.name, branch: c.branch, status: rank <= c.rank * 0.8 ? 'safe' : 'borderline' }))
        .slice(0, 6);
    }

    _cutoffStatus(score, exam, category) {
      const table = (RANK_TABLE[exam] || {})[category] || RANK_TABLE[exam].general;
      const cutoffScore = exam === 'main' ? 90 : 90;
      const diff = score - cutoffScore;
      return {
        qualifies: score >= cutoffScore,
        margin: Math.abs(diff),
        message: diff >= 0
          ? `${diff} marks above estimated cutoff`
          : `${Math.abs(diff)} marks below estimated cutoff`
      };
    }

    _confidence(score, exam) {
      // Higher confidence near well-documented score ranges
      const main = exam === 'main';
      if (main && score >= 150 && score <= 280) return 'high';
      if (!main && score >= 90 && score <= 260) return 'high';
      return 'medium';
    }
  }

  // ═══════════════════════════════════════════════════════════
  // ENGINE 3 — SYLLABUS TRACKER
  // ═══════════════════════════════════════════════════════════
  /**
   * Tracks chapter completion across all subjects.
   * Status per chapter: 'not_started' | 'in_progress' | 'done' | 'needs_revision'
   *
   * mark(chapterId, status)
   * query() → { completion, subjects, pending, unlocked, nextRecommended }
   */
  class SyllabusTracker extends Engine {
    constructor() {
      super('syllabus');
      this._state = this._load('state', {});
    }

    mark(chapterId, status) {
      this._state[chapterId] = { status, updatedAt: Date.now() };
      this._save('state', this._state);
      EventBus.emit('syllabus:updated', { chapterId, status });
      return this.query();
    }

    getStatus(chapterId) {
      return (this._state[chapterId] || {}).status || 'not_started';
    }

    query() {
      const allChapters = [...SYLLABUS.physics, ...SYLLABUS.chemistry, ...SYLLABUS.mathematics];
      const subjects = { physics: SYLLABUS.physics, chemistry: SYLLABUS.chemistry, mathematics: SYLLABUS.mathematics };
      const result = { subjects: {}, completion: {}, pending: [], unlocked: [], nextRecommended: [] };

      for (const [subj, chapters] of Object.entries(subjects)) {
        const stats = { total:0, done:0, inProgress:0, notStarted:0, needsRevision:0, weightDone:0, weightTotal:0 };
        const chapterList = chapters.map(ch => {
          const status = this.getStatus(ch.id);
          const prereqsDone = ch.pre.every(p => this.getStatus(p) === 'done');
          stats.total++;
          stats[status === 'not_started' ? 'notStarted' : status === 'in_progress' ? 'inProgress' : status === 'done' ? 'done' : 'needsRevision']++;
          stats.weightTotal += ch.wt;
          if (status === 'done') stats.weightDone += ch.wt;
          if (status === 'not_started' && prereqsDone) result.unlocked.push({ ...ch, subject: subj });
          if (status !== 'done') result.pending.push({ ...ch, subject: subj, prereqsDone });
          return { ...ch, status, prereqsDone };
        });
        result.subjects[subj] = { ...stats, chapters: chapterList, weightCompletion: +(stats.weightDone/stats.weightTotal*100).toFixed(1) };
        result.completion[subj] = +(stats.done / stats.total * 100).toFixed(1);
      }

      // Overall completion
      result.completion.overall = +(Object.values(result.completion).reduce((a,b) => a+b, 0) / 3).toFixed(1);

      // Recommend by: unlocked + high weightage + not started
      result.nextRecommended = result.unlocked
        .filter(c => this.getStatus(c.id) === 'not_started')
        .sort((a, b) => b.wt - a.wt)
        .slice(0, 5);

      this.cache = result;
      this.lastUpdated = Date.now();
      this.isReady = true;
      return result;
    }

    reset() {
      this._state = {};
      this._save('state', {});
      EventBus.emit('syllabus:reset', {});
    }
  }

  // ═══════════════════════════════════════════════════════════
  // ENGINE 4 — WEAK AREA DETECTOR
  // ═══════════════════════════════════════════════════════════
  /**
   * Classifies chapters as weak/medium/strong based on accuracy history.
   * Calculates a priority score = JEE weightage × weakness factor.
   *
   * record(chapterId, { correct, attempted, subject })
   * query() → { weak, medium, strong, priorityList }
   */
  class WeakAreaDetector extends Engine {
    constructor() {
      super('weak');
      this._history = this._load('history', {});
    }

    /** Record a performance entry for a chapter */
    record(chapterId, { correct, attempted, subject }) {
      if (!this._history[chapterId]) this._history[chapterId] = [];
      this._history[chapterId].push({ correct, attempted, subject, ts: Date.now() });
      // Keep only last 10 entries per chapter
      if (this._history[chapterId].length > 10) this._history[chapterId].shift();
      this._save('history', this._history);
      EventBus.emit('weak:updated', { chapterId });
      return this.query();
    }

    /** Get accuracy for a chapter (weighted toward recent entries) */
    getAccuracy(chapterId) {
      const entries = this._history[chapterId];
      if (!entries || !entries.length) return null;
      let totalC = 0, totalA = 0;
      entries.forEach((e, i) => {
        const w = i + 1; // more recent = higher weight
        totalC += e.correct * w;
        totalA += e.attempted * w;
      });
      return totalA > 0 ? +(totalC / totalA * 100).toFixed(1) : null;
    }

    query() {
      const allChapters = [
        ...SYLLABUS.physics.map(c => ({...c, subject:'physics'})),
        ...SYLLABUS.chemistry.map(c => ({...c, subject:'chemistry'})),
        ...SYLLABUS.mathematics.map(c => ({...c, subject:'mathematics'}))
      ];

      const classified = { weak: [], medium: [], strong: [], untested: [] };
      const priorityList = [];

      for (const ch of allChapters) {
        const acc = this.getAccuracy(ch.id);
        const entries = this._history[ch.id] || [];
        const totalAttempts = entries.reduce((s, e) => s + e.attempted, 0);

        if (acc === null) {
          classified.untested.push({ ...ch, accuracy: null });
          continue;
        }

        const zone = acc < 45 ? 'weak' : acc < 70 ? 'medium' : 'strong';
        const weaknessFactor = zone === 'weak' ? 3 : zone === 'medium' ? 1.5 : 0.5;
        const priority = +(ch.wt * weaknessFactor).toFixed(1);

        const entry = { ...ch, accuracy: acc, zone, priority, attempts: totalAttempts };
        classified[zone].push(entry);

        if (zone !== 'strong') {
          priorityList.push(entry);
        }
      }

      // Sort by priority descending
      priorityList.sort((a, b) => b.priority - a.priority);
      classified.weak.sort((a, b) => b.priority - a.priority);

      const result = {
        ...classified,
        priorityList: priorityList.slice(0, 10),
        summary: {
          weak: classified.weak.length,
          medium: classified.medium.length,
          strong: classified.strong.length,
          untested: classified.untested.length,
        }
      };

      this.cache = result;
      this.lastUpdated = Date.now();
      this.isReady = true;
      return result;
    }

    reset(chapterId) {
      if (chapterId) {
        delete this._history[chapterId];
      } else {
        this._history = {};
      }
      this._save('history', this._history);
    }
  }

  // ═══════════════════════════════════════════════════════════
  // ENGINE 5 — REVISION SCHEDULER (SM-2 Algorithm)
  // ═══════════════════════════════════════════════════════════
  /**
   * Implements SuperMemo SM-2 spaced repetition.
   * Quality scale: 0 (blackout) → 5 (perfect recall)
   *
   * review(chapterId, quality)  — record a review session
   * getToday()                  — chapters due today
   * getOverdue()                — overdue chapters
   * getUpcoming(days)           — due in next N days
   */
  class RevisionScheduler extends Engine {
    constructor() {
      super('revision');
      this._cards = this._load('cards', {});
    }

    /** Initialize a chapter for spaced repetition */
    _initCard(chapterId) {
      if (!this._cards[chapterId]) {
        this._cards[chapterId] = {
          easeFactor: 2.5,
          interval: 0,
          repetitions: 0,
          nextReview: Date.now(), // due today initially
          lastReview: null,
          history: []
        };
      }
      return this._cards[chapterId];
    }

    /** Record a review. quality: 0-5 */
    review(chapterId, quality) {
      const card = this._initCard(chapterId);
      const q = Math.max(0, Math.min(5, quality));

      card.lastReview = Date.now();
      card.history.push({ quality: q, ts: Date.now() });
      if (card.history.length > 20) card.history.shift();

      if (q < 3) {
        // Failed: restart
        card.repetitions = 0;
        card.interval = 1;
      } else {
        // Passed: advance
        if (card.repetitions === 0)      card.interval = 1;
        else if (card.repetitions === 1) card.interval = 6;
        else card.interval = Math.round(card.interval * card.easeFactor);

        card.repetitions++;
        card.easeFactor = Math.max(1.3,
          card.easeFactor + 0.1 - (5 - q) * (0.08 + (5 - q) * 0.02)
        );
      }

      card.nextReview = Date.now() + card.interval * 86400000;
      this._save('cards', this._cards);
      EventBus.emit('revision:reviewed', { chapterId, quality: q, nextReview: card.nextReview });
      return card;
    }

    getToday() {
      const now = Date.now();
      const today = new Date(); today.setHours(23,59,59,999);
      return this._getDueCards(now, today.getTime());
    }

    getOverdue() {
      const now = Date.now();
      return this._getDueCards(0, now - 1);
    }

    getUpcoming(days = 7) {
      const now = Date.now();
      const future = now + days * 86400000;
      return this._getDueCards(now, future);
    }

    _getDueCards(from, to) {
      const allChapters = [
        ...SYLLABUS.physics.map(c => ({...c, subject:'physics'})),
        ...SYLLABUS.chemistry.map(c => ({...c, subject:'chemistry'})),
        ...SYLLABUS.mathematics.map(c => ({...c, subject:'mathematics'}))
      ];
      const result = [];
      for (const [id, card] of Object.entries(this._cards)) {
        if (card.nextReview >= from && card.nextReview <= to) {
          const chapter = allChapters.find(c => c.id === id);
          if (chapter) result.push({ ...chapter, ...card, daysUntil: Math.round((card.nextReview - Date.now()) / 86400000) });
        }
      }
      return result.sort((a, b) => a.nextReview - b.nextReview);
    }

    /** Add multiple chapters to the scheduler at once */
    addChapters(chapterIds) {
      chapterIds.forEach(id => this._initCard(id));
      this._save('cards', this._cards);
    }

    query() {
      const today = this.getToday();
      const overdue = this.getOverdue();
      const upcoming = this.getUpcoming(7);
      const result = { today, overdue, upcoming, totalScheduled: Object.keys(this._cards).length };
      this.cache = result;
      this.lastUpdated = Date.now();
      this.isReady = true;
      return result;
    }

    reset(chapterId) {
      if (chapterId) delete this._cards[chapterId];
      else this._cards = {};
      this._save('cards', this._cards);
    }
  }

  // ═══════════════════════════════════════════════════════════
  // ENGINE 6 — STUDY TIMER
  // ═══════════════════════════════════════════════════════════
  /**
   * Tracks study sessions per subject.
   * Calculates streaks, daily/weekly/monthly totals, heatmap data.
   *
   * start(subject)   — begin a session
   * stop()           — end current session
   * query()          → { today, weekly, monthly, streak, heatmap, bySubject }
   */
  class StudyTimer extends Engine {
    constructor() {
      super('timer');
      this._sessions = this._load('sessions', []);
      this._active   = this._load('active', null);
    }

    start(subject = 'General') {
      if (this._active) this.stop(); // auto-stop previous
      this._active = { subject, startMs: Date.now() };
      this._save('active', this._active);
      EventBus.emit('timer:started', { subject });
      return this._active;
    }

    stop() {
      if (!this._active) return null;
      const duration = Date.now() - this._active.startMs;
      if (duration < 60000) { // ignore sessions < 1 minute
        this._active = null;
        this._save('active', null);
        return null;
      }
      const session = {
        subject: this._active.subject,
        startMs: this._active.startMs,
        endMs: Date.now(),
        durationMs: duration,
        date: new Date().toISOString().slice(0, 10)
      };
      this._sessions.push(session);
      // Keep only last 365 days
      const cutoff = Date.now() - 365 * 86400000;
      this._sessions = this._sessions.filter(s => s.startMs > cutoff);
      this._save('sessions', this._sessions);
      this._active = null;
      this._save('active', null);
      EventBus.emit('timer:stopped', session);
      return session;
    }

    isRunning() { return !!this._active; }
    getActiveSubject() { return this._active?.subject || null; }
    getElapsed() { return this._active ? Date.now() - this._active.startMs : 0; }

    query() {
      const now = Date.now();
      const todayStr = new Date().toISOString().slice(0, 10);

      const sessionsInRange = (fromMs) => this._sessions.filter(s => s.startMs >= fromMs);
      const totalMs = (sessions) => sessions.reduce((s, x) => s + x.durationMs, 0);

      const todaySessions  = this._sessions.filter(s => s.date === todayStr);
      const weeklySessions = sessionsInRange(now - 7  * 86400000);
      const monthlySessions= sessionsInRange(now - 30 * 86400000);

      // By subject totals (this month)
      const bySubject = {};
      monthlySessions.forEach(s => {
        bySubject[s.subject] = (bySubject[s.subject] || 0) + s.durationMs;
      });

      // Heatmap: last 90 days
      const heatmap = {};
      sessionsInRange(now - 90 * 86400000).forEach(s => {
        heatmap[s.date] = (heatmap[s.date] || 0) + s.durationMs;
      });

      // Streak
      const streak = this._calcStreak();

      const fmt = ms => ({
        ms,
        minutes: Math.floor(ms / 60000),
        hours: +(ms / 3600000).toFixed(1),
        display: this._fmtDuration(ms)
      });

      const result = {
        today:   fmt(totalMs(todaySessions)),
        weekly:  fmt(totalMs(weeklySessions)),
        monthly: fmt(totalMs(monthlySessions)),
        streak,
        heatmap,
        bySubject: Object.fromEntries(Object.entries(bySubject).map(([k,v]) => [k, fmt(v)])),
        activeSession: this._active ? {
          subject: this._active.subject,
          elapsed: fmt(this.getElapsed())
        } : null,
        totalSessions: this._sessions.length
      };

      this.cache = result;
      this.lastUpdated = Date.now();
      this.isReady = true;
      return result;
    }

    _calcStreak() {
      const dates = [...new Set(this._sessions.map(s => s.date))].sort().reverse();
      if (!dates.length) return { current: 0, best: 0, lastStudied: null };
      let current = 0;
      const today = new Date().toISOString().slice(0, 10);
      let check = today;
      for (const d of dates) {
        if (d === check) {
          current++;
          const prev = new Date(check); prev.setDate(prev.getDate() - 1);
          check = prev.toISOString().slice(0, 10);
        } else if (d < check) break;
      }
      // Best streak (all-time)
      let best = 1, run = 1;
      for (let i = 1; i < dates.length; i++) {
        const d1 = new Date(dates[i-1]), d2 = new Date(dates[i]);
        const diff = Math.round((d1 - d2) / 86400000);
        if (diff === 1) { run++; best = Math.max(best, run); }
        else run = 1;
      }
      return { current, best, lastStudied: dates[0] || null };
    }

    _fmtDuration(ms) {
      const h = Math.floor(ms / 3600000);
      const m = Math.floor((ms % 3600000) / 60000);
      return h > 0 ? `${h}h ${m}m` : `${m}m`;
    }

    reset() {
      this._sessions = [];
      this._active = null;
      this._save('sessions', []);
      this._save('active', null);
    }
  }

  // ═══════════════════════════════════════════════════════════
  // JEECORE — Single facade for all engines
  // ═══════════════════════════════════════════════════════════
  class JEECore {
    constructor() {
      this.score    = new ScoreEngine();
      this.rank     = new RankEstimator();
      this.syllabus = new SyllabusTracker();
      this.weak     = new WeakAreaDetector();
      this.revision = new RevisionScheduler();
      this.timer    = new StudyTimer();
      this.bus      = EventBus;
      this._version = '1.0.0';
      this._initCrossEngineListeners();
    }

    /** Wire engines together: score update → weak area update → revision nudge */
    _initCrossEngineListeners() {
      // When syllabus marks a chapter done → add to revision scheduler
      EventBus.on('syllabus:updated', ({ chapterId, status }) => {
        if (status === 'done') this.revision.addChapters([chapterId]);
      });
    }

    /** Ping: returns isReady status of all engines */
    status() {
      return {
        score:    this.score.isReady,
        rank:     this.rank.isReady,
        syllabus: this.syllabus.isReady,
        weak:     this.weak.isReady,
        revision: this.revision.isReady,
        timer:    this.timer.isReady,
        version:  this._version,
      };
    }

    /** Returns the data a Context Builder would send to Gemini for a given question type */
    buildContext(questionType) {
      const ctx = { questionType, engines: {} };
      switch(questionType) {
        case 'what_to_study':
          ctx.engines.revision = this.revision.getToday();
          ctx.engines.overdue  = this.revision.getOverdue();
          ctx.engines.weak     = this.weak.cache?.priorityList?.slice(0,5);
          ctx.engines.syllabus = { completion: this.syllabus.cache?.completion };
          ctx.engines.timer    = { today: this.timer.cache?.today, streak: this.timer.cache?.streak };
          break;
        case 'performance_analysis':
          ctx.engines.score  = this.score.cache;
          ctx.engines.weak   = this.weak.cache;
          ctx.engines.rank   = this.rank.cache;
          break;
        case 'doubt':
          ctx.engines.syllabus = { currentChapter: this.syllabus.cache?.nextRecommended?.[0] };
          break;
        default:
          ctx.engines.weak = this.weak.cache?.summary;
      }
      return ctx;
    }

    /** Wipe all engine data (development/reset) */
    resetAll() {
      this.score._clear('last');
      this.syllabus.reset();
      this.weak.reset();
      this.revision.reset();
      this.timer.reset();
      console.warn('[JEECore] All engine data cleared.');
    }
  }

  // ── Expose globally ──────────────────────────────────────
  global.JEECore     = JEECore;
  global.JEEEventBus = EventBus;
  global.JEESyllabus = SYLLABUS;

})(typeof window !== 'undefined' ? window : this);
