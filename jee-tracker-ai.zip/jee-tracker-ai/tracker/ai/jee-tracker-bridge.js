/*!
 * jee-tracker-bridge.js — connects the AI engine stack to the JEE Battle Royale Tracker
 * ═══════════════════════════════════════════════════════════════════════════════
 * The tracker (index.html) keeps ALL of its data in localStorage under "jee-*" keys and
 * treats that as the single source of truth for every page of the app. This bridge is
 * therefore READ-ONLY: it never writes tracker keys, and it keeps no second copy of
 * progress. It turns the tracker's data into what the AI layer needs:
 *
 *   TrackerBridge.snapshot()            full normalised view of the tracker (memoised ~2 s)
 *   TrackerBridge.profile()             compact (<~700 B) student profile for Gemini prompts
 *   TrackerBridge.engineChapters()      Set of engine chapter ids the tracker's syllabus covers
 *   TrackerBridge.toEngineIds(id)       tracker chapter id  -> engine SYLLABUS ids (primary first)
 *   TrackerBridge.toTrackerIds(eid)     engine id -> tracker chapter ids
 *   TrackerBridge.install(core)         replaces the core's syllabus / weak / revision / timer / score
 *                                       registry entries with tracker-backed adapters and attaches
 *                                       the profile to every Gemini request
 *
 * Load order:  engines, formulas, quizbank, josaa, core, THEN this file, then call install(core).
 * Rules copied from index.html so the AI and the dashboard never disagree:
 *   checklist % = ticked items / 9 · complete at 90% · weak score = computeWeakSpots() ·
 *   revision due = completed >= 20 days ago and no chapter test logged since.
 */
(function (global) {
  'use strict';

  var COMPLETION_THRESHOLD = 90, REVISION_DUE_DAYS = 20, CHECK_ITEMS = 9, DAY = 86400000;
  // Generated from PHYSICS_/CHEMISTRY_/MATHS_CHAPTERS in index.html: id, name, subject, engine ids
  var CHAPTERS = [{"id": "phy-units-measurements", "n": "Units and Measurements", "s": "physics", "e": ["kin"]}, {"id": "phy-motion-straight-line", "n": "Motion in a Straight Line", "s": "physics", "e": ["kin"]}, {"id": "phy-motion-plane", "n": "Motion in a Plane", "s": "physics", "e": ["kin"]}, {"id": "phy-laws-motion", "n": "Laws of Motion", "s": "physics", "e": ["nlm"]}, {"id": "phy-work-energy-power", "n": "Work, Energy, and Power", "s": "physics", "e": ["wpe"]}, {"id": "phy-centre-mass-collisions", "n": "Centre of Mass and Collisions", "s": "physics", "e": ["com"]}, {"id": "phy-rotational-dynamics", "n": "Rotational Dynamics", "s": "physics", "e": ["rot"]}, {"id": "phy-gravitation", "n": "Gravitation", "s": "physics", "e": ["grav"]}, {"id": "phy-mech-properties-solids", "n": "Mechanical Properties of Solids", "s": "physics", "e": ["prop"]}, {"id": "phy-fluid-mechanics", "n": "Fluid Mechanics", "s": "physics", "e": ["prop"]}, {"id": "phy-thermal-properties-calorimetry", "n": "Thermal Properties of Matter & Calorimetry", "s": "physics", "e": ["heat"]}, {"id": "phy-kinetic-theory-gases", "n": "Kinetic Theory of Gases", "s": "physics", "e": ["ktg"]}, {"id": "phy-thermodynamics", "n": "Thermodynamics", "s": "physics", "e": ["heat"]}, {"id": "phy-oscillations-shm", "n": "Oscillations (Simple Harmonic Motion)", "s": "physics", "e": ["shm"]}, {"id": "phy-wave-motion-sound", "n": "Wave Motion and Sound Waves", "s": "physics", "e": ["wave"]}, {"id": "phy-electrostatics-charges-fields", "n": "Electrostatics (Electric Charges and Fields)", "s": "physics", "e": ["es"]}, {"id": "phy-electrostatic-potential-capacitance", "n": "Electrostatic Potential and Capacitance", "s": "physics", "e": ["cap", "es"]}, {"id": "phy-current-electricity", "n": "Current Electricity", "s": "physics", "e": ["cur"]}, {"id": "phy-magnetic-effects-current", "n": "Magnetic Effects of Current", "s": "physics", "e": ["mag"]}, {"id": "phy-magnetism-matter", "n": "Magnetism and Matter", "s": "physics", "e": ["mag"]}, {"id": "phy-electromagnetic-induction", "n": "Electromagnetic Induction", "s": "physics", "e": ["emi"]}, {"id": "phy-alternating-current", "n": "Alternating Current", "s": "physics", "e": ["emi"]}, {"id": "phy-em-waves", "n": "Electromagnetic Waves", "s": "physics", "e": ["wop"]}, {"id": "phy-ray-optics", "n": "Ray Optics and Optical Instruments", "s": "physics", "e": ["ray"]}, {"id": "phy-wave-optics", "n": "Wave Optics", "s": "physics", "e": ["wop"]}, {"id": "phy-dual-nature", "n": "Dual Nature of Radiation and Matter", "s": "physics", "e": ["mod"]}, {"id": "phy-atoms", "n": "Atoms", "s": "physics", "e": ["mod"]}, {"id": "phy-nuclei", "n": "Nuclei", "s": "physics", "e": ["mod"]}, {"id": "phy-semiconductor-electronics", "n": "Semiconductor Electronics", "s": "physics", "e": ["semi"]}, {"id": "phy-practical-skills", "n": "Experimental Skills (Practical Physics)", "s": "physics", "e": []}, {"id": "chem-mole-concept", "n": "Some Basic Concepts of Chemistry (Mole Concept)", "s": "chemistry", "e": ["mol"]}, {"id": "chem-atomic-structure", "n": "Atomic Structure", "s": "chemistry", "e": ["atm"]}, {"id": "chem-thermodynamics", "n": "Chemical Thermodynamics", "s": "chemistry", "e": ["therm"]}, {"id": "chem-equilibrium", "n": "Chemical Equilibrium", "s": "chemistry", "e": ["ceq"]}, {"id": "chem-ionic-equilibrium", "n": "Ionic Equilibrium", "s": "chemistry", "e": ["ieq"]}, {"id": "chem-redox-reactions", "n": "Redox Reactions", "s": "chemistry", "e": ["red"]}, {"id": "chem-solutions-colligative", "n": "Solutions and Colligative Properties", "s": "chemistry", "e": ["sol"]}, {"id": "chem-electrochemistry", "n": "Electrochemistry", "s": "chemistry", "e": ["elec"]}, {"id": "chem-kinetics", "n": "Chemical Kinetics", "s": "chemistry", "e": ["ckin"]}, {"id": "chem-periodicity", "n": "Classification of Elements and Periodicity in Properties", "s": "chemistry", "e": ["pt"]}, {"id": "chem-bonding", "n": "Chemical Bonding and Molecular Structure", "s": "chemistry", "e": ["cbond"]}, {"id": "chem-p-block", "n": "p-Block Elements", "s": "chemistry", "e": ["pblk"]}, {"id": "chem-d-f-block", "n": "d- and f-Block Elements", "s": "chemistry", "e": ["dblk"]}, {"id": "chem-coordination-compounds", "n": "Coordination Compounds", "s": "chemistry", "e": ["coord"]}, {"id": "chem-purification-characterisation", "n": "Purification and Characterisation of Organic Compounds", "s": "chemistry", "e": ["goc"]}, {"id": "chem-goc", "n": "General Organic Chemistry (GOC)", "s": "chemistry", "e": ["goc"]}, {"id": "chem-isomerism", "n": "Isomerism", "s": "chemistry", "e": ["goc"]}, {"id": "chem-hydrocarbons", "n": "Hydrocarbons (Alkanes, Alkenes, Alkynes, and Aromatic)", "s": "chemistry", "e": ["hc"]}, {"id": "chem-haloalkanes-haloarenes", "n": "Haloalkanes and Haloarenes", "s": "chemistry", "e": ["hal"]}, {"id": "chem-alcohols-phenols-ethers", "n": "Alcohols, Phenols, and Ethers", "s": "chemistry", "e": ["alc"]}, {"id": "chem-aldehydes-ketones-acids", "n": "Aldehydes, Ketones, and Carboxylic Acids", "s": "chemistry", "e": ["ald", "acid"]}, {"id": "chem-amines", "n": "Amines (Organic Compounds Containing Nitrogen)", "s": "chemistry", "e": ["ami"]}, {"id": "chem-biomolecules", "n": "Biomolecules", "s": "chemistry", "e": ["bio"]}, {"id": "chem-practical-chemistry", "n": "Principles Related to Practical Chemistry (Salt Analysis & Volumetric Analysis)", "s": "chemistry", "e": ["sblk"]}, {"id": "chem-everyday-chemistry", "n": "Chemical Principles in Everyday Chemistry", "s": "chemistry", "e": ["bio"]}, {"id": "math-sets-relations-functions", "n": "Sets, Relations, and Functions", "s": "maths", "e": ["sets", "fun"]}, {"id": "math-complex-numbers", "n": "Complex Numbers", "s": "maths", "e": ["cn"]}, {"id": "math-quadratic-equations", "n": "Quadratic Equations", "s": "maths", "e": ["qe"]}, {"id": "math-matrices", "n": "Matrices", "s": "maths", "e": ["mat"]}, {"id": "math-determinants", "n": "Determinants", "s": "maths", "e": ["mat"]}, {"id": "math-permutations-combinations", "n": "Permutations and Combinations", "s": "maths", "e": ["pnc"]}, {"id": "math-binomial-theorem", "n": "Binomial Theorem", "s": "maths", "e": ["bin"]}, {"id": "math-sequences-series", "n": "Sequences and Series (AP, GP, and Special Series)", "s": "maths", "e": ["seq"]}, {"id": "math-trig-identities-equations", "n": "Trigonometric Identities and Equations", "s": "maths", "e": ["trig"]}, {"id": "math-inverse-trig", "n": "Inverse Trigonometric Functions", "s": "maths", "e": ["itr"]}, {"id": "math-limits-continuity", "n": "Limits, Continuity, and Differentiability", "s": "maths", "e": ["lim"]}, {"id": "math-methods-differentiation", "n": "Methods of Differentiation", "s": "maths", "e": ["diff"]}, {"id": "math-applications-derivatives", "n": "Applications of Derivatives (Tangent, Normal, Monotonicity, Maxima-Minima)", "s": "maths", "e": ["aod"]}, {"id": "math-indefinite-integration", "n": "Indefinite Integration", "s": "maths", "e": ["iint"]}, {"id": "math-definite-integration", "n": "Definite Integration", "s": "maths", "e": ["dint"]}, {"id": "math-area-under-curves", "n": "Area Under Curves (Application of Integrals)", "s": "maths", "e": ["auc"]}, {"id": "math-differential-equations", "n": "Differential Equations", "s": "maths", "e": ["de"]}, {"id": "math-straight-lines", "n": "Straight Lines", "s": "maths", "e": ["sl"]}, {"id": "math-circles", "n": "Circles", "s": "maths", "e": ["cir"]}, {"id": "math-conic-sections", "n": "Conic Sections (Parabola, Ellipse, and Hyperbola)", "s": "maths", "e": ["para", "ell", "hyp"]}, {"id": "math-vector-algebra", "n": "Vector Algebra", "s": "maths", "e": ["vec"]}, {"id": "math-3d-geometry", "n": "Three-Dimensional Geometry", "s": "maths", "e": ["3d"]}, {"id": "math-statistics", "n": "Statistics", "s": "maths", "e": ["stat"]}, {"id": "math-probability", "n": "Probability", "s": "maths", "e": ["prob"]}, {"id": "math-mathematical-reasoning", "n": "Mathematical Reasoning / Mathematical Induction", "s": "maths", "e": ["sets"]}];
  var BY_ID = {}, BY_ENGINE = {};
  CHAPTERS.forEach(function (c) {
    BY_ID[c.id] = c;
    c.e.forEach(function (e) { (BY_ENGINE[e] = BY_ENGINE[e] || []).push(c.id); });
  });

  function read(key, fallback) {
    try { var r = global.localStorage.getItem(key); return r == null ? fallback : JSON.parse(r); }
    catch (e) { return fallback; }
  }
  function isoDay(d) { d = d || new Date(); var m = d.getMonth() + 1, dd = d.getDate(); return d.getFullYear() + '-' + (m < 10 ? '0' : '') + m + '-' + (dd < 10 ? '0' : '') + dd; }
  function daysBetween(a, b) { var x = new Date(a), y = new Date(b); return (isNaN(x) || isNaN(y)) ? 0 : Math.round((y - x) / DAY); }
  function norm(s) { return String(s == null ? '' : s).trim().toLowerCase(); }
  function matchTests(tests, name) {
    var n = norm(name);
    return tests.filter(function (t) { var tt = norm(t.topic); return tt && n && (tt === n || n.indexOf(tt) >= 0 || tt.indexOf(n) >= 0); });
  }
  function mistakes(t) { return Array.isArray(t.mistake) ? t.mistake : (typeof t.mistake === 'string' && t.mistake ? [t.mistake] : []); }
  function num(x) { x = Number(x); return isFinite(x) ? x : 0; }

  var memo = null, memoAt = 0;
  function snapshot(force) {
    var now = Date.now();
    if (!force && memo && now - memoAt < 2000) return memo;
    var today = isoDay();
    var progress = read('jee-progress', {}), tests = read('jee-chapter-tests', []), majors = read('jee-major-tests', []);
    var revCounts = read('jee-revision-counts', {}), lastRev = read('jee-last-revised-dates', {}), doneOn = read('jee-completion-dates', {});
    var hoursLog = read('jee-study-hours', []), streak = read('jee-streak', { currentStreak: 0, longestStreak: 0, lastActiveDate: null });
    var examDate = read('jee-exam-date', null), examType = read('jee-exam-type', 'both');
    var chapters = CHAPTERS.map(function (c) {
      var arr = progress[c.id] || [], ticked = arr.filter(Boolean).length, pct = Math.round(ticked / CHECK_ITEMS * 100);
      var matched = matchTests(tests, c.n), scored = matched.filter(function (t) { return num(t.questions) > 0; });
      var avg = scored.length ? Math.round(scored.reduce(function (s, t) { return s + num(t.myscore) / num(t.questions) * 100; }, 0) / scored.length) : null;
      // identical scoring to computeWeakSpots() in index.html
      var score = 0, reason = '';
      if (avg !== null) {
        score += Math.max(0, 100 - avg) * 2; reason = scored.length + ' test' + (scored.length === 1 ? '' : 's') + ' logged, avg ' + avg + '%';
        var mc = {}; matched.forEach(function (t) { mistakes(t).forEach(function (m) { if (m && m !== 'None') mc[m] = (mc[m] || 0) + 1; }); });
        var top = Object.keys(mc).sort(function (a, b) { return mc[b] - mc[a]; })[0];
        if (top) reason += ' — mostly: ' + top;
      }
      if (pct >= COMPLETION_THRESHOLD && matched.length === 0) { score += 60; reason = 'Checklist complete, 0 tests logged'; }
      else if (pct > 0 && pct < 50 && matched.length === 0) { score += 20; reason = reason || (pct + '% checklist, no tests yet'); }
      // identical to computeRevisionDue()
      var due = null, completedOn = doneOn[c.id];
      if (completedOn) {
        var since = daysBetween(completedOn, today);
        if (since >= REVISION_DUE_DAYS && !matched.some(function (t) { return t.date && daysBetween(completedOn, t.date) >= 0; })) due = since;
      }
      var status = due !== null ? 'needs_revision' : pct >= COMPLETION_THRESHOLD ? 'done' : (pct > 0 || (revCounts[c.id] || 0) > 0) ? 'in_progress' : 'not_started';
      return { id: c.id, name: c.n, subject: c.s, engineIds: c.e, pct: pct, ticked: ticked, status: status,
               tests: matched.length, avgTestPct: avg, weakScore: score, weakReason: reason,
               revisions: revCounts[c.id] || 0, lastRevised: lastRev[c.id] || null, revisionDueDays: due };
    });
    var bySubject = {};
    ['physics', 'chemistry', 'maths'].forEach(function (s) {
      var list = chapters.filter(function (c) { return c.subject === s; });
      bySubject[s] = { chapters: list.length, done: list.filter(function (c) { return c.pct >= COMPLETION_THRESHOLD; }).length,
                       avgPct: list.length ? Math.round(list.reduce(function (a, c) { return a + c.pct; }, 0) / list.length) : 0 };
    });
    var overallPct = Math.round(chapters.reduce(function (a, c) { return a + c.pct; }, 0) / chapters.length);
    var weak = chapters.filter(function (c) { return c.weakScore > 0; }).sort(function (a, b) { return b.weakScore - a.weakScore; });
    var revisionDue = chapters.filter(function (c) { return c.revisionDueDays !== null; }).sort(function (a, b) { return b.revisionDueDays - a.revisionDueDays; });
    // mocks
    var mocks = (majors || []).filter(function (m) { return num(m.maxmarks) > 0 && m.scored != null && m.scored !== ''; })
      .map(function (m) { return { name: m.name || 'Mock', date: m.date || '', scored: num(m.scored), max: num(m.maxmarks), pct: Math.round(num(m.scored) / num(m.maxmarks) * 100) }; })
      .sort(function (a, b) { return String(a.date).localeCompare(String(b.date)); });
    var lastMock = mocks[mocks.length - 1] || null, prev = mocks.slice(0, -1).slice(-3);
    var mockTrend = lastMock && prev.length ? lastMock.pct - Math.round(prev.reduce(function (a, m) { return a + m.pct; }, 0) / prev.length) : null;
    // study hours
    var hrs = function (e) { return num(e.physicsHours) + num(e.chemistryHours) + num(e.mathsHours); };
    var todayEntry = (hoursLog || []).filter(function (e) { return e.date === today; })[0];
    var weekAgo = isoDay(new Date(Date.now() - 6 * DAY));
    var week = (hoursLog || []).filter(function (e) { return e.date >= weekAgo && e.date <= today; });
    memo = {
      today: today,
      exam: { date: examDate, daysLeft: examDate && !isNaN(new Date(examDate)) ? daysBetween(today, examDate) : null, type: examType,
              targetScore: read('jee-target-score', null), marking: read('jee-marking-scheme', null) },
      completion: { overallPct: overallPct, bySubject: bySubject, doneChapters: chapters.filter(function (c) { return c.pct >= COMPLETION_THRESHOLD; }).length, totalChapters: chapters.length },
      chapters: chapters, weak: weak, revisionDue: revisionDue,
      selfWeakSubjects: read('jee-self-weak-subjects', []),
      mocks: mocks, lastMock: lastMock, mockTrend: mockTrend,
      study: { hoursToday: todayEntry ? Math.round(hrs(todayEntry) * 10) / 10 : 0, hoursWeek: Math.round(week.reduce(function (a, e) { return a + hrs(e); }, 0) * 10) / 10,
               bySubjectWeek: { physics: week.reduce(function (a, e) { return a + num(e.physicsHours); }, 0), chemistry: week.reduce(function (a, e) { return a + num(e.chemistryHours); }, 0), maths: week.reduce(function (a, e) { return a + num(e.mathsHours); }, 0) } },
      streak: { current: streak.currentStreak || 0, longest: streak.longestStreak || 0, lastActive: streak.lastActiveDate || null },
      hasData: Object.keys(progress).length > 0 || tests.length > 0 || majors.length > 0
    };
    memoAt = now; return memo;
  }

  function slim(c) { return { id: c.id, name: c.name, subject: c.subject, reason: c.weakReason, score: c.weakScore, engineIds: c.engineIds }; }

  /** Compact profile injected into Gemini prompts (keeps token use tiny). */
  function profile() {
    var s = snapshot();
    if (!s.hasData && s.exam.daysLeft === null) return null;
    var p = { examType: s.exam.type };
    if (s.exam.daysLeft !== null) p.daysToExam = s.exam.daysLeft;
    if (s.exam.targetScore) p.targetScore = s.exam.targetScore;
    p.syllabusDonePct = s.completion.overallPct;
    p.subjectPct = { physics: s.completion.bySubject.physics.avgPct, chemistry: s.completion.bySubject.chemistry.avgPct, maths: s.completion.bySubject.maths.avgPct };
    if (s.weak.length) p.topWeakChapters = s.weak.slice(0, 3).map(function (c) { return c.name + ' (' + c.weakReason + ')'; });
    if (s.revisionDue.length) p.revisionDueCount = s.revisionDue.length;
    if (s.lastMock) p.lastMock = s.lastMock.pct + '%' + (s.mockTrend !== null ? ' (' + (s.mockTrend >= 0 ? '+' : '') + s.mockTrend + ' vs previous 3)' : '');
    p.studyHoursToday = s.study.hoursToday; p.studyHoursWeek = s.study.hoursWeek; p.streakDays = s.streak.current;
    return p;
  }

  /** Engine-shaped adapters so ContextBuilder needs no changes. */
  function adapters() {
    function mk(getCache, extra) {
      var o = { isReady: true, get lastUpdated() { return memoAt || null; }, get cache() { return getCache(); }, query: function () { return getCache(); }, tracker: true };
      for (var k in (extra || {})) o[k] = extra[k];
      return o;
    }
    return {
      syllabus: mk(function () { var s = snapshot(); return { completion: s.completion, exam: s.exam }; }),
      weak: mk(function () { var s = snapshot(); return { priorityList: s.weak.slice(0, 10).map(slim), selfReportedWeakSubjects: s.selfWeakSubjects }; }),
      revision: mk(function () { return snapshot().revisionDue; }, {
        // tracker rule = "completed 20+ days ago, not retested"; it has no separate today/overdue split
        getToday: function () { return snapshot().revisionDue.slice(0, 10).map(function (c) { return { chapterId: c.id, name: c.name, subject: c.subject, daysSinceCompleted: c.revisionDueDays }; }); },
        getOverdue: function () { return []; }
      }),
      timer: mk(function () { var s = snapshot(); return { today: { hours: s.study.hoursToday }, week: { hours: s.study.hoursWeek, bySubject: s.study.bySubjectWeek }, streak: s.streak }; }),
      score: mk(function () { var s = snapshot(); return { lastMock: s.lastMock, recentMocks: s.mocks.slice(-5), trendVsPrev3: s.mockTrend, target: s.exam.targetScore }; })
    };
  }

  function install(core) {
    if (!core || !core.registry) throw new Error('TrackerBridge.install(core): pass a JEEAICoreV2 instance');
    var a = adapters();
    Object.keys(a).forEach(function (k) { core.registry.register(k, a[k]); });
    core.profileProvider = profile;             // read by JEEAICoreV2.ask()
    core.tracker = TrackerBridge;
    return core;
  }

  var TrackerBridge = {
    snapshot: snapshot, profile: profile, install: install, adapters: adapters,
    chapters: function () { return CHAPTERS.slice(); },
    toEngineIds: function (id) { return BY_ID[id] ? BY_ID[id].e.slice() : []; },
    toTrackerIds: function (eid) { return (BY_ENGINE[eid] || []).slice(); },
    engineChapters: function () { return new Set(Object.keys(BY_ENGINE)); },
    constants: { COMPLETION_THRESHOLD: COMPLETION_THRESHOLD, REVISION_DUE_DAYS: REVISION_DUE_DAYS }
  };
  global.TrackerBridge = TrackerBridge;
  if (typeof module !== 'undefined' && module.exports) module.exports = TrackerBridge;
})(typeof window !== 'undefined' ? window : globalThis);
