import json,collections,datetime,pathlib
HERE=pathlib.Path(__file__).resolve().parent
rows=json.load(open(HERE/'questions.json'))
data=json.dumps(rows,ensure_ascii=False,separators=(',',':'))
data=data.replace('</script','<\\/script')
header=f'''/*!
 * jee-quizbank.js — Phase 2 offline question bank (v2)
 * {len(rows)} real JEE Main PYQs (text-only) from eQOURSE/jee-main-questions, replacing the 50 hand-written questions.
 * Exports: LocalQuizBank, JEE_QUESTIONS_RAW   (global or CommonJS)
 * Schema is backward compatible; additive fields: t ('mcq'|'num'), num (numerical answer), src (source id).
 * Numerical questions have opts:[] and ans:-1 and are EXCLUDED by default — pass includeNumerical:true to get them.
 * localStorage keys: jee_qbank_seen, jee_qbank_wrong, jee_qbank_correct (JSON arrays of question ids)
 */
'''
body=r'''
(function (global) {
  'use strict';
  var JEE_QUESTIONS_RAW = __DATA__;

  var K_SEEN = 'jee_qbank_seen', K_WRONG = 'jee_qbank_wrong', K_CORRECT = 'jee_qbank_correct';
  var LS = (function () { try { var t = '__q'; global.localStorage.setItem(t, t); global.localStorage.removeItem(t); return global.localStorage; } catch (e) { return null; } })();
  var mem = {};
  function load(k) { try { var v = LS ? LS.getItem(k) : mem[k]; return v ? JSON.parse(v) : []; } catch (e) { return []; } }
  function save(k, arr) { var s = JSON.stringify(arr); try { if (LS) LS.setItem(k, s); else mem[k] = s; } catch (e) { mem[k] = s; } }
  function shuffle(a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function copy(q) { return JSON.parse(JSON.stringify(q)); }

  function LocalQuizBank(questions) {
    this.questions = questions || JEE_QUESTIONS_RAW;
    this.byId = {};
    for (var i = 0; i < this.questions.length; i++) this.byId[this.questions[i].id] = this.questions[i];
    this.seen = load(K_SEEN); this.wrong = load(K_WRONG); this.correct = load(K_CORRECT);
  }
  var P = LocalQuizBank.prototype;

  P._filter = function (o) {
    o = o || {};
    return this.questions.filter(function (q) {
      if (o.subject && q.s !== (o.subject === 'maths' || o.subject === 'math' ? 'mathematics' : o.subject)) return false;
      if (o.chapter && q.ch !== o.chapter) return false;
      if (o.difficulty && q.d !== o.difficulty) return false;
      if (o.frequency && q.f !== o.frequency) return false;
      if (o.type && q.t !== o.type) return false;
      if (!o.includeNumerical && q.t === 'num') return false;
      return true;
    });
  };
  P.getRandom = function (o) {
    o = o || {}; var n = o.count || 5;
    return shuffle(this._filter(o)).slice(0, n).map(copy);
  };
  P.getUnseen = function (o) {
    o = o || {}; var n = o.count || 5, seen = this.seen;
    var pool = this._filter(o).filter(function (q) { return seen.indexOf(q.id) < 0; });
    return shuffle(pool).slice(0, n).map(copy);
  };
  P.getWrong = function (o) {
    o = o || {}; var wrong = this.wrong;
    var o2 = {}; for (var k in o) o2[k] = o[k]; o2.includeNumerical = true;
    var res = this._filter(o2).filter(function (q) { return wrong.indexOf(q.id) >= 0; }).map(copy);
    return o.count ? res.slice(0, o.count) : res;
  };
  P.getById = function (id) { var q = this.byId[id]; return q ? copy(q) : null; };
  P.getChapters = function (subject) {
    var m = {};
    this.questions.forEach(function (q) { if (!subject || q.s === (subject === 'maths' ? 'mathematics' : subject)) { var k = q.s + ':' + q.ch; m[k] = m[k] || { subject: q.s, chapter: q.ch, count: 0 }; m[k].count++; } });
    return Object.keys(m).map(function (k) { return m[k]; });
  };
  // selected: option index (mcq) or the typed value (numerical)
  P.checkAnswer = function (id, selected) {
    var q = this.byId[id]; if (!q) return null;
    var ok;
    if (q.t === 'num') {
      var v = parseFloat(String(selected).replace(/,/g, ''));
      ok = !isNaN(v) && Math.abs(v - q.num) <= Math.max(0.01, Math.abs(q.num) * 0.01);
    } else ok = (selected === q.ans);
    if (this.seen.indexOf(id) < 0) this.seen.push(id);
    var wi = this.wrong.indexOf(id), ci = this.correct.indexOf(id);
    if (ok) { if (ci < 0) this.correct.push(id); if (wi >= 0) this.wrong.splice(wi, 1); }
    else { if (wi < 0) this.wrong.push(id); if (ci >= 0) this.correct.splice(ci, 1); }
    save(K_SEEN, this.seen); save(K_WRONG, this.wrong); save(K_CORRECT, this.correct);
    return { correct: ok, correctIdx: q.ans, correctAnswer: q.t === 'num' ? q.num : q.opts[q.ans], solution: q.sol, concept: q.concept, chapter: q.ch };
  };
  P.getStats = function () {
    var self = this, by = {};
    this.questions.forEach(function (q) {
      var b = by[q.s] = by[q.s] || { total: 0, seen: 0, correct: 0, wrong: 0 };
      b.total++;
      if (self.seen.indexOf(q.id) >= 0) b.seen++;
      if (self.correct.indexOf(q.id) >= 0) b.correct++;
      if (self.wrong.indexOf(q.id) >= 0) b.wrong++;
    });
    var seen = this.seen.length, c = this.correct.length;
    return { total: this.questions.length, seen: seen, correct: c, wrong: this.wrong.length, accuracy: seen ? Math.round(c / seen * 100) : 0, bySubject: by };
  };
  P.reset = function () { this.seen = []; this.wrong = []; this.correct = []; save(K_SEEN, []); save(K_WRONG, []); save(K_CORRECT, []); };
  Object.defineProperty(P, 'count', { get: function () { return this.questions.length; } });

  global.LocalQuizBank = LocalQuizBank; global.JEE_QUESTIONS_RAW = JEE_QUESTIONS_RAW;
  if (typeof module !== 'undefined' && module.exports) module.exports = { LocalQuizBank: LocalQuizBank, JEE_QUESTIONS_RAW: JEE_QUESTIONS_RAW };
})(typeof window !== 'undefined' ? window : globalThis);
'''.replace('__DATA__',data)
open(HERE.parent/'tracker'/'ai'/'jee-quizbank.js','w',encoding='utf-8').write(header+body)
