import json,glob,re,collections,os,sys,pathlib
HERE=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from mapping import map_chapter
# Point at the folder that contains physics/ chemistry/ mathematics/ (the Hugging Face eQOURSE/jee-main-questions snapshot)
DATASET=sys.argv[1] if len(sys.argv)>1 else os.environ.get('DATASET_DIR','dataset')
base=DATASET.rstrip('/')+'/'
if not os.path.isdir(base+'physics'): sys.exit('Dataset not found. Usage: python quizbank-build/build.py <dataset-folder>')
SUBJ={'physics':('p','physics'),'chemistry':('c','chemistry'),'mathematics':('m','mathematics')}
stats=collections.Counter()
def norm_diff(d):
    d=(d or '').strip().lower()
    if not d: return 'medium'
    if 'easy' in d and ('moderate' in d or 'tough' in d): return 'medium'
    if d.startswith('easy'): return 'easy'
    if d.startswith('mod') or d.startswith('med') or d.endswith('moderate'): return 'medium'
    if 'tough' in d or 'hard' in d: return 'hard'
    return 'medium'
FIG=re.compile(r'\b(figure|fig\.|diagram|as shown|shown (below|above|in)|graph (shown|given|below)|following (graph|figure|circuit|diagram))',re.I)
def clean(t):
    t=(t or '').replace('\r','').strip()
    t=re.sub(r'[ \t]+\n','\n',t)
    return t
def qclean(t):
    return re.sub(r'\s*\n\s*',' ',clean(t))
def oclean(t):
    t=qclean(t)
    t=re.sub(r'^\(?[A-Da-d1-4][\).]\s+','',t) if re.match(r'^\(?[A-Da-d1-4][\).]\s+\S',t) else t
    return t
def parse_num(x):
    s=str(x).strip().replace(',','')
    try:
        v=float(s)
        return int(v) if v==int(v) else v
    except: return None
LEGCH=re.compile(r'[\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u00FF\u0152\u0153\u0160\u02C6]')
LEGTOK=re.compile(r'\b(gSA?|rks|dks|esa|ij|vkSj|fdl|tks|nzo|uyh|ckgj|rkfd|osx|Kkr|djks|gksxk|gksxh|ykxrk|fn;k|fcUnq|dqy)\b')
class _L:
    def search(self,q):
        return bool(LEGCH.search(q)) or len(LEGTOK.findall(q))>=1 or bool(re.search(r'\w`\w',q))
LEG=_L()
def garbage(q):
    ql=q.lower()
    if len(q)<25: return True
    if 'four choices' in ql or 'integer answer type' in ql or 'are integer' in ql or 'numerical value type' in ql: return True
    if re.search(r'[\u0900-\u097F]',q): return True
    if LEG.search(q): return True  # mangled Hindi (legacy-font) text mixed into the question
    return False
# Translate to the real SYLLABUS ids in jee-engines.js
TO_SYLLABUS={
 # physics
 'waves':'wave','sem':'semi','ac':'emi','emw':'wop','units':'kin',
 # chemistry
 'bond':'cbond','atom':'atm','ptab':'pt','redox':'red','hyd':'hc','met':'metal',
 'gas':'ss','solid':'ss','sur':'ss','env':'pblk','eda':'bio','nuc':'mod',
}
out=[];seen_text=set()
for sfull,(pref,sname) in SUBJ.items():
    for sp in ['train','test']:
        for l in open(f'{base}{sfull}/{sp}.jsonl'):
            r=json.loads(l); stats['total']+=1
            if r.get('question_images'): stats['drop_image']+=1; continue
            q=qclean(r['question'])
            if garbage(q): stats['drop_garbage']+=1; continue
            if FIG.search(q): stats['drop_figure_ref']+=1; continue
            key=re.sub(r'\W+','',q.lower())[:200]
            if key in seen_text: stats['drop_dup']+=1; continue
            ch,how=map_chapter(sfull,r['topic'],r['subtopic'],q)
            if not ch: stats['drop_unmapped']+=1; continue
            ch=TO_SYLLABUS.get(ch,ch)
            sol=clean(r.get('solution'))
            if r['question_type']=='numerical':
                v=parse_num(r['numerical_answer'])
                if v is None: stats['drop_bad_numeric']+=1; continue
                item=dict(t='num',opts=[],ans=-1,num=v)
            else:
                o=[oclean(r.get(f'option_{i}')) for i in range(1,5)]
                if any(not x for x in o): stats['drop_missing_opts']+=1; continue
                if any(LEG.search(x) for x in o): stats['drop_garbage']+=1; continue
                if len(set(o))<4: stats['drop_dup_opts']+=1; continue
                co=r['correct_option']
                if co not in (1,2,3,4): stats['drop_bad_answer']+=1; continue
                if any(FIG.search(x) for x in o): stats['drop_figure_ref']+=1; continue
                item=dict(t='mcq',opts=o,ans=co-1)
            seen_text.add(key)
            if not sol:
                stats['no_solution']+=1
                sol=('Answer: option %s.'%'ABCD'[item['ans']]) if item['t']=='mcq' else 'Answer: %s.'%item['num']
            concept=(r['subtopic'] or r['topic'] or '').strip()
            if concept.lower() in ('physical chemistry','organic chemistry','inorganic chemistry','mechanics'): concept=''
            item.update(s=sname,ch=ch,d=norm_diff(r['difficulty']),q=q,sol=sol,concept=concept,src=r['question_id'])
            out.append(item); stats['kept_'+item['t']]+=1
# frequency by chapter share within subject: top third common, middle moderate, rest rare
cc=collections.Counter((i['s'],i['ch']) for i in out)
for s in ['physics','chemistry','mathematics']:
    chs=sorted([c for (ss,c) in cc if ss==s],key=lambda c:-cc[(s,c)])
    n=len(chs)
    for idx,c in enumerate(chs):
        f='common' if idx<n/3 else ('moderate' if idx<2*n/3 else 'rare')
        for i in out:
            if i['s']==s and i['ch']==c: i['f']=f
# ids
ctr=collections.Counter();pref={'physics':'p','chemistry':'c','mathematics':'m'}
for i in out:
    k=(i['s'],i['ch']); ctr[k]+=1
    i['id']='%s_%s_%02d'%(pref[i['s']],i['ch'],ctr[k])
order=['id','s','ch','d','f','t','q','opts','ans','num','sol','concept','src']
rows=[{k:i[k] for k in order if k in i} for i in out]
json.dump(rows,open(HERE/'questions.json','w'),ensure_ascii=False)
print(dict(stats)); print(len(rows))
print(collections.Counter((i['s'],i['d']) for i in out))
print(collections.Counter((i['s'],i['t']) for i in out))
import sys
json.dump({f'{s}:{c}':n for (s,c),n in cc.items()},open(HERE/'chapter_counts.json','w'),indent=1)
