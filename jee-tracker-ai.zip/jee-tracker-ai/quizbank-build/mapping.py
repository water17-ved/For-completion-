import re
# topic/subtopic (lowercased substring) -> chapter id. First match wins. Order matters.
PHYS = [
 ('rigid body','rot'),('rotation','rot'),('moment of inertia','rot'),('torque','rot'),('angular momentum','rot'),
 ('centre of mass','com'),('center of mass','com'),('system of particles','com'),('collision','com'),
 ('newton','nlm'),('friction','nlm'),('circular motion','nlm'),
 ('work power','wpe'),('work, power','wpe'),('energy','wpe'),
 ('projectile','kin'),('relative motion','kin'),('motion in 1d','kin'),('kinematics','kin'),('motion in a','kin'),
 ('unit and dimension','units'),('error','units'),('dimension','units'),('vernier','units'),('screw gauge','units'),
 ('gravitation','grav'),('satellite','grav'),
 ('fluid','prop'),('liquid','prop'),('surface tension','prop'),('viscos','prop'),('elastic','prop'),('mechanical properties','prop'),
 ('simple harmonic','shm'),('oscillation','shm'),('shm','shm'),
 ('em wave','emw'),('e-m wave','emw'),('electromagnetic wave','emw'),
 ('wave optics','wop'),
 ('wave on','waves'),('sound','waves'),('string wave','waves'),('doppler','waves'),('standing wave','waves'),('wave','waves'),
 ('kinetic theory','ktg'),('ktg','ktg'),
 ('thermodynamic','heat'),('thermal','heat'),('calorimetry','heat'),('heat','heat'),('radiation','heat'),
 ('capacit','cap'),('electrostat','es'),('gauss','es'),('electric field','es'),('electric potential','es'),
 ('current electricity','cur'),('electric current','cur'),('kirchhoff','cur'),('potentiometer','cur'),('meter bridge','cur'),('wheatstone','cur'),
 ('moving charge','mag'),('magnetic effect','mag'),('magnetism','mag'),('magnetics','mag'),('magnet','mag'),
 ('electromagnetic induction','emi'),('emi','emi'),('inductance','emi'),
 ('alternating','ac'),('ac circuit','ac'),('ac','ac'),
 ('em wave','emw'),('e-m wave','emw'),('electromagnetic wave','emw'),
 ('wave optics','wop'),('interference','wop'),('diffraction','wop'),('young','wop'),
 ('ray optics','ray'),('optical instrument','ray'),('lens','ray'),('mirror','ray'),('prism','ray'),('optics','ray'),
 ('modern physics','mod'),('atomic','mod'),('dual nature','mod'),('photoelectric','mod'),('nuclei','mod'),('nuclear','mod'),('bohr','mod'),
 ('communication','sem'),('electronic device','sem'),('semiconductor','sem'),('logic gate','sem'),
]
PHYS_KW = [
 (r'moment of inertia|angular (momentum|velocity)|torque|rolling|rigid','rot'),
 (r'centre of mass|center of mass|collision|elastic collision|recoil','com'),
 (r'projectile|thrown|velocity.*time|acceleration|kinematic|relative velocity|falls? (freely|from)|river|boat','kin'),
 (r'friction|inclined plane|pulley|newton|block.*mass|tension in','nlm'),
 (r'work done|kinetic energy|potential energy|power|conservative','wpe'),
 (r'gravitational|escape velocity|orbit|satellite|kepler','grav'),
 (r'surface tension|viscos|bernoulli|density|pressure|young.s modulus|stress|strain|capillary|terminal velocity|bulk modulus','prop'),
 (r'simple harmonic|oscillat|spring|time period','shm'),
 (r'sound|wave|frequency|beats?|resonance|organ pipe|doppler|string','waves'),
 (r'ideal gas|rms speed|degrees of freedom|mean free path|kinetic theory','ktg'),
 (r'heat|calorimet|thermodynamic|isothermal|adiabatic|carnot|specific heat|temperature|entropy|latent|conduct|black ?body|stefan|wien','heat'),
 (r'capacitor|capacitance|dielectric','cap'),
 (r'electric field|charge|coulomb|gauss|dipole|electric potential|electrostatic','es'),
 (r'resistance|resistor|battery|emf|ammeter|voltmeter|current|potentiometer|wheatstone|drift','cur'),
 (r'magnetic field|solenoid|biot|ampere|cyclotron|galvanometer|magnetic moment|lorentz','mag'),
 (r'induced|inductance|flux|faraday|lenz|eddy','emi'),
 (r'ac source|rms current|impedance|reactance|lcr|transformer|resonant','ac'),
 (r'electromagnetic wave|poynting|em wave','emw'),
 (r'interference|diffraction|young.s double|fringe|polari[sz]|slit|coherent','wop'),
 (r'lens|mirror|refractive|refraction|prism|microscope|telescope|focal|total internal|image','ray'),
 (r'photoelectric|work function|de.?broglie|hydrogen atom|bohr|nuclei|nuclear|radioactiv|half.?life|binding energy|x.?ray|photon|decay','mod'),
 (r'semiconductor|diode|transistor|logic gate|modulation|amplitude modulated|carrier|band gap|zener','sem'),
 (r'dimension|significant figure|least count|vernier|screw gauge|percentage error|unit','units'),
]
CHEM = [
 ('coordination','coord'),('werner','coord'),('crystal field','coord'),('valence bond theory and crystal','coord'),
 ('chemical bonding','bond'),('molecular orbital','bond'),('vsepr','bond'),('hybridi','bond'),('bonding','bond'),
 ('atomic structure','atom'),('bohr model','atom'),('quantum','atom'),
 ('periodic','ptab'),
 ('chemical kinetics','ckin'),('kinetics','ckin'),
 ('ionic equilibrium','ieq'),('chemical and ionic','ceq'),('chemical equilibrium','ceq'),('equilibrium','ceq'),
 ('thermodynamics','therm'),('thermochem','therm'),
 ('electrochem','elec'),
 ('redox','redox'),
 ('mole concept','mol'),('equivalent concept','mol'),('some basic concepts','mol'),('stoichiometry','mol'),('eudiometry','mol'),
 ('gaseous','gas'),('ideal gas','gas'),('real gas','gas'),('vander','gas'),('van der','gas'),('gas','gas'),
 ('solid state','solid'),('hcp','solid'),('ccp','solid'),('simple cubic','solid'),('bcc','solid'),('unit cell','solid'),
 ('solution','sol'),('colligative','sol'),
 ('surface chemistry','sur'),('colloid','sur'),
 ('nuclear','nuc'),
 ('metallurgy','met'),
 ('environmental','env'),
 ('everyday','eda'),
 ('biomolecule','bio'),('polymer','bio'),
 ('hydrocarbon','hyd'),('alkane','hyd'),('alkene','hyd'),('alkyne','hyd'),('aromatic','hyd'),
 ('haloalkane','hal'),('halogen derivative','hal'),
 ('alcohol','alc'),('phenol','alc'),('ether','alc'),
 ('carboxylic','acid'),('aldehydes, ketones & carboxylic','ald'),('aldehyde','ald'),('ketone','ald'),('carbonyl','ald'),
 ('amine','ami'),('containing nitrogen','ami'),
 ('iupac','goc'),('isomer','goc'),('stereo','goc'),('some basic principles','goc'),('reaction mechanism','goc'),('structure identification','goc'),('goc','goc'),('organic chemistry','goc'),('poc','goc'),
 ('salt analysis','sblk'),('s-block','sblk'),('s block','sblk'),('hydrogen','sblk'),
 ('d & f','dblk'),('d and f','dblk'),('d-block','dblk'),('f-block','dblk'),
 ('p-block','pblk'),('p block','pblk'),('inorganic chemistry','pblk'),
]
CHEM_KW = [
 (r'coordination|complex|ligand|\[.*\(.*\).*\]|crystal field|cfse','coord'),
 (r'hybridi[sz]ation|bond order|molecular orbital|dipole moment|bond angle|shape of|vsepr|geometry','bond'),
 (r'orbital|quantum number|de.?broglie|wavelength|bohr|electronic configuration|uncertainty','atom'),
 (r'ionisation|ionization|electronegativ|atomic radius|electron gain|periodic','ptab'),
 (r'rate constant|order of reaction|half.?life|activation energy|rate law|arrhenius','ckin'),
 (r'\bph\b|buffer|solubility product|ksp|degree of dissociation|hydrolysis','ieq'),
 (r'equilibrium|kc\b|kp\b|le chatelier','ceq'),
 (r'enthalpy|entropy|gibbs|heat capacity|adiabatic|isothermal|spontaneous|internal energy','therm'),
 (r'electrode|emf|cell potential|nernst|electrolysis|conductivity|faraday|molar conductance','elec'),
 (r'oxidation (number|state)|oxidising|reducing agent|redox|disproportionation|balanc','redox'),
 (r'mole|molar mass|molarity|molality|stoichiometr|equivalent|empirical formula|limiting reagent|% by mass','mol'),
 (r'ideal gas|compressibility|van der waals|graham|critical temperature|rms|vapou?r pressure of a gas','gas'),
 (r'unit cell|lattice|packing|coordination number of|fcc|bcc|voids|crystal','solid'),
 (r'colligative|boiling point elevation|freezing point|osmotic|raoult|van.?t hoff|vapou?r pressure|solution','sol'),
 (r'adsorption|colloid|micelle|freundlich|emulsion|tyndall','sur'),
 (r'ore\b|extraction|smelting|roasting|metallurgy|calcination|froth','met'),
 (r'ozone|acid rain|greenhouse|smog|pollut|bod\b|cod\b','env'),
 (r'protein|carbohydrate|glucose|amino acid|nucleic|vitamin|dna|rna|polymer|nylon|bakelite|monomer','bio'),
 (r'alkene|alkyne|alkane|benzene|electrophilic|markovnikov|ozonolysis|hydroboration|aromatic','hyd'),
 (r'alkyl halide|haloalkane|sn1|sn2|chlorobenzene|grignard','hal'),
 (r'alcohol|phenol|\bether|williamson|lucas|kolbe|reimer','alc'),
 (r'carboxylic|esterification|acid derivative|acyl','acid'),
 (r'aldehyde|ketone|aldol|cannizzaro|clemmensen|wolff|tollens|benedict','ald'),
 (r'amine|diazonium|hinsberg|gabriel|aniline|carbylamine|nitro compound','ami'),
 (r'iupac|isomer|carbocation|hyperconjugation|inductive|resonance|nucleophil|tautomer|optical activity|chiral|enantiomer|e/z|acidic strength|basic strength','goc'),
 (r'\bs.?block|alkali|alkaline earth|sodium|potassium|calcium|magnesium|lithium|hydrogen peroxide|water|plaster of paris|salt analysis|flame test','sblk'),
 (r'lanthan|actinoid|transition|kmno4|k2cr2o7|d.?block|f.?block|magnetic moment|spin only','dblk'),
 (r'nitrogen|phosph|sulphur|sulfur|halogen|noble gas|oxoacid|group 1[5-8]|interhalogen|xenon|nh3|so2|h2so4|hno3|ozone|boron|carbon|silicon|borax|aluminium','pblk'),
]
MATH = [
 ('straight line','sl'),('pair of straight','sl'),('coordinate geometry','sl'),
 ('circle and parabola','cir'),('circle','cir'),
 ('parabola','para'),('ellipse','ell'),('hyperbola','hyp'),('conic','para'),
 ('binomial','bin'),
 ('quadratic','qe'),('theory of equation','qe'),('thoery of equation','qe'),('inequalit','qe'),('logarithm','qe'),('polynomial','qe'),
 ('complex number','cn'),
 ('vector','vec'),
 ('3d','3d'),('three dimension','3d'),('three-dimension','3d'),
 ('sequence','seq'),('series','seq'),('progression','seq'),
 ('permutation','pnc'),('pemutation','pnc'),('combination','pnc'),
 ('probability','prob'),
 ('inverse trig','itr'),('itf','itr'),
 ('trigonometr','trig'),('compound angle','trig'),('triangle','trig'),('height and distance','trig'),
 ('differential equation','de'),
 ('area under','auc'),
 ('application of derivative','aod'),('monoton','aod'),('maxima','aod'),('tangent and normal','aod'),
 ('definite integr','dint'),
 ('indefinite integr','iint'),('integral','iint'),('integration','iint'),
 ('continuity','diff'),('derivab','diff'),('differentiab','diff'),('differentiation','diff'),('differcntiation','diff'),
 ('limit','lim'),
 ('matri','mat'),('determinant','mat'),
 ('statistic','stat'),('mean deviation','stat'),
 ('function','fun'),('relation','sets'),('set','sets'),('mathematical reasoning','sets'),('logical reasoning','sets'),('mathematical induction','sets'),
]
MATH_KW = [
 (r'straight line|\bline\b.*(passes|perpendicular|parallel|slope)|slope|intercept|centroid|orthocent|locus|distance of the point','sl'),
 (r'circle|radius|chord|tangent to the circle','cir'),
 (r'parabola|latus|focus|directrix','para'),
 (r'hyperbola','hyp'),
 (r'ellipse|eccentricity','ell'),
 (r'binomial|coefficient of x|expansion of|\bc\(|\^\{?n\}?c','bin'),
 (r'quadratic|roots? of|discriminant|polynomial|log_|logarithm|inequal','qe'),
 (r'complex number|\bz\b|argument|modulus|iota|amplitude|\\omega|cube root of unity','cn'),
 (r'vector|\\vec|\\hat|cross product|dot product|scalar triple','vec'),
 (r'plane|direction (cosines|ratios)|skew lines|line.*\bx-\d','3d'),
 (r'a\.?p\.?|g\.?p\.?|h\.?p\.?|sequence|series|sum of the first|arithmetic|geometric|harmonic','seq'),
 (r'permutation|combination|arrangements?|ways|selections?|committee|words|digits','pnc'),
 (r'probability|dice|die|coin|random|bayes|expectation|variance of|distribution','prob'),
 (r'sin\^\{-1\}|cos\^\{-1\}|tan\^\{-1\}|inverse trig','itr'),
 (r'sin|cos|tan|trigonometric|cot|sec|triangle abc','trig'),
 (r'differential equation|dy/dx|\\frac\{dy\}\{dx\}.*=|solution curve|order and degree','de'),
 (r'area (of|bounded|enclosed)|region bounded','auc'),
 (r'maxima|minima|increasing|decreasing|monoton|tangent to the curve|normal to the curve|rolle|lagrange|mean value','aod'),
 (r'\\int_','dint'),
 (r'\\int|integral|antiderivative','iint'),
 (r'continuous|differentiable|derivative|f\'','diff'),
 (r'\\lim|limit','lim'),
 (r'matrix|matrices|determinant|adjoint|inverse of|\\begin\{vmatrix\}|\\begin\{bmatrix\}','mat'),
 (r'mean|median|standard deviation|variance|mode of','stat'),
 (r'function|domain|range|onto|one.?one|bijective|composition','fun'),
 (r'relation|set|\\cup|\\cap|reflexive|symmetric|tautology|statement','sets'),
]
def _try(rules, text):
    t=(text or '').lower()
    for k,c in rules:
        if k in t: return c
    return None
def _kw(rules,text):
    t=(text or '').lower()
    for pat,c in rules:
        if re.search(pat,t): return c
    return None
def map_chapter(subject, topic, subtopic, question):
    s=subject.lower()
    rules,kw={'physics':(PHYS,PHYS_KW),'chemistry':(CHEM,CHEM_KW),'mathematics':(MATH,MATH_KW)}[s]
    # subtopic first (more specific) for chemistry generic topics like "Physical Chemistry"
    generic={'physical chemistry','organic chemistry','inorganic chemistry','mechanics'}
    if topic and topic.lower() not in generic:
        c=_try(rules,topic)
        if c: return c,'topic'
    c=_try(rules,subtopic)
    if c: return c,'subtopic'
    if topic and topic.lower() in generic:
        c=_try(rules,topic)
        if c and topic.lower()!='physical chemistry': return c,'topic'
    c=_kw(kw,question)
    if c: return c,'keyword'
    return None,None
