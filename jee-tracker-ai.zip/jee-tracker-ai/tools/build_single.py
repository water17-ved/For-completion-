#!/usr/bin/env python3
"""Build tracker/index.html — the self-contained, single-file tracker.

Reads   tracker/index.split.html   (tracker + tiny lazy loader that fetches ./ai/*.js)
        tracker/ai/*.js            (engines, quiz bank, JoSAA data, core, tracker bridge, coach UI)
Writes  tracker/index.html         (the same page with all AI code embedded as inert text blocks)

The embedded code is NOT parsed or run at start-up. It is executed the first time the AI Coach tab
opens, so tracker start-up stays as fast as before.

Run:  python tools/build_single.py        (re-run after editing anything in tracker/ai/)
"""
import pathlib
import re
import sys

root = pathlib.Path(__file__).resolve().parent.parent
tr = root / 'tracker'
FILES = ['jee-engines.js', 'jee-formulas.js', 'jee-quizbank.js', 'jee-josaa.js',
         'jee-core.js', 'jee-tracker-bridge.js', 'jee-coach-ui.js']  # load order matters

html = (tr / 'index.split.html').read_text(encoding='utf-8')
m = re.search(r'<script id="jee-ai-coach-loader">.*?</script>\n', html, re.S)
if not m:
    sys.exit('lazy loader block not found in index.split.html')

blobs = []
for f in FILES:
    js = (tr / 'ai' / f).read_text(encoding='utf-8')
    if '</script' in js.lower():
        sys.exit(f + ': contains "</script" - cannot be embedded safely')
    blobs.append('<script type="text/plain" id="jee-ai-src-%s">%s</script>\n' % (f, js))

LOADER = '''<script id="jee-ai-coach-loader">
// Runs the embedded AI code the first time the AI Coach tab opens (nothing is fetched, nothing runs before that).
(function () {
  var FILES = __FILES__, state = 'idle';
  function rootEl() { return document.getElementById('ai-coach-root'); }
  function say(html) { var r = rootEl(); if (r) r.innerHTML = '<div style="padding:30px;text-align:center;color:#9a83b0">' + html + '</div>'; }
  function open() {
    if (state === 'ready') { window.JEECoachUI.open(); return; }
    if (state === 'loading') return;
    state = 'loading';
    try {
      FILES.forEach(function (f) {
        var src = document.getElementById('jee-ai-src-' + f);
        if (!src) throw new Error('embedded file missing: ' + f);
        var s = document.createElement('script'); s.text = src.textContent; document.head.appendChild(s); s.remove();
      });
      if (!window.JEECoachUI) throw new Error('coach did not initialise (see console)');
      window.JEECoachUI.mount(rootEl()); state = 'ready'; window.JEECoachUI.open();
    } catch (e) {
      state = 'idle'; console.error('[AI Coach]', e);
      say('\\u26a0 AI Coach failed to start: ' + String(e && e.message || e).replace(/</g, '&lt;') + '<br><br><button class="add-btn" onclick="AICoachLoader.open()">Retry</button>');
    }
  }
  window.AICoachLoader = { open: open };
})();
</script>
'''.replace('__FILES__', '[' + ', '.join('"%s"' % f for f in FILES) + ']')

html = html[:m.start()] + ''.join(blobs) + LOADER + html[m.end():]
(tr / 'index.html').write_text(html, encoding='utf-8')
print('wrote tracker/index.html  (%.2f MB)' % (len(html.encode('utf-8')) / 1e6))
