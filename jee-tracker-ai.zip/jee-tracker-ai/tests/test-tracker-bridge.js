// node test-tracker-bridge.js <dir>   — builds a fake tracker localStorage and checks the bridge end to end
const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const dir=process.argv[2]||'.';const mem={};
const ls={getItem:k=>k in mem?mem[k]:null,setItem:(k,v)=>{mem[k]=String(v)},removeItem:k=>{delete mem[k]}};
const ctx={console,setTimeout,clearTimeout,localStorage:ls,Date};ctx.window=ctx;ctx.globalThis=ctx;vm.createContext(ctx);
for(const f of ['jee-engines.js','jee-formulas.js','jee-quizbank.js','jee-josaa.js','jee-core.js','jee-tracker-bridge.js'])vm.runInContext(fs.readFileSync(path.join(dir,f),'utf8'),ctx,{filename:f});
const B=ctx.TrackerBridge;let ok=0;const t=(n,f)=>{try{f();ok++;console.log('  ok  ',n)}catch(e){console.log('  FAIL',n,'\n     ',e.message);process.exitCode=1}};
const day=n=>{const d=new Date(Date.now()+n*864e5);return d.toISOString().slice(0,10)};
const set=(k,v)=>ls.setItem(k,JSON.stringify(v));
const tick=n=>Array.from({length:9},(_,i)=>i<n);
t('empty tracker: no crash, profile null',()=>{const s=B.snapshot(true);assert.strictEqual(s.chapters.length,80);assert.strictEqual(s.hasData,false);assert.strictEqual(B.profile(),null)});
// realistic data
set('jee-progress',{'phy-rotational-dynamics':tick(9),'phy-laws-motion':tick(4),'chem-goc':tick(9),'math-circles':tick(2),'math-probability':tick(9)});
set('jee-completion-dates',{'phy-rotational-dynamics':day(-30),'chem-goc':day(-25),'math-probability':day(-3)});
set('jee-chapter-tests',[{subject:'Physics',topic:'Laws of Motion',level:'L1',questions:20,myscore:8,topperscore:18,date:day(-5),mistake:['Conceptual','Calculation']},
  {subject:'Physics',topic:'laws of motion',level:'L2',questions:10,myscore:4,date:day(-2),mistake:'Conceptual'},
  {subject:'Chemistry',topic:'General Organic Chemistry (GOC)',questions:10,myscore:9,date:day(-1)}]);
set('jee-major-tests',[{name:'Mock 1',date:day(-20),maxmarks:300,scored:120},{name:'Mock 2',date:day(-13),maxmarks:300,scored:135},{name:'Mock 3',date:day(-6),maxmarks:300,scored:150},{name:'Mock 4',date:day(-1),maxmarks:300,scored:180},{name:'Unscored',date:day(0),maxmarks:300,scored:''}]);
set('jee-study-hours',[{date:day(0),physicsHours:2,chemistryHours:1,mathsHours:1.5},{date:day(-3),physicsHours:1,chemistryHours:0,mathsHours:2},{date:day(-30),physicsHours:9,chemistryHours:9,mathsHours:9}]);
set('jee-streak',{currentStreak:6,longestStreak:11,lastActiveDate:day(0)});set('jee-exam-date',day(100));set('jee-exam-type','mains');set('jee-target-score',240);
const S=()=>B.snapshot(true);const ch=id=>S().chapters.find(c=>c.id===id);
t('checklist % and status',()=>{assert.strictEqual(ch('phy-laws-motion').pct,44);assert.strictEqual(ch('phy-laws-motion').status,'in_progress');assert.strictEqual(ch('math-probability').status,'done');assert.strictEqual(ch('phy-atoms').status,'not_started')});
t('weak score matches computeWeakSpots formula',()=>{const c=ch('phy-laws-motion');assert.strictEqual(c.avgTestPct,40);assert.strictEqual(c.weakScore,120);assert(/2 tests logged, avg 40% — mostly: Conceptual/.test(c.weakReason),c.weakReason)});
t('complete+untested = +60; low checklist untested = +20',()=>{assert.strictEqual(ch('math-probability').weakScore,60);assert.strictEqual(ch('math-circles').weakScore,20)});
t('weak list sorted, strongest excluded',()=>{const w=S().weak;assert.strictEqual(w[0].id,'phy-laws-motion');assert(!w.find(c=>c.id==='chem-goc'&&c.weakScore>20))});
t('revision due = completed 20+ days ago and not retested',()=>{const r=S().revisionDue;assert.strictEqual(JSON.stringify(r.map(c=>c.id)),'["phy-rotational-dynamics"]');assert.strictEqual(r[0].revisionDueDays,30);assert.strictEqual(ch('chem-goc').status,'done');/* GOC retested after completion */});
t('mocks: unscored ignored, trend vs previous 3',()=>{const s=S();assert.strictEqual(s.mocks.length,4);assert.strictEqual(s.lastMock.pct,60);assert.strictEqual(s.mockTrend,60-Math.round((40+45+50)/3))});
t('study hours: today, 7-day window',()=>{const s=S();assert.strictEqual(s.study.hoursToday,4.5);assert.strictEqual(s.study.hoursWeek,7.5)});
t('exam countdown / streak',()=>{const s=S();assert.strictEqual(s.exam.daysLeft,100);assert.strictEqual(s.exam.targetScore,240);assert.strictEqual(s.streak.current,6)});
t('profile is compact and useful',()=>{const p=B.profile();const j=JSON.stringify(p);assert(j.length<900,'size '+j.length);assert.strictEqual(p.daysToExam,100);assert(/Laws of Motion/.test(p.topWeakChapters[0]));assert.strictEqual(p.revisionDueCount,1)});
t('id maps: every tracker chapter mapped, engine ids exist in SYLLABUS',()=>{const SYL=ctx.JEESyllabus;const valid=new Set([...SYL.physics,...SYL.chemistry,...SYL.mathematics].map(c=>c.id));B.chapters().forEach(c=>c.e.forEach(e=>assert(valid.has(e),c.id+'->'+e)));assert.strictEqual(B.toEngineIds('math-conic-sections').join(),'para,ell,hyp');assert(B.toTrackerIds('mat').length===2)});
t('bridge is read-only (no tracker key changed)',()=>{const before=JSON.stringify(mem);B.snapshot(true);B.profile();assert.strictEqual(JSON.stringify(mem),before)});
t('corrupt JSON in a key does not crash',()=>{ls.setItem('jee-progress','{oops');const s=B.snapshot(true);assert.strictEqual(s.chapters.length,80);set('jee-progress',{})});
// core integration
const core=new ctx.JEEAICoreV2({});B.install(core);
t('install replaces registry engines with tracker adapters',()=>{['syllabus','weak','revision','timer','score'].forEach(k=>assert.strictEqual(core.registry.get(k).tracker,true,k));assert(core.registry.get('josaa'));assert(core.registry.get('quizbank'))});
t('study_tonight context now uses tracker data',()=>{set('jee-progress',{'phy-rotational-dynamics':tick(9)});B.snapshot(true);const c=core.context.build('What should I study tonight?');assert.strictEqual(c.intent,'study_tonight');assert(c.engines.dueToday.length===1&&c.engines.dueToday[0].name==='Rotational Dynamics');assert(c.engines.weakPriority[0].name==='Laws of Motion');assert.strictEqual(c.engines.completion.overallPct,S().completion.overallPct)});
t('weakness + test_analysis contexts populated',()=>{const w=core.context.build('which chapters am I weak in?');assert(w.engines.weakAreas.priorityList.length>0);const a=core.context.build('analyse my test');assert.strictEqual(a.engines.score.lastMock.pct,60)});
t('profile reaches Gemini request; local answers unaffected',async()=>{});
let sent=null;core.requests.send=async(o)=>{sent=o;return 'ok'};core.configure({apiKey:'x'});
core.ask({userMessage:'Explain torque'}).then(r=>{assert.strictEqual(r.source,'gemini');const m=sent.messages[sent.messages.length-1].content;assert(/\[Student profile from their tracker\]/.test(m));assert(/"daysToExam":100/.test(m));console.log('  ok   Gemini prompt carries profile ('+m.length+' chars)');
  return core.ask({userMessage:'JEE Advanced rank 900, which IIT?'})}).then(r=>{assert.strictEqual(r.source,'local');console.log('  ok   JoSAA local answer still works')}).catch(e=>{console.log('  FAIL async',e.message);process.exitCode=1}).finally(()=>console.log(ok+' sync tests passed'));
