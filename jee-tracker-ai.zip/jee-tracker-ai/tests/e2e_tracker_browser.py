"""Browser end-to-end test of the tracker + AI Coach (needs: pip install playwright && playwright install chromium).
Run from the repo root:  python tests/e2e_tracker_browser.py     (set E2E_DIR=path to test another folder)
Gemini is mocked; nothing leaves your machine."""
import json,datetime,sys,subprocess,time,atexit,os,pathlib
srv=subprocess.Popen(['python3','-m','http.server','8765'],cwd=os.environ.get('E2E_DIR',str(pathlib.Path(__file__).resolve().parent.parent/'tracker')),stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);atexit.register(srv.terminate);time.sleep(1.5)
from playwright.sync_api import sync_playwright
today=datetime.date.today()
d=lambda n:(today+datetime.timedelta(days=n)).isoformat()
tick=lambda n:[i<n for i in range(9)]
seed={
 'jee-onboarding-done':True,'jee-player-name':'Test','jee-exam-date':d(100),'jee-exam-type':'mains','jee-target-score':240,
 'jee-progress':{'phy-rotational-dynamics':tick(9),'phy-laws-motion':tick(4),'chem-goc':tick(9),'math-circles':tick(2),'math-probability':tick(9),'math-quadratic-equations':tick(3)},
 'jee-completion-dates':{'phy-rotational-dynamics':d(-30),'chem-goc':d(-25),'math-probability':d(-3)},
 'jee-chapter-tests':[{'subject':'Physics','topic':'Laws of Motion','level':'L1','questions':20,'myscore':8,'date':d(-5),'mistake':['Conceptual','Calculation']},
                      {'subject':'Physics','topic':'Laws of Motion','level':'L2','questions':10,'myscore':4,'date':d(-2),'mistake':'Conceptual'}],
 'jee-major-tests':[{'name':'Mock 1','date':d(-20),'maxmarks':300,'scored':120},{'name':'Mock 2','date':d(-13),'maxmarks':300,'scored':135},{'name':'Mock 3','date':d(-6),'maxmarks':300,'scored':150},{'name':'Mock 4','date':d(-1),'maxmarks':300,'scored':180}],
 'jee-study-hours':[{'date':d(0),'physicsHours':2,'chemistryHours':1,'mathsHours':1.5}],
 'jee-streak':{'currentStreak':6,'longestStreak':11,'lastActiveDate':d(0)},
}
init="(()=>{const s=%s;if(!localStorage.getItem('__seeded')){for(const k in s)localStorage.setItem(k,JSON.stringify(s[k]));localStorage.setItem('__seeded','1');}sessionStorage.setItem('jee-splash-seen','1');})()"%json.dumps(seed)
os.makedirs('test-output',exist_ok=True)
errs=[];res=[]
def ck(name,cond,extra=''):
    res.append((name,bool(cond)));print(('  ok   ' if cond else '  FAIL ')+name+(' '+str(extra) if extra and not cond else ''))
with sync_playwright() as p:
    b=p.chromium.launch();ctx=b.new_context(viewport={'width':390,'height':844},device_scale_factor=2,is_mobile=True,has_touch=True)
    ctx.add_init_script(init);pg=ctx.new_page()
    pg.on('pageerror',lambda e:errs.append('PAGEERR '+str(e)))
    pg.on('console',lambda m:errs.append('CONSOLE '+m.text) if m.type=='error' and 'net::' not in m.text and 'Failed to load resource' not in m.text else None)
    pg.goto('http://localhost:8765/index.html');pg.wait_for_timeout(4200)
    ck('tracker loads, AI Coach not loaded yet (lazy)',pg.evaluate("typeof window.JEECoachUI==='undefined' && typeof window.AICoachLoader==='object'"))
    pg.evaluate("switchTab('ai-coach')");pg.wait_for_selector('.jc-wrap',timeout=15000)
    ck('coach mounted after tab open',pg.locator('.jc-wrap').count()==1)
    ck('nav lists AI Coach',pg.evaluate("NAV_CATEGORIES.track.tabs.some(t=>t.id==='ai-coach')"))
    pg.wait_for_timeout(1400);pg.screenshot(path='test-output/1-open.png')
    ck('stats chips show tracker data',pg.locator('.jc-stat').count()>=5 and '100d' in pg.locator('.jc-stats').inner_text())
    ck('key card shown when no key',pg.locator('text=Gemini key needed').count()==1)
    # study tonight
    pg.click('.jc-chip:has-text("Study tonight")');pg.wait_for_selector('.jc-card:has-text("Tonight")');pg.wait_for_timeout(300)
    t=pg.locator('.jc-card').filter(has_text="Tonight's plan").inner_text()
    ck('plan lists revision-due chapter',('Rotational Dynamics' in t) and ('30 days' in t),t[:200])
    ck('plan lists weak chapter with reason',('Laws of Motion' in t) and ('avg 40%' in t),t[:300])
    pg.screenshot(path='test-output/2-plan.png')
    # weak
    pg.click('.jc-chip:has-text("Weak chapters")');pg.wait_for_selector('.jc-card:has-text("Your weakest chapters")');pg.wait_for_timeout(300)
    ck('weak card has Quiz/Formulas buttons',pg.locator('.jc-card:has-text("weakest chapters") [data-act=quiz]').count()>=1)
    # mock
    pg.click('.jc-chip:has-text("Mock trend")');pg.wait_for_selector('.jc-card:has-text("Mock trend")');pg.wait_for_timeout(200)
    ck('mock card shows latest %',pg.locator('.jc-card:has-text("Mock trend")').inner_text().count('60%')>=1)
    # quiz on weak chapter
    pg.click('.jc-chip[data-act=quizweak]');pg.wait_for_selector('.jc-opt');pg.wait_for_timeout(300)
    ck('quiz card renders 4 options',pg.locator('.jc-opt').count()==4)
    qid=pg.evaluate("(()=>{const c=document.querySelector('[data-card]');return c.dataset.card})()")
    before=pg.evaluate("localStorage.getItem('jee_qbank_seen')")
    pg.locator('.jc-opt').first.click();pg.wait_for_selector('.jc-sol');
    ck('answer gives feedback + solution',pg.locator('.jc-sol').count()==1 and pg.locator('.jc-opt.ok').count()==1)
    ck('quiz result stored in jee_qbank_* (not jee- tracker keys)',pg.evaluate("JSON.parse(localStorage.getItem('jee_qbank_seen')||'[]').length")>=1)
    pg.screenshot(path='test-output/3-quiz.png')
    pg.click('.jc-btn:has-text("Next question")');pg.wait_for_timeout(300)
    ck('next question appended',pg.locator('.jc-card[data-card]').count()==2)
    # college predictor
    ta=pg.locator('.jc-input textarea');ta.fill('My JEE Advanced rank is 2500, which IIT can I get?');pg.click('.jc-send');pg.wait_for_selector('.jc-card:has-text("Rank 2500")');pg.wait_for_timeout(300)
    ck('JoSAA chances card',pg.locator('.jc-card:has-text("Rank 2500")').inner_text().lower().count('safe')>=1)
    pg.screenshot(path='test-output/4-josaa.png')
    ta.fill('what was the cutoff for CSE at NIT Trichy?');pg.click('.jc-send');pg.wait_for_selector('.jc-card:has-text("Tiruchirappalli")');
    ck('cutoff card',pg.locator('.jc-table').count()>=2)
    ta.fill('my rank is 4500, which college can I get?');pg.click('.jc-send');pg.wait_for_selector('.jc-card:has-text("Which rank is 4500")');
    pg.click('.jc-btn:has-text("JEE Main rank")');pg.wait_for_selector('.jc-card:has-text("Rank 4500")');
    ck('needs-exam flow resolves',pg.locator('.jc-card:has-text("Rank 4500")').count()>=1)
    # formulas
    ta.fill('torque formula');pg.click('.jc-send');pg.wait_for_selector('.jc-card:has-text("Formulas")');ck('formula card',pg.locator('.jc-card:has-text("Formulas")').count()>=1)
    # gemini path with fake fetch (no network)
    pg.evaluate("""()=>{window.__reqs=[];const enc=new TextEncoder();window.fetch=async(url,opt)=>{window.__reqs.push({url:String(url),body:JSON.parse(opt.body)});
      const chunk='data: '+JSON.stringify({candidates:[{content:{parts:[{text:'Torque is **force x distance**: $\\\\tau = r F \\\\sin\\\\theta$.'}]}}]})+'\\n\\n';
      return {ok:true,status:200,body:{getReader(){let done=false;return{read:async()=>done?{done:true}:(done=true,{done:false,value:enc.encode(chunk)})}}},json:async()=>({}),text:async()=>''};}}""")
    pg.click('[data-act=settings]');pg.fill('#jc-key','AIzaFAKE');pg.click('[data-act=save]')
    ck('key persisted',pg.evaluate("localStorage.getItem('jee_key')")=='AIzaFAKE')
    ta.fill('Explain torque in simple words');pg.click('.jc-send');pg.wait_for_timeout(1500)
    n=pg.evaluate("window.__reqs.length");ck('Gemini called once via RequestManager',n==1,n)
    if n:
        body=json.dumps(pg.evaluate("window.__reqs[0].body"))
        ck('request carries tracker profile',('Student profile from their tracker' in body) and ('daysToExam' in body) and ('Laws of Motion' in body))
        ck('request has system prompt',('JEE' in body and 'coach' in body))
    ck('assistant reply rendered with markdown',pg.locator('.jc-msg.assistant b:has-text("force x distance")').count()==1)
    pg.screenshot(path='test-output/5-gemini.png')
    # local answers must not call Gemini
    pg.evaluate("window.__reqs.length=0");ta.fill('AIR 900 advanced, which IIT?');pg.click('.jc-send');pg.wait_for_selector('.jc-card:has-text("Rank 900")');
    ck('local answers make no API call',pg.evaluate("window.__reqs.length")==0)
    # tracker data untouched
    changed=pg.evaluate("""()=>{const s=%s;let bad=[];for(const k in s){if(k==='jee-onboarding-done')continue;const cur=JSON.parse(localStorage.getItem(k)||'null');if(JSON.stringify(cur)!==JSON.stringify(s[k]))bad.push(k)}return bad}"""%json.dumps(seed))
    ck('tracker keys unchanged by the coach (excluding tracker-own writes)',all(k in('jee-streak','jee-study-hours') for k in changed),changed)
    # persistence of chat
    pg.reload();pg.wait_for_timeout(3500);pg.evaluate("switchTab('ai-coach')");pg.wait_for_selector('.jc-wrap');pg.wait_for_timeout(500)
    ck('chat history restored after reload',pg.locator('.jc-msg.user').count()>=1)
    # switching tabs back and forth keeps working
    pg.evaluate("switchTab('physics')");pg.wait_for_timeout(300);pg.evaluate("switchTab('ai-coach')");pg.wait_for_timeout(300)
    ck('reopen tab OK',pg.locator('.jc-wrap').count()==1)
    # command center shortcut
    pg.evaluate("switchTab('command-center')");pg.wait_for_timeout(500)
    ck('command center has AI Coach shortcut',pg.locator('.cc-action:has-text("Ask AI Coach")').count()==1)
    # empty tracker
    b.close()
print('\nconsole/page errors:',len(errs))
for e in errs[:12]:print('  ',e[:220])
print('passed',sum(1 for _,o in res if o),'/',len(res))
sys.exit(0 if all(o for _,o in res) else 1)
