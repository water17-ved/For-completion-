"""Browser test for the floating AI button, the bottom sheet and the accessibility features.
Needs: pip install playwright && playwright install chromium.   Run from the repo root:  python tests/e2e_accessibility.py
Speech APIs and Gemini are mocked; nothing leaves your machine."""
import json, datetime, sys, os, pathlib, subprocess, time, atexit
ROOT = pathlib.Path(__file__).resolve().parent.parent
srv = subprocess.Popen(['python3', '-m', 'http.server', '8790'], cwd=os.environ.get('E2E_DIR', str(ROOT / 'tracker')), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
atexit.register(srv.terminate); time.sleep(1.5)
from playwright.sync_api import sync_playwright
today = datetime.date.today(); d = lambda n: (today + datetime.timedelta(days=n)).isoformat(); tick = lambda n: [i < n for i in range(9)]
seed = {'jee-onboarding-done': True, 'jee-player-name': 'Test', 'jee-exam-date': d(100), 'jee-exam-type': 'mains',
        'jee-progress': {'phy-rotational-dynamics': tick(9), 'phy-laws-motion': tick(4)}, 'jee-completion-dates': {'phy-rotational-dynamics': d(-30)},
        'jee-chapter-tests': [{'subject': 'Physics', 'topic': 'Laws of Motion', 'level': 'L1', 'questions': 20, 'myscore': 8, 'date': d(-5), 'mistake': ['Conceptual']}]}
MOCKS = """
(() => {
  window.__speech = {spoken: [], cancelled: 0, listened: 0};
  class SR { constructor(){ this.lang=''; } start(){ window.__speech.listened++; setTimeout(()=>{ this.onresult && this.onresult({results:[[{transcript:'explain torque'}]]}); setTimeout(()=>this.onend && this.onend(), 50); }, 50); } stop(){ this.onend && this.onend(); } }
  window.SpeechRecognition = SR; window.webkitSpeechRecognition = SR;   // newer Chromium ships its own SpeechRecognition, so mock both
  class U { constructor(t){ this.text=t; } }
  window.SpeechSynthesisUtterance = U;
  let speaking=false;
  Object.defineProperty(window, 'speechSynthesis', { configurable: true, value: { get speaking(){return speaking;}, speak(u){ speaking=true; window.__speech.spoken.push(u.text); setTimeout(()=>{speaking=false; u.onend && u.onend();}, 5000); }, cancel(){ speaking=false; window.__speech.cancelled++; } } });
})();
"""
init = "(()=>{const s=%s;if(!localStorage.getItem('__seeded')){for(const k in s)localStorage.setItem(k,JSON.stringify(s[k]));localStorage.setItem('__seeded','1');}sessionStorage.setItem('jee-splash-seen','1');})();" % json.dumps(seed) + MOCKS
res = []; errs = []
def ck(name, cond, extra=''):
    res.append(bool(cond)); print(('  ok   ' if cond else '  FAIL ') + name + ((' ' + str(extra)) if (extra and not cond) else ''))
os.makedirs('test-output', exist_ok=True)
with sync_playwright() as p:
    b = p.chromium.launch(); ctx = b.new_context(viewport={'width': 390, 'height': 844}, device_scale_factor=2, is_mobile=True, has_touch=True)
    ctx.add_init_script(init); pg = ctx.new_page()
    pg.on('pageerror', lambda e: errs.append(str(e)[:200]))
    pg.goto('http://localhost:8790/index.html'); pg.wait_for_timeout(4200)
    # ---- floating button ----
    pg.evaluate("switchTab('physics')"); pg.wait_for_timeout(500)
    ck('floating button visible on a normal tab', pg.locator('.jc-fab.on').count() == 1)
    ck('floating button has an accessible name', pg.get_attribute('.jc-fab', 'aria-label') == 'Ask AI Coach')
    ck('coach NOT loaded before first use (lazy)', pg.evaluate("typeof window.JEECoachUI==='undefined'"))
    pg.screenshot(path='test-output/a1-fab.png')
    # ---- open sheet ----
    pg.click('.jc-fab'); pg.wait_for_selector('.jc-sheet.open .jc-wrap', timeout=15000); pg.wait_for_timeout(600)
    ck('sheet is a modal dialog', pg.evaluate("(()=>{const s=document.querySelector('.jc-sheet');return s.getAttribute('role')==='dialog'&&s.getAttribute('aria-modal')==='true'&&!!s.getAttribute('aria-label')})()"))
    ck('coach lives inside the sheet', pg.evaluate("!!document.querySelector('.jc-sheet .jc-wrap')"))
    ck('input focused on open', pg.evaluate("document.activeElement && document.activeElement.tagName==='TEXTAREA'"))
    ck('floating button hidden while sheet open', pg.locator('.jc-fab.on').count() == 0)
    ck('page behind is scroll-locked', pg.evaluate("document.body.classList.contains('jc-sheet-open')"))
    ck('context hint chip for the current tab (physics)', pg.locator('.jc-chip[data-hint]:has-text("physics quiz")').count() == 1)
    pg.screenshot(path='test-output/a2-sheet.png')
    # hint chip works inside the sheet
    pg.click('.jc-chip[data-hint]'); pg.wait_for_selector('.jc-sheet .jc-opt'); ck('hint chip starts a physics quiz', pg.locator('.jc-sheet .jc-opt').count() == 4)
    pg.locator('.jc-sheet .jc-opt').first.click(); pg.wait_for_selector('.jc-sheet .jc-sol')
    tags = pg.locator('.jc-sheet .jc-tag').all_inner_texts()
    ck('quiz result is not colour-only (text markers)', any('correct answer' in t for t in tags), tags)
    ck('quiz feedback is a live status region', pg.get_attribute('.jc-sheet .jc-fb', 'role') == 'status')
    # ---- keyboard ----
    ok_trap = True
    for _ in range(40):
        pg.keyboard.press('Tab')
        if not pg.evaluate("document.querySelector('.jc-sheet').contains(document.activeElement)"): ok_trap = False; break
    ck('Tab key cycles inside the dialog (focus trap)', ok_trap)
    pg.keyboard.press('Escape'); pg.wait_for_timeout(500)
    ck('Escape closes the sheet', pg.locator('.jc-sheet.open').count() == 0 and pg.locator('.jc-sheet:visible').count() == 0)
    ck('focus returns to the floating button', pg.evaluate("document.activeElement && document.activeElement.classList.contains('jc-fab')"))
    ck('coach moved back to its tab', pg.evaluate("!!document.querySelector('#ai-coach #ai-coach-root .jc-wrap')"))
    ck('scroll lock released', pg.evaluate("!document.body.classList.contains('jc-sheet-open')"))
    pg.click('.jc-fab'); pg.wait_for_selector('.jc-sheet.open .jc-wrap'); pg.wait_for_timeout(300)
    ck('conversation kept when re-opened', pg.locator('.jc-sheet .jc-card[data-card]').count() == 1)
    # backdrop click closes
    pg.mouse.click(195, 30); pg.wait_for_timeout(450); ck('tapping the backdrop closes', pg.locator('.jc-sheet.open').count() == 0)
    # open tab while sheet open
    pg.click('.jc-fab'); pg.wait_for_selector('.jc-sheet.open .jc-wrap'); pg.evaluate("switchTab('ai-coach')"); pg.wait_for_timeout(700)
    ck('opening the AI tab closes the sheet and shows the coach there', pg.locator('.jc-sheet:visible').count() == 0 and pg.evaluate("!!document.querySelector('#ai-coach #ai-coach-root .jc-wrap')"))
    ck('floating button hidden on the AI tab itself', pg.locator('.jc-fab.on').count() == 0)
    pg.evaluate("switchTab('tests')"); pg.wait_for_timeout(500); ck('floating button back on other tabs', pg.locator('.jc-fab.on').count() == 1)
    # ---- voice input ----
    pg.click('.jc-fab'); pg.wait_for_selector('.jc-sheet.open .jc-mic'); ck('mic button present when speech recognition exists', pg.locator('.jc-mic').count() == 1)
    ck('mic has name + pressed state', pg.get_attribute('.jc-mic', 'aria-label') == 'Speak your question' and pg.get_attribute('.jc-mic', 'aria-pressed') == 'false')
    users_before = pg.locator('.jc-msg.user').count()
    pg.click('.jc-mic'); pg.wait_for_function("document.querySelector('.jc-input textarea').value.includes('explain torque')", timeout=3000)
    pg.wait_for_timeout(300)
    ck('spoken text lands in the input (not auto-sent)', pg.input_value('.jc-input textarea') == 'explain torque' and pg.locator('.jc-msg.user').count() == users_before)
    ck('mic state resets after listening', pg.get_attribute('.jc-mic', 'aria-pressed') == 'false')
    # ---- Gemini reply + read aloud (fetch mocked) ----
    pg.evaluate("""()=>{const enc=new TextEncoder();window.fetch=async()=>{const chunk='data: '+JSON.stringify({candidates:[{content:{parts:[{text:'Torque is **force times distance**: $\\\\tau = rF$. Remember the lever arm.'}]}}]})+'\\n\\n';
      return {ok:true,status:200,body:{getReader(){let done=false;return{read:async()=>done?{done:true}:(done=true,{done:false,value:enc.encode(chunk)})}}},json:async()=>({}),text:async()=>''};}}""")
    pg.evaluate("localStorage.setItem('jee_key','AIzaFAKE')"); pg.reload(); pg.wait_for_timeout(3500)
    pg.evaluate("switchTab('physics')"); pg.click('.jc-fab'); pg.wait_for_selector('.jc-sheet.open .jc-wrap'); pg.wait_for_timeout(500)
    pg.evaluate("""()=>{const enc=new TextEncoder();window.fetch=async()=>{const chunk='data: '+JSON.stringify({candidates:[{content:{parts:[{text:'Torque is **force times distance**: $\\\\tau = rF$. Remember the lever arm.'}]}}]})+'\\n\\n';
      return {ok:true,status:200,body:{getReader(){let done=false;return{read:async()=>done?{done:true}:(done=true,{done:false,value:enc.encode(chunk)})}}},json:async()=>({}),text:async()=>''};}}""")
    pg.fill('.jc-input textarea', 'Explain torque in simple words'); pg.click('.jc-send'); pg.wait_for_selector('.jc-msg.assistant [data-act=speak]', timeout=8000)
    ck('chat is a labelled live log', pg.evaluate("(()=>{const c=document.querySelector('.jc-chat');return c.getAttribute('role')==='log'&&c.getAttribute('aria-busy')==='false'})()"))
    pg.click('.jc-msg.assistant [data-act=speak]'); pg.wait_for_timeout(150)
    sp = pg.evaluate("window.__speech.spoken")
    ck('read-aloud speaks the answer with maths replaced', len(sp) == 1 and 'force times distance' in sp[0] and '$' not in sp[0] and 'formula' in sp[0], sp)
    pg.click('.jc-msg.assistant [data-act=speak]'); pg.wait_for_timeout(100)
    ck('second press stops speech', pg.evaluate("window.__speech.cancelled")>=1)
    # ---- text size + FAB toggle ----
    pg.click('[data-act=settings]'); fs0 = pg.evaluate("parseFloat(getComputedStyle(document.querySelector('.jc-msg.assistant')).fontSize)")
    pg.click('[data-act="fs+"]'); pg.click('[data-act="fs+"]'); pg.wait_for_timeout(100)
    fs1 = pg.evaluate("parseFloat(getComputedStyle(document.querySelector('.jc-msg.assistant')).fontSize)")
    ck('A+ enlarges chat text', fs1 > fs0 * 1.15, (fs0, fs1)); ck('size persisted', pg.evaluate("localStorage.getItem('jee_coach_fs')") == '1.2')
    pg.click('#jc-fabtoggle'); ck('turning the floating button off is stored', pg.evaluate("localStorage.getItem('jee_coach_fab')") == '0')
    pg.keyboard.press('Escape'); pg.wait_for_timeout(450); ck('floating button hidden after toggle off', pg.locator('.jc-fab.on').count() == 0)
    # ---- a11y audit ----
    pg.evaluate("localStorage.setItem('jee_coach_fab','1')"); pg.reload(); pg.wait_for_timeout(3500); pg.evaluate("switchTab('physics')"); pg.click('.jc-fab'); pg.wait_for_selector('.jc-sheet.open .jc-wrap'); pg.wait_for_timeout(500)
    pg.click('.jc-chip:has-text("Weak chapters")'); pg.wait_for_selector('.jc-card:has-text("weakest")')
    audit = pg.evaluate("""()=>{const out={unnamed:[],small:[]};
      document.querySelectorAll('.jc-sheet button, .jc-sheet input, .jc-sheet textarea, .jc-sheet select').forEach(n=>{
        if(n.offsetParent===null) return;
        const name=(n.getAttribute('aria-label')||n.innerText||n.value||n.placeholder||'').trim();
        const lbl=n.id&&document.querySelector('label[for="'+n.id+'"]'); const wrapped=n.closest('label');
        if(!name&&!lbl&&!wrapped) out.unnamed.push(n.outerHTML.slice(0,80));
        const r=n.getBoundingClientRect(); const min=n.classList.contains('sm')?36:40;
        if(n.type!=='checkbox'&&(r.height<min-1)) out.small.push(n.className+' '+Math.round(r.height));
      }); return out;}""")
    ck('every control has an accessible name', not audit['unnamed'], audit['unnamed'])
    ck('touch targets are large enough (>=40px, small buttons >=36px)', not audit['small'], audit['small'])
    pg.screenshot(path='test-output/a3-weak-in-sheet.png')
    # reduced motion
    ctx2 = b.new_context(viewport={'width': 390, 'height': 844}, reduced_motion='reduce'); ctx2.add_init_script(init); pg2 = ctx2.new_page()
    pg2.goto('http://localhost:8790/index.html'); pg2.wait_for_timeout(4000); pg2.evaluate("switchTab('physics')"); pg2.click('.jc-fab'); pg2.wait_for_selector('.jc-sheet.open')
    ck('reduced-motion removes the sheet animation', pg2.evaluate("getComputedStyle(document.querySelector('.jc-sheet')).transitionDuration") in ('0s', '0s, 0s'))
    # desktop layout
    ctx3 = b.new_context(viewport={'width': 1280, 'height': 800}); ctx3.add_init_script(init); pg3 = ctx3.new_page()
    pg3.goto('http://localhost:8790/index.html'); pg3.wait_for_timeout(4000); pg3.evaluate("switchTab('physics')"); pg3.click('.jc-fab'); pg3.wait_for_selector('.jc-sheet.open .jc-wrap'); pg3.wait_for_timeout(500)
    bb = pg3.locator('.jc-sheet').bounding_box(); ck('desktop: side panel ~440px wide', 430 <= bb['width'] <= 450 and bb['x'] > 700, bb); pg3.screenshot(path='test-output/a4-desktop.png')
    b.close()
print('\npage errors:', errs[:5]); print('passed', sum(res), '/', len(res)); sys.exit(0 if all(res) and not errs else 1)
