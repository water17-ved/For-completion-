const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const dir=process.argv[2]||'.';const mem={};
const ls={getItem:k=>k in mem?mem[k]:null,setItem:(k,v)=>{mem[k]=String(v)},removeItem:k=>{delete mem[k]}};
const ctx={console,setTimeout,clearTimeout,localStorage:ls};ctx.window=ctx;ctx.globalThis=ctx;vm.createContext(ctx);
for(const f of ['jee-engines.js','jee-formulas.js','jee-quizbank.js','jee-josaa.js','jee-core.js'])vm.runInContext(fs.readFileSync(path.join(dir,f),'utf8'),ctx,{filename:f});
const core=new ctx.JEEAICoreV2({});const SYL=ctx.JEESyllabus;
const valid=new Set([...SYL.physics,...SYL.chemistry,...SYL.mathematics].map(c=>c.id));
const bank=core.quizbank;let ok=0;const t=(n,f)=>{try{f();ok++;console.log('  ok  ',n)}catch(e){console.log('  FAIL',n,e.message);process.exitCode=1}};
t('978 questions, every chapter id exists in SYLLABUS',()=>{assert.strictEqual(bank.count,978);bank.questions.forEach(q=>assert(valid.has(q.ch),q.id+' '+q.ch))});
t('chapter belongs to the right subject',()=>{['physics','chemistry','mathematics'].forEach(s=>{const ids=new Set(SYL[s].map(c=>c.id));bank.questions.filter(q=>q.s===s).forEach(q=>assert(ids.has(q.ch),q.id+' '+q.ch+' not in '+s))})});
t('quiz_request routes to local bank for each subject word',()=>{
  for(const [w,s] of [['physics','physics'],['chemistry','chemistry'],['maths','mathematics']]){
    const c=core.context.build('give me a '+w+' mcq');assert(c.canAnswerLocally,w);assert.strictEqual(c.localType,'quiz');assert.strictEqual(c.localAnswer.s,s);assert.strictEqual(c.localAnswer.t,'mcq');}
});
t("'maths' alias and getRandom by real chapter id",()=>{assert(bank.getRandom({subject:'maths',chapter:'qe',count:3}).length===3);assert(bank.getRandom({subject:'physics',chapter:'wave',count:2}).length===2)});
t('numerical excluded by default, included on request',()=>{assert(bank.getRandom({count:500}).every(q=>q.t==='mcq'));assert(bank.getRandom({includeNumerical:true,count:2000}).some(q=>q.t==='num'))});
t('checkAnswer records to jee_qbank_* keys',()=>{const q=bank.getRandom({subject:'physics',count:1})[0];bank.checkAnswer(q.id,q.ans);assert(JSON.parse(mem.jee_qbank_seen).includes(q.id));assert(JSON.parse(mem.jee_qbank_correct).includes(q.id))});
t('all mcq: 4 options, ans in range, no duplicate options',()=>{bank.questions.filter(q=>q.t==='mcq').forEach(q=>{assert.strictEqual(q.opts.length,4);assert(q.ans>=0&&q.ans<4);assert.strictEqual(new Set(q.opts).size,4)})});
console.log(ok+' passed');
