// Node test for JoSAA wiring. Usage: node test-josaa-wiring.js <dir-with-jee-*.js>
const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const dir=process.argv[2]||'.';
const mem={};const ls={getItem:k=>k in mem?mem[k]:null,setItem:(k,v)=>{mem[k]=String(v)},removeItem:k=>{delete mem[k]}};
const ctx={console,setTimeout,clearTimeout,localStorage:ls};ctx.window=ctx;ctx.globalThis=ctx;vm.createContext(ctx);
for(const f of ['jee-engines.js','jee-formulas.js','jee-quizbank.js','jee-josaa.js','jee-core.js'])
  vm.runInContext(fs.readFileSync(path.join(dir,f),'utf8'),ctx,{filename:f});
const core=new ctx.JEEAICoreV2({});           // NOTE: no API key on purpose
let pass=0;const t=(n,f)=>{try{f();pass++;console.log('  ok  ',n)}catch(e){console.log('  FAIL',n,'\n      ',e.message);process.exitCode=1}};
const build=m=>core.context.build(m);

t('josaa registered',()=>{assert(core.registry.get('josaa'));assert(core.registry.status().josaa.ready===true)});
t('registry.query works',()=>{const r=core.registry.query('josaa',{rank:1000,category:'OPEN',type:'IIT'});assert(r&&r.rank===1000)});

t('explicit Advanced rank -> IIT chances, local',()=>{
  const c=build('My JEE Advanced rank is 2500, which IIT can I get?');
  assert.strictEqual(c.intent,'rank_query');assert(c.canAnswerLocally);assert.strictEqual(c.localType,'josaa_chances');
  const a=c.localAnswer;assert.strictEqual(a.rank,2500);assert.strictEqual(a.exam,'advanced');assert.strictEqual(a.category,'OPEN');
  const all=[...a.safe,...a.likely,...a.borderline,...a.reach];assert(all.length>0);assert(all.every(x=>x.type==='IIT'));
  assert(a.safe.every(x=>2500<=x.orank)); assert(a.likely.every(x=>x.orank<2500&&2500<=x.crank));
});
t('Main rank + OBC -> NIT only',()=>{
  const c=build('JEE Main OBC rank 12,000, which NIT and branch can I get?');
  assert.strictEqual(c.localType,'josaa_chances');const a=c.localAnswer;
  assert.strictEqual(a.category,'OBC-NCL');assert.strictEqual(a.exam,'main');
  [...a.safe,...a.likely,...a.borderline,...a.reach].forEach(x=>assert(x.type!=='IIT'));
});
t('rank + CSE filter',()=>{
  const a=build('AIR 3000 in advanced, chances for CSE at IITs?').localAnswer;
  assert.strictEqual(a.program,'computer science');
  [...a.safe,...a.likely,...a.borderline,...a.reach].forEach(x=>assert(/computer science/i.test(x.program)));
});
t('rank "5k" shorthand',()=>assert.strictEqual(build('Main rank 5k which college?').localAnswer.rank,5000));
t('rank without exam asks which exam (still local)',()=>{
  const c=build('my rank is 4500, which college can I get?');
  assert(c.canAnswerLocally);assert.strictEqual(c.localType,'josaa_needs_exam');assert(/Main|Advanced/.test(c.localAnswer.question));
});
t('cutoff for named college+branch',()=>{
  const c=build('What was the cutoff for CSE at NIT Trichy?');
  assert.strictEqual(c.localType,'josaa_cutoff');const a=c.localAnswer;
  assert(a.rows.length>0);assert(a.rows.every(r=>/Tiruchirappalli/.test(r.institute)&&/computer science/i.test(r.program)));
});
t('cutoff IIT Bombay CSE, SC category',()=>{
  const a=build('IIT Bombay computer science cutoff for SC').localAnswer;
  assert.strictEqual(a.category,'SC');assert(a.rows.length&&a.rows.every(r=>r.institute==='IIT Bombay'));
});
t('ambiguous "delhi" + iit picks IIT only',()=>{
  const a=build('IIT Delhi cutoff for CSE').localAnswer;assert(a.rows.every(r=>r.institute==='IIT Delhi'));
});
t('estimator cache used when no rank typed',()=>{
  core.rank.query({score:210,exam:'main',category:'general'});
  const c=build('Which colleges can I get with my rank?');
  assert.strictEqual(c.localType,'josaa_chances');assert.strictEqual(c.localAnswer.source,'score_estimate');
});
t('legacy rank answer when not asking about colleges',()=>{
  const c=build('What is my rank and percentile?');assert.strictEqual(c.localType,'rank');
});
// ---- false-positive guards ----
for (const m of ['Explain unit vectors','What is nitrogen fixation?','definition of infinite series','speed of sound in air','Find the rank of a 3x3 matrix','rank of matrix 3']) {
  t('no hijack: '+m,()=>{const c=build(m);assert(!/^josaa/.test(c.localType||''),'got '+c.localType);assert.notStrictEqual(c.intent==='rank_query'&&c.canAnswerLocally,true)});
}
t('local answers need no API key',async()=>{ /* async checked below */ });
core.ask({userMessage:'JEE Advanced rank 900, which IIT?'}).then(r=>{
  assert.strictEqual(r.source,'local');console.log('  ok   ask() local without key ->',r.data.counts);
  return core.ask({userMessage:'Explain torque'}).then(()=>{throw new Error('should need key')},e=>{assert(/NO_KEY/.test(e.message));console.log('  ok   ask() gemini path still requires key');});
}).catch(e=>{console.log('  FAIL ask()',e.message);process.exitCode=1}).finally(()=>console.log(pass+' sync tests passed'));
// sample output
const s=build('My JEE Advanced rank is 2500, which IIT can I get?').localAnswer;
console.log('\nSAMPLE counts',s.counts,'\n safe[0]',JSON.stringify(s.safe[0]),'\n likely[0]',JSON.stringify(s.likely[0]),'\n reach[0]',JSON.stringify(s.reach[0]));
console.log('size bytes',JSON.stringify(s).length);
